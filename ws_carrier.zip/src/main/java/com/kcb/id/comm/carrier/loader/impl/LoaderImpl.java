package com.kcb.id.comm.carrier.loader.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.kcb.id.comm.carrier.common.XMLUtils;
import com.kcb.id.comm.carrier.loader.Loader;

public abstract class LoaderImpl implements Loader {
	
	static Logger logger = LoggerFactory.getLogger(LoaderImpl.class);
	TYPE type;
	String loaderFilePath;
	
	public TYPE getType() {
		return type;
	}

	public void setType(TYPE type) {
		this.type = type;
	}

	public String getLoaderFilePath() {
		return loaderFilePath;
	}

	public void setLoaderFilePath(String loaderFilePath) {
		this.loaderFilePath = loaderFilePath;
	}
	
	@Override
	public void load(ApplicationContext context) {
		try {
			if (this.getLoaderFilePath() == null) {
				logger.info("loader file path is null..............");
				return;
			}else {
				logger.info("loader file path is not null..............");
			}
			ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
			Resource[] resources = resolver.getResources(this.getLoaderFilePath());
			logger.info("resource file count : " + resources.length);
			for(Resource res : resources) {
				this.load(context,res.getInputStream());
			}
		} catch (Exception e) {
			logger.error(e.toString(),e);
		}
	}
	
	
	public void load(ApplicationContext context, InputStream is) {
		try {
			Document doc = XMLUtils.getDocument(is);
			if (doc == null) {
				logger.error("xml file error");
				return;
			}
			NodeList nodeList = doc.getElementsByTagName("SET");
			if (nodeList == null) {
				logger.error("xml does not contains SET element");
				return;
			}else {
				logger.info("Nodelist of SET is " + nodeList.getLength());
			}
			int LoopCount = 1;
			logger.info("LOADER   " + nodeList.item(0).getNodeName());
			this.parseMe(context, nodeList);
		} catch (Exception e) {
			logger.error(e.toString(),e);
		} finally {
			try {if (is != null)is.close();} catch (Exception e) {}
		}
	}
	
	public abstract void parseMe(ApplicationContext context, NodeList nodeList);
}
