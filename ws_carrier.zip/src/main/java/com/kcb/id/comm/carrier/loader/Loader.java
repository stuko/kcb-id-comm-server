package com.kcb.id.comm.carrier.loader;

import java.io.InputStream;

import org.springframework.context.ApplicationContext;

public interface Loader {
	enum TYPE {XML, JSON , YML , PROPERTIES};
	void setType(TYPE type);
	TYPE getType();
	void setLoaderFilePath(String file);
	String getLoaderFilePath();
	void load(ApplicationContext context);
	void load(ApplicationContext context, InputStream is);
}
