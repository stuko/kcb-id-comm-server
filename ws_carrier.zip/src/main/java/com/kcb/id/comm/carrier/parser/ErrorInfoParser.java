package com.kcb.id.comm.carrier.parser;

import org.springframework.context.ApplicationContext;
import org.w3c.dom.NodeList;

import com.kcb.id.comm.carrier.loader.ErrorInfo;

public interface ErrorInfoParser {
	ErrorInfo parse(ApplicationContext context, NodeList nodeList) throws Exception;
}
