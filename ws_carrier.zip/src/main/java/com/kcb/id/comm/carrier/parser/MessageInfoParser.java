package com.kcb.id.comm.carrier.parser;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.w3c.dom.NodeList;

import com.kcb.id.comm.carrier.loader.MessageInfo;

public interface MessageInfoParser {
	List<MessageInfo> parse(ApplicationContext context,NodeList nodeList) throws Exception;
}
