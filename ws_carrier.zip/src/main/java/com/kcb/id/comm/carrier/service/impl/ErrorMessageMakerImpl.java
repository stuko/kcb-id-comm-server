package com.kcb.id.comm.carrier.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.kcb.id.comm.carrier.common.ByteUtils;
import com.kcb.id.comm.carrier.core.Carrier;
import com.kcb.id.comm.carrier.loader.MessageInfo;
import com.kcb.id.comm.carrier.loader.impl.Field;
import com.kcb.id.comm.carrier.service.ErrorMessageMaker;

@Component
@Primary
public class ErrorMessageMakerImpl implements ErrorMessageMaker{

	static Logger logger = LoggerFactory.getLogger(ErrorMessageMakerImpl.class);
	
	@Override
	public byte[] generate(Carrier carrier, MessageInfo messageInfo, Exception ex) {
		byte[] response = null;
		try {
			String exName = ex.getMessage();
			String errorCode = "";
			String errorMessage = "";
			logger.info("Error Generation : " + exName);
			if(carrier.getErrorInfoLoader().getErrorInfo() != null) {
				// data[0] : CODE
				// data[1] : MESSAGE
				logger.info("ErrorInfoMap exists");
			   String[] data = carrier.getErrorInfoLoader().getErrorInfo().getHeaderErrorValue(exName);
			   // Can not find in Header 
			   if(data == null) {
				   data = carrier.getErrorInfoLoader().getErrorInfo().getMessageErrorValue(exName);
			   }
			   if(data == null) {
				   // 정의되지 않은 예외상황이므로 공통 에러 전문 리턴
				   response = this.generateCommonError(carrier, ex);
			   }else {
				   logger.info("Exception Data is {} ,{}", data[0] , data[1]);
				   // 에러 전문 리턴
				   // 응답전문의 isResCode 속성이 true 인 필드에  CODE 값
				   // 응답전문의 isResMessage 속성이 true 인 필드에  MESSAGE 값
				   Map<String,Object> errorMap = new HashMap<>();
				   errorMap.put("CODE", data[0]);
				   errorMap.put("MESSAGE", data[1]);
				   for(Field f : messageInfo.getResponseMessage().getHeader()) {
					   logger.info("Error Map header put [{}][{}]" , f.getName(), f.getPadChar()==null? "":f.getPadChar());
					   if(f.isResCode())errorMap.put(f.getName(),data[0]);
					   else if(f.isResMessage())errorMap.put(f.getName(),data[1]);
					   else {
						   errorMap.put(f.getName(),f.getPadChar()==null? "":f.getPadChar());
						   f.setRef("");
					   }
				   }
				   for(Field f : messageInfo.getResponseMessage().getBody()) {
					   logger.info("Error Map body put [{}][{}]" , f.getName(), f.getPadChar()==null? "":f.getPadChar());
					   if(f.isResCode())errorMap.put(f.getName(),data[0]);
					   else if(f.isResMessage())errorMap.put(f.getName(),data[1]);
					   else {
						   errorMap.put(f.getName(),f.getPadChar()==null? "":f.getPadChar());
						   f.setRef("");
					   }
				   }
				   for(Field f : messageInfo.getResponseMessage().getTail()) {
					   logger.info("Error Map tail put [{}][{}]" , f.getName(),f.getPadChar()==null? "":f.getPadChar());
					   if(f.isResCode())errorMap.put(f.getName(),data[0]);
					   else if(f.isResMessage())errorMap.put(f.getName(),data[1]);
					   else {
						   errorMap.put(f.getName(),f.getPadChar()==null? "":f.getPadChar());
						   f.setRef("");
					   }
				   }
				   response = ByteUtils.getMessage2Byte(carrier.getApplicationContext(), messageInfo.getResponseMessage(), errorMap);
			   }
			}
		}catch(Exception e) {
			response = this.generateCommonError(carrier, ex);
			logger.error(e.toString(),e);
		}
		return response;
	}
	
	@Override
	public byte[] generateCommonError(Carrier carrier, Exception ex) {
		byte[] response = null;
		try {
			String exName = ex.getMessage();
			String errorCode = "";
			String errorMessage = "";
			// carrier.getErrorInfoLoader().getErrorInfo()
		}catch(Exception e) {
			logger.error(e.toString(),e);
		}
		return response;		
	}
}
