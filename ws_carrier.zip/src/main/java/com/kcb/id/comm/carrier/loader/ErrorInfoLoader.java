package com.kcb.id.comm.carrier.loader;

public interface ErrorInfoLoader extends Loader {
	ErrorInfo getErrorInfo();
	void setErrorInfo(ErrorInfo errorInfo);
}
