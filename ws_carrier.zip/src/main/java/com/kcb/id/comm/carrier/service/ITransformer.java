package com.kcb.id.comm.carrier.service;

import com.kcb.id.comm.carrier.loader.impl.Field;

public interface ITransformer {
	public String byteToString(Field f , byte[] buf) throws Exception;
	public byte[] stringToByte(Field f) throws Exception;
	public int byteToInt(byte[] buf) throws Exception;
	public byte[] intToByte(int src, int size) throws Exception;
}
