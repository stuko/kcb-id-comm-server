package com.kcb.id.comm.carrier.loader.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.kcb.id.comm.carrier.loader.HeaderInfo;
import com.kcb.id.comm.carrier.service.impl.DeEncoderImpl;

public class HeaderInfoImpl extends DeEncoderImpl implements HeaderInfo {
	
	static Logger logger = LoggerFactory.getLogger(HeaderInfoImpl.class);
	
	ApplicationContext applicationContext;
	
	Field[] requestHeader;
	Field[] responseHeader;

	public HeaderInfoImpl() {}
	
	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}
	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}
	public String getRequestValue(String name) {
		for(int i = 0; i < requestHeader.length; i++) {
			if(requestHeader[i].getName().equals(name))return requestHeader[i].getValue();
		}
		return null;
	}
	public String getResponseValue(String name) {
		for(int i = 0; i < responseHeader.length; i++) {
			if(responseHeader[i].getName().equals(name))return responseHeader[i].getValue();
		}
		return null;
	}
	
	public Field[] getRequestHeader() {
		return requestHeader;
	}
	public void setRequestHeader(Field[] requestHeader) {
		this.requestHeader = requestHeader;
	}
	public Field[] getResponseHeader() {
		return responseHeader;
	}
	public void setResponseHeader(Field[] responseHeader) {
		this.responseHeader = responseHeader;
	}
	@Override
	public HeaderInfo newInstance(ApplicationContext context) throws Exception{
		if(context == null) throw new Exception("SpringContextNullException");
		HeaderInfo headerInfo = new HeaderInfoImpl();
		if(requestHeader == null) throw new Exception("RequestHeaderIsNullException");
		headerInfo.setRequestHeader(new Field[requestHeader.length]);
		for(int i = 0; i < requestHeader.length; i++){
			logger.info("##### request header's {}" , requestHeader[i].getName());
			headerInfo.getRequestHeader()[i] = requestHeader[i].newInstance();
		}
		headerInfo.setResponseHeader(new Field[responseHeader.length]);
		for(int i = 0; i < responseHeader.length; i++){
			logger.info("##### response header's {}" , responseHeader[i].getName());
			headerInfo.getResponseHeader()[i] = responseHeader[i].newInstance();
		}
		return headerInfo;
	}
	@Override
	public Map<String, Object> toHashMap() {
		Map<String, Object> map = new HashMap<>();
		map.put("request",this.getRequestHeaderMap());
		map.put("response",this.getResponseHeaderMap());
		return map;
	}	
	
	public Map<String, Object> getRequestHeaderMap() {
		Map<String, Object> map = new HashMap<>();
		for(int i = 0; i < requestHeader.length; i++){
			map.put(requestHeader[i].getName(),requestHeader[i].getValue()) ;
		}
		return map;
	}
	public Map<String, Object> getResponseHeaderMap() {
		Map<String, Object> map = new HashMap<>();
		for(int i = 0; i < responseHeader.length; i++){
			map.put(responseHeader[i].getName(),responseHeader[i].getValue()) ;
		}
		return map;
	}
	@Override
	public String getRequestKindCodeValue() {
		for(int i = 0; i < requestHeader.length; i++) {
			if(requestHeader[i].isKindCode())return requestHeader[i].getValue();
		}
		return null;
	}

	@Override
	public Field decodeAndEncode(Field f) throws Exception {
		return this.decodeAndEncode(this.getApplicationContext(),f, this.toHashMap());
	}
}
