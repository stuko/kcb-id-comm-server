package com.kcb.id.comm.carrier.loader.impl;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.kcb.id.comm.carrier.loader.Message;
import com.kcb.id.comm.carrier.loader.MessageInfo;

public class MessageInfoImpl implements Serializable, Cloneable, MessageInfo {

	private static final long serialVersionUID = 1L;
	static Logger logger = LoggerFactory.getLogger(MessageInfoImpl.class);

	Message requestMessage;
	Message responseMessage;
	String messageName;
	ApplicationContext applicationContext;
	
	public MessageInfoImpl(){}
	
	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	public String getMessageName() {
		return messageName;
	}

	public void setMessageName(String messageName) {
		this.messageName = messageName;
	}

	public Message getRequestMessage() {
		return requestMessage;
	}

	public void setRequestMessage(Message requestMessage) {
		this.requestMessage = requestMessage;
	}

	public Message getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(Message responseMessage) {
		this.responseMessage = responseMessage;
	}

	public MessageInfo newInstance(ApplicationContext context) throws Exception{
		if(context == null) throw new Exception("SpringContextNullException");
		MessageInfo msg = new MessageInfoImpl();
		msg.setApplicationContext(context);
		msg.setRequestMessage(this.getRequestMessage().newInstance(context,msg));		
		msg.setResponseMessage(this.getResponseMessage().newInstance(context,msg));
		msg.setMessageName(this.getMessageName());
		return msg;
	}
	
}
