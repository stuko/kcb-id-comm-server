package com.kcb.id.comm.carrier.loader;

public interface SelfChecker {
	boolean checkMe();
}
