package com.kcb.id.comm.carrier.service;

import com.kcb.id.comm.carrier.core.Carrier;
import com.kcb.id.comm.carrier.loader.MessageInfo;

public interface ErrorMessageMaker {
	public byte[] generate(Carrier carrier, MessageInfo messageInfo, Exception ex);
	public byte[] generateCommonError(Carrier carrier, Exception ex);
}
