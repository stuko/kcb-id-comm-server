package com.kcb.id.comm.carrier.service.impl;

import org.springframework.stereotype.Component;

import com.kcb.id.comm.carrier.loader.impl.Field;
import com.kcb.id.comm.carrier.service.ITransformer;

@Component
public class TransformerImpl implements ITransformer{
	
	@Override
	public String byteToString(Field f , byte[] buf) throws Exception {
		if(f.getType().equals(Field.TYPE.B)) {
			return new String(buf);
		}else if(f.getType().equals(Field.TYPE.C)) {
			return new String(buf);
		}else if(f.getType().equals(Field.TYPE.N)) {
			return new String(buf);
		}else {
			return new String(buf);
		}
	}

	@Override
	public byte[] stringToByte(Field f) throws Exception {
		if(f.getType().equals(Field.TYPE.B)) {
			return f.getValue().getBytes();
		}else if(f.getType().equals(Field.TYPE.C)) {
			return f.getValue().getBytes();
		}else if(f.getType().equals(Field.TYPE.N)) {
			return f.getValue().getBytes();
		}else {
			return f.getValue().getBytes();
		}
	}
	
	@Override
	public int byteToInt(byte[] buf) throws Exception {
		/*
		 int result = ((0xff & buf[0]) << 24) | ((0xff & buf[1]) << 16) | ((0xff & buf[2]) << 8) | ((0xff & buf[3]));
		 return result;
		 */
		
		return Integer.valueOf(new String(buf).trim());
	}
	
	@Override
	public byte[] intToByte(int src, int size) throws Exception {
		/*
		 // ignore byte order
		 return ByteBuffer.allocate(size).putInt(src).array();
		 // order platform's byteorder
		 return ByteBuffer.allocate(size).order(ByteOrder.nativeOrder()).putInt(src).array();
		 */
		// default 4 byte
		return new byte[] {(byte)(src >>> 24),(byte)(src >>> 16),(byte)(src >>> 8),(byte)(src) };
		
	}

}
