package com.kcb.id.comm.carrier.service;

import java.util.Map;

import org.springframework.context.ApplicationContext;

import com.kcb.id.comm.carrier.loader.impl.Field;

public interface DeEncoder {
	Field decodeAndEncode(ApplicationContext context, Field f, Map<String,Object> msg) throws Exception;
}
