package com.kcb.id.comm.carrier.loader;

import org.springframework.context.ApplicationContext;

public interface ApplicationReferBean {
	ApplicationContext getApplicationContext();
	void setApplicationContext(ApplicationContext applicationContext);
}
