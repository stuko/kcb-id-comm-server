package com.kcb.id.comm.carrier.service;

import java.util.Map;

public interface IService {
	Object call(Map<String,Object> param);
}
