package com.kcb.id.comm.carrier.loader;

public interface HeaderInfoLoader extends Loader {
	HeaderInfo getHeaderInfo();
	void setHeaderInfo(HeaderInfo headerInfo);
}
