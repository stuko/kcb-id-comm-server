package com.kcb.id.comm.carrier.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.kcb.id.comm.carrier.loader.impl.Field;
import com.kcb.id.comm.carrier.service.Cypher;
import com.kcb.id.comm.carrier.service.DeEncoder;

@Component
public class DeEncoderImpl implements DeEncoder {

	@Override
	public Field decodeAndEncode(ApplicationContext context, Field f, Map<String,Object> msg) throws Exception {
		try {
			if(f.getDecoder() != null && !"".equals(f.getDecoder())) {
				if(context == null) throw new Exception("SpringContextNullException");
				Object object = context.getBean(f.getDecoder());
				if(object != null) {
					Cypher cypher = (Cypher)object;
					f.setValue(cypher.decode(f.getValue(),msg));
				}else {
					throw new Exception("DecoderBeanDoesNotExistException ["+f.getDecoder()+"]");
				}
			}
			if(f.getEncoder() != null && !"".equals(f.getEncoder())) {
				Object object = context.getBean(f.getEncoder());
				if(object != null) {
					Cypher cypher = (Cypher)object;
					f.setValue(cypher.encode(f.getValue(),msg));
				}else {
					throw new Exception("EncoderBeanDoesNotExistException ["+f.getEncoder()+"]");
				}
			}

		}catch(Exception e) {
			throw new Exception("NoDecoderOrEncoderException");
		}
		return f;
	}

}
