package com.kcb.id.comm.carrier.parser;

import org.springframework.context.ApplicationContext;
import org.w3c.dom.NodeList;

import com.kcb.id.comm.carrier.loader.HeaderInfo;

public interface HeaderInfoParser {
	HeaderInfo parse(ApplicationContext context, NodeList nodeList) throws Exception;
}
