package com.kcb.id.comm.carrier.loader;

import java.util.Map;

import org.springframework.context.ApplicationContext;

import com.kcb.id.comm.carrier.loader.impl.Field;

public interface HeaderInfo extends ApplicationReferBean {
	String getRequestValue(String name);
	String getRequestKindCodeValue();
	String getResponseValue(String name);
	Field[] getRequestHeader();
	void setRequestHeader(Field[] header);
	Field[] getResponseHeader();
	void setResponseHeader(Field[] header);
	Map<String,Object> toHashMap();
	Field decodeAndEncode(Field f) throws Exception;
	HeaderInfo newInstance(ApplicationContext applicationContext) throws Exception;
}
