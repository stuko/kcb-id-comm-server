package com.kcb.id.comm.carrier.loader.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.w3c.dom.NodeList;

import com.kcb.id.comm.carrier.loader.MessageInfo;
import com.kcb.id.comm.carrier.loader.MessageInfoLoader;
import com.kcb.id.comm.carrier.parser.MessageInfoParser;

@Component
@Scope("prototype")
public class MessageInfoLoaderImpl extends LoaderImpl  implements MessageInfoLoader {

	static Logger logger = LoggerFactory.getLogger(MessageInfoLoaderImpl.class);
	@Autowired
	MessageInfoParser parser;
	Map<String, MessageInfo> messageRepository = new HashMap<>();

	public MessageInfoParser getParser() {
		return parser;
	}

	public void setParser(MessageInfoParser parser) {
		this.parser = parser;
	}

	public Map<String, MessageInfo> getMessageRepository() {
		return messageRepository;
	}

	public void setMessageRepository(Map<String, MessageInfo> messageRepository) {
		this.messageRepository = messageRepository;
	}

	@Override
	public void parseMe(ApplicationContext context, NodeList nodeList){
		try {
			List<MessageInfo> list = this.getParser().parse(context, nodeList);
			logger.info("##### message count " + list.size());
			if (list != null && list.size() > 0) {
				list.forEach(message->{
					logger.info("##### message name " + message.getMessageName());
					this.getMessageRepository().put(message.getMessageName(),message);
				});
			} 
		} catch (Exception e) {
			logger.error(e.toString(),e);
		}
	}

	@Override
	public MessageInfo getMessageInfo(String kindCode, String messageCode) throws Exception {
		MessageInfo messageInfo = null;
		for(String k : this.getMessageRepository().keySet()){
			logger.info("message kind = {}, msg = {} " ,this.getMessageRepository().get(k).getRequestMessage().getKindCode(),this.getMessageRepository().get(k).getRequestMessage().getMessageCode()  );
			if(kindCode.equals(this.getMessageRepository().get(k).getRequestMessage().getKindCode())
			&& messageCode.equals(this.getMessageRepository().get(k).getRequestMessage().getMessageCode())) {
				messageInfo = this.getMessageRepository().get(k);
			}
		}
		return messageInfo;
	}

}
