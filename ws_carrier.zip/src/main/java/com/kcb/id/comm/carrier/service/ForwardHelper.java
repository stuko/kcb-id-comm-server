package com.kcb.id.comm.carrier.service;

import java.util.Map;

public interface ForwardHelper {
	String[] findForwardInfo(Map<String,Object> bodyMap) throws Exception;
}
