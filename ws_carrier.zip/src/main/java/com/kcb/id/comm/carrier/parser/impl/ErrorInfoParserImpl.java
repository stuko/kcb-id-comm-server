package com.kcb.id.comm.carrier.parser.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kcb.id.comm.carrier.loader.ErrorInfo;
import com.kcb.id.comm.carrier.loader.impl.ErrorInfoImpl;
import com.kcb.id.comm.carrier.loader.impl.Field;
import com.kcb.id.comm.carrier.parser.ErrorInfoParser;

@Component
public class ErrorInfoParserImpl implements ErrorInfoParser{

	static Logger logger = LoggerFactory.getLogger(ErrorInfoParserImpl.class);

	public ErrorInfo parse(ApplicationContext context, NodeList nodeList) throws Exception{
		ErrorInfo errorInfo = new ErrorInfoImpl();
		logger.info("Error First Child Node Name :" + nodeList.item(0).getNodeName());
		NodeList setNodeList = nodeList.item(0).getChildNodes();
		for (int i = 0; i < setNodeList.getLength(); i++) {
			if (setNodeList.item(i) == null)
				continue;
			if (setNodeList.item(i).getNodeType() == Node.TEXT_NODE)
				continue;
			Node node = setNodeList.item(i);
			
			boolean isHeader = false;
			
			if(node.getNodeName().equals("headers")) {
				logger.info("Find Header Error Node !!!!");
				isHeader = true;				
			}else if(node.getNodeName().equals("messages")) {
				logger.info("Find Message Error Node !!!!");						
				isHeader = false;
			}
			
			logger.info("Error Second Child Node Name :" + node.getNodeName());
			if(node.hasChildNodes()) {
				NodeList subNodeList = node.getChildNodes();
				for(int j = 0; j < subNodeList.getLength(); j++) {
					if (subNodeList.item(j) == null)
						continue;
					if (subNodeList.item(j).getNodeType() == Node.TEXT_NODE)
						continue;
					if(subNodeList.item(j).getNodeName().equals("error")) {
						FieldParser parser = new FieldParser();
						logger.info("Error Head or Message's Child Node Name : " + subNodeList.item(j).getNodeName());
						errorInfo = parser.parseErrorField(errorInfo, subNodeList.item(j) , isHeader);
					}
					
				}
			}
		}
			
		return errorInfo;
	}

	private ErrorInfo getErrorInfo(NodeList subNodeList, int j , boolean isHeader) throws Exception{
		ErrorInfo errorInfo = new ErrorInfoImpl();
		NodeList subSubNodeList = subNodeList.item(j).getChildNodes();
		FieldParser parser = null;
		for (int k = 0; k < subSubNodeList.getLength(); k++) {
			if (subSubNodeList.item(j) == null)
				continue;
			if (subSubNodeList.item(j).getNodeType() == Node.TEXT_NODE)
				continue;
			Field[] fields = null;
			Node subSubNode = subSubNodeList.item(k);
			parser = new FieldParser();
			logger.info("Error Head or Message's Child Node Name : " + subSubNode.getNodeName());
			errorInfo = parser.parseErrorField(errorInfo, subSubNode , isHeader);
		}
		return errorInfo;
	}

}
