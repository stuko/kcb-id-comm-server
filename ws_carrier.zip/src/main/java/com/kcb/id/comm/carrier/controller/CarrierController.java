package com.kcb.id.comm.carrier.controller;

import java.io.ByteArrayInputStream;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.kcb.id.comm.carrier.common.ByteUtils;
import com.kcb.id.comm.carrier.core.Carrier;
import com.kcb.id.comm.carrier.loader.HeaderInfo;
import com.kcb.id.comm.carrier.loader.MessageInfo;
import com.kcb.id.comm.carrier.loader.impl.Field;
import com.kcb.id.comm.carrier.service.DeEncoder;
import com.kcb.id.comm.carrier.service.ErrorMessageMaker;
import com.kcb.id.comm.carrier.service.ForwardHelper;
import com.kcb.id.comm.carrier.service.IService;
import com.kcb.id.comm.carrier.service.ITransformer;


@RestController
@RequestMapping("/carrier")
public class CarrierController {
	
	static Logger logger = LoggerFactory.getLogger(CarrierController.class);
	
	@Autowired
	Carrier carrier;

	@Autowired
	ForwardHelper forwardHelper;

	@Autowired
	ITransformer transformer;
	
	@Autowired
	ErrorMessageMaker errorMessageMaker;

	@RequestMapping(value="/request" , method= RequestMethod.POST, consumes = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
	public byte[] request(@RequestBody byte[] msg) throws Exception{
		byte[] response = null;
		MessageInfo messageInfo = null;
		try {
			messageInfo = this.parseRequestMessage(msg);
			if(messageInfo == null) throw new Exception("MessageInfoErrorException");
		
			String preBean = messageInfo.getRequestMessage().getPreBean();
			logger.info("############### request's prebean is {} " , preBean);
			Map<String,Object> bodyMap = messageInfo.getRequestMessage().getBodyMap();
			bodyMap.putAll(messageInfo.getRequestMessage().getHeaderMap());
			bodyMap.putAll(messageInfo.getRequestMessage().getTailMap());
			Map<String,Object> result = this.execute(preBean,bodyMap);
			if(result != null) bodyMap.putAll(result);
			
			boolean isForward = false;
			
			if(forwardHelper == null) throw new Exception("ForwardHelperDoesNotExistException");
			
			String[] info = forwardHelper.findForwardInfo(bodyMap);
			if(info != null) {
				if((info.length == 5) || (info.length == 4) || (info.length == 3)) {
					messageInfo.getRequestMessage().setForwardIp(info[0]);
					messageInfo.getRequestMessage().setForwardPort(info[1]);
					messageInfo.getRequestMessage().setForwardTimeOut(info[2]);
					if(info.length == 4) messageInfo.getRequestMessage().setForwardMessageName(info[3]);
					if(info.length == 5) {
						messageInfo.getRequestMessage().setKindCode(info[3]);
						messageInfo.getRequestMessage().setMessageCode(info[4]);
					}
				}else {
					throw new Exception("ForwardMessageInformationDoseNotOKException");
				}
			}else {
				logger.info("########### Forward info is Null");
			}
			
			if(messageInfo.getRequestMessage().getForwardIp() != null
			&& !"".equals(messageInfo.getRequestMessage().getForwardIp())
			&& messageInfo.getRequestMessage().getForwardPort() != null
			&& !"".equals(messageInfo.getRequestMessage().getForwardPort())
			&& messageInfo.getRequestMessage().getForwardTimeOut() != null
			&& !"".equals(messageInfo.getRequestMessage().getForwardTimeOut())
			) {
				isForward = true;
			}
			
			byte[] forwardResponse = null;
			MessageInfo forward = null;
			
			if(messageInfo.getRequestMessage().getForwardMessageName() != null
			&& !"".equals(messageInfo.getRequestMessage().getForwardMessageName())) {
				try {
					forward = carrier.getMessageInfoLoader().getMessageRepository().get(messageInfo.getRequestMessage().getForwardMessageName()).newInstance(carrier.getApplicationContext());
				}catch(Exception e) {
					new Exception("ForwardMessageCanNotFindException ["+messageInfo.getRequestMessage().getForwardMessageName()+"]");
				}
			}else if(messageInfo.getRequestMessage().getKindCode() != null
			&& !"".equals(messageInfo.getRequestMessage().getKindCode())
			&& messageInfo.getRequestMessage().getMessageCode() != null
			&& !"".equals(messageInfo.getRequestMessage().getMessageCode())
			) {
				try {
					forward = carrier.getMessageInfoLoader().getMessageInfo(messageInfo.getRequestMessage().getKindCode(), messageInfo.getRequestMessage().getMessageCode()).newInstance(carrier.getApplicationContext());
				}catch(Exception e) {
					new Exception("ForwardMessageCanNotFindException ["+messageInfo.getRequestMessage().getKindCode()+"],["+messageInfo.getRequestMessage().getMessageCode()+"]");
				}
			}
			
			if(forward != null) {
				forward.getRequestMessage().setHeader(messageInfo.getRequestMessage().getHeader());
				forward.getResponseMessage().setHeader(messageInfo.getResponseMessage().getHeader());
				
				String forwardPreBean = forward.getRequestMessage().getPreBean();
				result = this.execute(forwardPreBean,bodyMap);
				if(result != null) bodyMap.putAll(result);
				
				// 포워드 전에 현재 데이터를 바인딩해 준다.
				byte[] forwardBytes = ByteUtils.getMessage2Byte(carrier.getApplicationContext(),forward.getRequestMessage(),bodyMap);
				if(isForward) {
					try {
						forwardResponse = ByteUtils.send(messageInfo.getRequestMessage().getForwardIp()
								, Integer.parseInt(messageInfo.getRequestMessage().getForwardPort())
								, Integer.parseInt(messageInfo.getRequestMessage().getForwardTimeOut())
								, forwardBytes);
					}catch(Exception e) {
						throw new Exception("MessageAndForwardException ["+forward.getMessageName()+"]["+messageInfo.getRequestMessage().getForwardIp()+"]");
					}
					mergeForwardResponse(forward, bodyMap, forwardResponse);
				}
				// 포워드 성공후에 데이터를 바인딩 해준다.
				String forwardPostBean = forward.getRequestMessage().getPostBean();
				result = this.execute(forwardPostBean,bodyMap);
				if(result != null) bodyMap.putAll(result);
			}else {
				if(isForward) {
					try {
						forwardResponse = ByteUtils.send(messageInfo.getRequestMessage().getForwardIp()
							, Integer.parseInt(messageInfo.getRequestMessage().getForwardPort())
							, Integer.parseInt(messageInfo.getRequestMessage().getForwardTimeOut())
							, msg);
					}catch(Exception e) {
						throw new Exception("MessageForwardException ["+messageInfo.getMessageName()+"]["+messageInfo.getRequestMessage().getForwardMessageName()+"]["+messageInfo.getRequestMessage().getForwardIp()+"]");
					}
					mergeForwardResponse(messageInfo, bodyMap, forwardResponse);
				}
			}
				
			String postBean = messageInfo.getRequestMessage().getPostBean();
			logger.info("############### request's postbean is {} " , preBean);
			result = this.execute(preBean,bodyMap);
			if(result != null) bodyMap.putAll(result);
			
			logger.info("response body map : [{}]",bodyMap);
			
			logger.info("response header structure : [{}]",messageInfo.getResponseMessage().getHeaderMap());
			logger.info("response body structure : [{}]",messageInfo.getResponseMessage().getBodyMap());
			logger.info("response tail structure : [{}]",messageInfo.getResponseMessage().getTailMap());
			
			response = ByteUtils.getMessage2Byte(carrier.getApplicationContext(), messageInfo.getResponseMessage(),bodyMap);
			
		}catch(Exception e) {
			// logger.error(e.toString(),e);
			if(messageInfo != null) {
				try{response = errorMessageMaker.generate(carrier, messageInfo, e );}
				catch(Exception ee) {logger.error(ee.toString(),ee);}
			}else {
				// 전문오류이므로 공통 전문 전송해야 함.
				try{response = errorMessageMaker.generateCommonError(carrier, e );}
				catch(Exception ee) {logger.error(ee.toString(),ee);}
			}
		}
		return response;
	}

	private void mergeForwardResponse(MessageInfo messageInfo, Map<String, Object> bodyMap, byte[] forwardResponse)
			throws Exception {
		if(forwardResponse != null) {
			logger.info("Forward Message is not null...................");
			MessageInfo forwardResult = parseResponseMessage(forwardResponse
					,carrier.getMessageInfoLoader().getMessageRepository().get(messageInfo.getRequestMessage().getForwardMessageName()));
			bodyMap.putAll(forwardResult.getResponseMessage().getBodyMap());
		}
	}
	
	private Map<String,Object> execute(String beanName,Map<String,Object> bodyMap) throws Exception {
		if(beanName != null && !"".equals(beanName)) {
			IService service = (IService) carrier.getApplicationContext().getBean(beanName);
			if(service == null)throw new Exception("ServiceBeanDoesNotExistException ["+beanName+"]");
			logger.info("Service calling ......");
			Object result = service.call(bodyMap);
			logger.info("Service called ......");
			if(result != null) {
				return (Map<String,Object>)result;
			}
		}
		return null;
	}
	
	private byte[] makeErrorResponse(Exception e , MessageInfo messageInfo) {
		byte[] responseError = null;
		try {
			
		}catch(Exception ex) {
			
		}
		return responseError;
	}

	public MessageInfo parseRequestMessage(byte[] in) throws Exception {

		ByteArrayInputStream bais = new ByteArrayInputStream(in);
		String msgCode = "";
		if(bais.available() <= 0) {
			throw new Exception("MessageLengthNotEqualException ["+bais.available()+"]");
		}
		if(carrier.getHeaderInfoLoader() == null) {
			throw new Exception("NoHeaderInfoLoaderException");
		}
		if(carrier.getHeaderInfoLoader().getHeaderInfo() == null) {
			throw new Exception("NoHeaderInfoException");
		}
		
		//--------------------------------------
		// HeaderInfo는 신규 카피된 객체 임
		//--------------------------------------		
		HeaderInfo headerInfo = carrier.getHeaderInfoLoader().getHeaderInfo().newInstance(carrier.getApplicationContext());
		Field headers[] = headerInfo.getRequestHeader();
		for (int i = 0; i < headers.length; i++) {
			Field f = headers[i];
			byte[] buf = new byte[Integer.parseInt(f.getLength())];
			logger.info("request header of {} 's is TotalLength ? {} ", f.getName(), f.isTotalLength());
			logger.info("request header of {} 's length is {} ", f.getName(), buf.length);
			bais.read(buf);
			String value = transformer.byteToString(f, buf);
			f.setValue(value);
			f = headerInfo.decodeAndEncode(f);
			logger.info("request header's name: {} , value: [{}]", f.getName() , f.getValue());
		}
		headers = headerInfo.getResponseHeader();
		for (int i = 0; i < headers.length; i++) {
			Field f = headers[i];
			logger.info("response header of {} 's is TotalLength ? {} ", f.getName(), f.isTotalLength());
			logger.info("response header's name: {} , value: [{}]", f.getName() , f.getValue());
		}
		//-----------------------------------------
		// 하드코딩 ^^
		//-----------------------------------------
		String kindCode = headerInfo.getRequestKindCodeValue();
		if(kindCode == null || "".equals(kindCode)) throw new Exception("HeaderDoesNotContainsKindCodeException");
		//-----------------------------------------
		// 하드코딩 ^^ : 바디부분의 4자리 필수 읽어야 함.
		//-----------------------------------------		
		byte[] msgCodeBytes = new byte[4];
		bais.read(msgCodeBytes);
		String messageCode = new String(msgCodeBytes);
		
		MessageInfo findMessageInfo = carrier.getMessageInfoLoader().getMessageInfo(kindCode, messageCode);
		if(findMessageInfo == null) throw new Exception("CanNotFindMessageException ["+kindCode+"]["+messageCode+"]");

		MessageInfo newMsg = findMessageInfo.newInstance(carrier.getApplicationContext());
		try {
			//-------------------------------------
			// 이미 읽은 헤더 부분과 응답헤더부분을 저장
			//-------------------------------------
			newMsg.getRequestMessage().setHeader(headerInfo.getRequestHeader());
			newMsg.getResponseMessage().setHeader(headerInfo.getResponseHeader());

			//-------------------------------------
			// 이미 읽은 메시지 코드
			// 하드코딩 ^^ : 바디부분의 4자리 
			//-------------------------------------
			newMsg.getRequestMessage().getBody()[0].setValue(messageCode);
			
			// 이제부터는 새로운 메시지 newMsg 정보를 사용해야 함.
			Field[] header = newMsg.getRequestMessage().getHeader();
			Field[] body = newMsg.getRequestMessage().getBody();
			Field[] tail = newMsg.getRequestMessage().getTail();
			
			for (int i = 1; i < body.length; i++) {
				Field f = body[i];
				byte[] buf = new byte[newMsg.getRequestMessage().getLength(f,newMsg.getRequestMessage())];
				logger.info("request body of {} 's length is {} ", f.getName(), buf.length);
				bais.read(buf);
				String value = transformer.byteToString(f, buf);
				logger.info("request body of {} 's raw value is {} ", f.getName(), new String(buf));
				logger.info("request body of {} 's value is {} ", f.getName(), value);
				f.setValue(value);
				newMsg.getRequestMessage().decodeAndEncode(f);
				logger.info("body's name: {} , value: [{}]", f.getName() , f.getValue());
			}

			for (int i = 0; i < tail.length; i++) {
				Field f = tail[i];
				byte[] buf = new byte[newMsg.getRequestMessage().getLength(f,newMsg.getRequestMessage())];
				logger.info("request tail of {} 's length is {} ", f.getName(), buf.length);
				bais.read(buf);
				String value = transformer.byteToString(f, buf);
				logger.info("request tail of {} 's raw value is {} ", f.getName(), new String(buf));
				logger.info("request tail of {} 's value is {} ", f.getName(), value);
				f.setValue(value);
				newMsg.getRequestMessage().decodeAndEncode(f);
				logger.info("tail's name: {} , value: [{}]", f.getName() , f.getValue());				
			}
			bais.close();
			bais = null;
		} catch (Exception e) {
			throw new Exception("RequestMessageParseException [" + e.getStackTrace()[0].getClassName() + ":" + e.getStackTrace()[0].getLineNumber() + "]", e);
		} finally {
			try {if (bais != null)bais.close();} catch (Exception e) {}
		}
		return newMsg;
	}
	
	public MessageInfo parseResponseMessage(byte[] in , MessageInfo responseMessageInfo) throws Exception {

		ByteArrayInputStream bais = new ByteArrayInputStream(in);
		byte[] remains = bais.readAllBytes();
		
		HeaderInfo headerInfo = carrier.getHeaderInfoLoader().getHeaderInfo().newInstance(carrier.getApplicationContext());
		Field headers[] = headerInfo.getResponseHeader();
		for (int i = 0; i < headers.length; i++) {
			Field f = headers[i];
			byte[] buf = new byte[Integer.parseInt(f.getLength())];
			logger.info("response header of {} 's length is {} ", f.getName(), buf.length);
			bais.read(buf);
			String value = transformer.byteToString(f, buf);
			logger.info("response header of {} 's raw value is {} ", f.getName(), new String(buf));
			logger.info("response header of {} 's value is {} ", f.getName(), value);
			f.setValue(value);
			f = ((DeEncoder)headerInfo).decodeAndEncode(carrier.getApplicationContext(), f,headerInfo.toHashMap());
			logger.info("header's name: {} , value: [{}]", f.getName() , f.getValue());
		}
		MessageInfo newMsg = responseMessageInfo.newInstance(carrier.getApplicationContext());
		try {
			// 이미 읽은 헤더 부분
			newMsg.getResponseMessage().setHeader(headerInfo.getResponseHeader());
			// 이제부터는 새로운 메시지 newMsg 정보를 사용해야 함.
			Field[] header = newMsg.getResponseMessage().getHeader();
			Field[] body = newMsg.getResponseMessage().getBody();
			Field[] tail = newMsg.getResponseMessage().getTail();

			for (int i = 0; i < body.length; i++) {
				Field f = body[i];
				byte[] buf = new byte[newMsg.getResponseMessage().getLength(f,newMsg.getResponseMessage())];
				logger.info("response body of {} 's length is {} ", f.getName(), buf.length);
				bais.read(buf);
				String value = transformer.byteToString(f, buf);
				logger.info("response body of {} 's raw value is {} ", f.getName(), new String(buf));
				logger.info("response body of {} 's value is {} ", f.getName(), value);
				f.setValue(value);
				newMsg.getResponseMessage().decodeAndEncode(f);
				logger.info("body's name: {} , value: [{}]", f.getName() , f.getValue());
			}

			for (int i = 0; i < tail.length; i++) {
				Field f = tail[i];
				byte[] buf = new byte[newMsg.getResponseMessage().getLength(f,newMsg.getResponseMessage())];
				logger.info("response tail of {} 's length is {} ", f.getName(), buf.length);
				bais.read(buf);
				String value = transformer.byteToString(f, buf);
				logger.info("response tail of {} 's raw value is {} ", f.getName(), new String(buf));
				logger.info("response tail of {} 's value is {} ", f.getName(), value);
				f.setValue(value);
				newMsg.getResponseMessage().decodeAndEncode(f);
				logger.info("tail's name: {} , value: [{}]", f.getName() , f.getValue());				
			}
			bais.close();
			bais = null;
		} catch (Exception e) {
			throw new Exception("ResponseMessageParseException [" + e.getStackTrace()[0].getClassName() + ":" + e.getStackTrace()[0].getLineNumber() + "]", e);
		} finally {
			try {if (bais != null)bais.close();} catch (Exception e) {}
		}
		return newMsg;
	}
}
