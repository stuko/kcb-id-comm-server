package com.kcb.id.comm.carrier.loader;

import org.springframework.context.ApplicationContext;

public interface MessageInfo{

	String getMessageName();
	void setMessageName(String messageName);
	
	Message getRequestMessage();
	void setRequestMessage(Message requestMessage);
	
	Message getResponseMessage();
	void setResponseMessage(Message responseMessage);
	
	ApplicationContext getApplicationContext();
	void setApplicationContext(ApplicationContext context);
	
	MessageInfo newInstance(ApplicationContext applicationContext) throws Exception;
	
}