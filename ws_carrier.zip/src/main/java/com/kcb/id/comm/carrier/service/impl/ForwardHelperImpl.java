package com.kcb.id.comm.carrier.service.impl;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.kcb.id.comm.carrier.service.ForwardHelper;

@Component
public class ForwardHelperImpl implements ForwardHelper {

	@Override
	public String[] findForwardInfo(Map<String, Object> bodyMap) throws Exception {
		String[] result = new String[5];
		result[0] = "127.0.0.1";
		result[1] = "8081";
		result[2] = "10000";
		result[3] = "KIND";
		result[4] = "CODE3";
		return result;
	}

}
