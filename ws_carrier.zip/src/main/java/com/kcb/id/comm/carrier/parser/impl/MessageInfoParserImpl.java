package com.kcb.id.comm.carrier.parser.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.kcb.id.comm.carrier.loader.Message;
import com.kcb.id.comm.carrier.loader.MessageInfo;
import com.kcb.id.comm.carrier.loader.impl.Field;
import com.kcb.id.comm.carrier.loader.impl.MessageImpl;
import com.kcb.id.comm.carrier.loader.impl.MessageInfoImpl;
import com.kcb.id.comm.carrier.parser.MessageInfoParser;

@Component
@Scope("prototype")
public class MessageInfoParserImpl implements MessageInfoParser {

	static Logger logger = LoggerFactory.getLogger(MessageInfoParserImpl.class);

	public List<MessageInfo> parse(ApplicationContext context, NodeList nodeList) throws Exception{
		List<MessageInfo> list = new ArrayList<>();
		NodeList setNodeList = nodeList.item(0).getChildNodes();
		for (int i = 0; i < setNodeList.getLength(); i++) {
			if (setNodeList.item(i).getNodeType() == Node.TEXT_NODE)
				continue;
			MessageInfo receiverInfo = new MessageInfoImpl();
			receiverInfo.setApplicationContext(context);
			
			Node node = setNodeList.item(i);
			receiverInfo.setMessageName(node.getAttributes().getNamedItem("messageName") == null ? "" : node.getAttributes().getNamedItem("messageName").getNodeValue());
			
			if (receiverInfo.getMessageName() == null) {
				throw new Exception("MessageNameDoesNotExistException");
			}
			
			NodeList subNodeList = node.getChildNodes();
			for (int j = 0; j < subNodeList.getLength(); j++) {
				if (subNodeList.item(j).getNodeType() == Node.TEXT_NODE)
					continue;
				
				if (subNodeList.item(j).getNodeName().equals("request")) {
					receiverInfo.setRequestMessage(getMessage(context, receiverInfo, subNodeList, j , true));
					logger.info("request kind code is " + receiverInfo.getRequestMessage().getKindCode());
					logger.info("request message code is " + receiverInfo.getRequestMessage().getMessageCode());
					logger.info("request messageName is " + receiverInfo.getMessageName());
					logger.info("request preBean is " + receiverInfo.getRequestMessage().getPreBean());
				} else if (subNodeList.item(j).getNodeName().equals("response")) {
					receiverInfo.setResponseMessage(getMessage(context, receiverInfo, subNodeList, j, false));
					logger.info("response kind code is " + receiverInfo.getResponseMessage().getKindCode());
					logger.info("response message code is " + receiverInfo.getResponseMessage().getMessageCode());
					logger.info("response messageName is " + receiverInfo.getMessageName());
					logger.info("response preBean is " + receiverInfo.getResponseMessage().getPreBean());
				}
			}
			logger.info("#####################################");
			logger.info("NAME : {}", receiverInfo.getMessageName());
			logger.info("PRE BEAN : {}", receiverInfo.getRequestMessage().getPreBean());
			logger.info("POST BEAN : {}", receiverInfo.getRequestMessage().getPostBean());			
			logger.info("#####################################");
			list.add(receiverInfo);
			
		}
		return list;
	}

	private Message getMessage(ApplicationContext context, MessageInfo receiverInfo, NodeList subNodeList, int j , boolean isRequest) throws Exception{
		Message parsedMsg = new MessageImpl(receiverInfo);
		parsedMsg.setApplicationContext(context);
		// parsedMsg.setMessageName(subNodeList.item(j).getAttributes().getNamedItem("messageName") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("messageName").getNodeValue());
		parsedMsg.setForwardMessageName(subNodeList.item(j).getAttributes().getNamedItem("forwardMessageName") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("forwardMessageName").getNodeValue());
		parsedMsg.setForwardIp(subNodeList.item(j).getAttributes().getNamedItem("forwardIp") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("forwardIp").getNodeValue());
		parsedMsg.setForwardPort(subNodeList.item(j).getAttributes().getNamedItem("forwardPort") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("forwardPort").getNodeValue());		
		parsedMsg.setForwardTimeOut(subNodeList.item(j).getAttributes().getNamedItem("forwardTimeOut") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("forwardTimeOut").getNodeValue());		
		parsedMsg.setKindCode(subNodeList.item(j).getAttributes().getNamedItem("kindCode") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("kindCode").getNodeValue());
		parsedMsg.setMessageCode(subNodeList.item(j).getAttributes().getNamedItem("messageCode") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("messageCode").getNodeValue());
		parsedMsg.setPreBean(subNodeList.item(j).getAttributes().getNamedItem("preBean") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("preBean").getNodeValue());
		parsedMsg.setPostBean(subNodeList.item(j).getAttributes().getNamedItem("postBean") == null ? "" 	: subNodeList.item(j).getAttributes().getNamedItem("postBean").getNodeValue());
		
		String gubun = isRequest ? "request" : "response";
		
		logger.info("getMessage>>>>>>> "+gubun+" kind code is " + parsedMsg.getKindCode());
		logger.info("getMessage>>>>>>> "+gubun+" message code is " +parsedMsg.getMessageCode());
		logger.info("getMessage>>>>>>> "+gubun+" preBean is " + parsedMsg.getPreBean());
		
		
		NodeList subSubNodeList = subNodeList.item(j).getChildNodes();
		FieldParser parser = null;
		for (int k = 0; k < subSubNodeList.getLength(); k++) {
			if (subSubNodeList.item(j) == null)
				continue;
			if (subSubNodeList.item(j).getNodeType() == Node.TEXT_NODE)
				continue;
			Field[] fields = null;
			Node subSubNode = subSubNodeList.item(k);
			parser = new FieldParser();
			parsedMsg = parser.parseMessageFields(parsedMsg, subSubNode, isRequest);
		}
		return parsedMsg;
	}


}
