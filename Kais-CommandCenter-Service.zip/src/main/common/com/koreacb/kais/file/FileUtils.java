package com.koreacb.kais.file;

public class FileUtils {
	
	String delim;
	boolean includeHeader;
	String fileName;
	
	public String getDelim() {
		return delim;
	}
	public void setDelim(String delim) {
		this.delim = delim;
	}
	public boolean isIncludeHeader() {
		return includeHeader;
	}
	public void setIncludeHeader(boolean includeHeader) {
		this.includeHeader = includeHeader;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	
}
