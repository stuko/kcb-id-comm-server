package com.koreacb.kais.mybatis;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.executor.BatchResult;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MyBatisUtils{
	
	SqlSession session;
	long batchSize = 1000;
	boolean batch;
	long executeCount;
	
	public MyBatisUtils(boolean isBatch) {
		try {
				this.setBatch(isBatch);
				if(this.getSession() == null) {
					if(isBatch)
						this.setSession(this.getSqlSessionFactory().openSession(ExecutorType.BATCH));
					else
						this.setSession(this.getSqlSessionFactory().openSession());
				}
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}
	
	public MyBatisUtils(String env,boolean isBatch) {
		try {
				this.setBatch(isBatch);
				if(this.getSession() == null) {
					if(isBatch)
						this.setSession(this.getSqlSessionFactory(env).openSession(ExecutorType.BATCH));
					else
						this.setSession(this.getSqlSessionFactory(env).openSession());
				}
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}
	
	
	
	public long getExecuteCount() {
		return executeCount;
	}

	public void setExecuteCount(long executeCount) {
		this.executeCount = executeCount;
	}

	public boolean isBatch() {
		return batch;
	}

	public void setBatch(boolean batch) {
		this.batch = batch;
	}

	public long getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(long batchSize) {
		this.batchSize = batchSize;
	}

	public void clear() {
		// 2018.08.22
		// 배치 모드로 인서트를 한 경우, 
		// 인서트 건이 마지막 batch size 보다 적은 경우, 해당 건을 commit 해줘야 함.
		if(this.executeCount > 0) {this.commit();}
		this.getSession().close();
	}
	
	public void setSession(SqlSession session) {
		this.session = session;
	}

	public SqlSession getSession(){
		return this.session;
	}
	
	public SqlSessionFactory getSqlSessionFactory() throws Exception{
		return getSqlSessionFactory(null);
	}
	
	private SqlSessionFactory getSqlSessionFactory(String env) throws Exception{
		String resource = "config.xml";
		InputStream is = Resources.getResourceAsStream(resource);
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
		SqlSessionFactory factory = null;
		if(env != null) factory = builder.build(is,env);
		else factory = builder.build(is);
		return factory;
	}

	public List<Map<String,Object>> select(String sqlName , Map<String,Object> parameter) throws Exception{
		List<Map<String,Object>> result = this.getSession().selectList(sqlName, parameter);
		return result;
	}
	
	public boolean insert(String sqlName, Map<String,Object> parameter) throws Exception{
		if(this.isBatch()) {
			this.executeCount++;
			this.getSession().insert(sqlName, parameter);
			if(this.getExecuteCount() >= this.getBatchSize()) {
				flushBatch();
				this.commit();
			}
		}else {
			this.getSession().insert(sqlName, parameter);
			this.commit();
		}
		return true;
	}

	private void flushBatch() {
		this.setExecuteCount(0);
		List<BatchResult> result = this.getSession().flushStatements();
		result.clear();
		this.getSession().clearCache();
	}
	
	public void commit() {
		// 2018.08.22
		// 배치 모드로 인서트를 한 경우, 
		// 인서트 건이 마지막 batch size 보다 적은 경우, 해당 건을 commit 해줘야 함.
		if(this.executeCount > 0) {
			flushBatch();
		}
		this.getSession().commit();
	}

}
