package com.koreacb.kais.mybatis;

import java.util.Map;

@FunctionalInterface
public interface RuleResultExecutorInDataLoading {
	public Map<String,Object> executeRuleAndStoreResult(Map<String,Object> parameter, Map<String,Object> input) throws Exception;
}
