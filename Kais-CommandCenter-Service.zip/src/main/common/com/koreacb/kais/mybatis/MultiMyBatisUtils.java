package com.koreacb.kais.mybatis;


import java.io.BufferedReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.ibatis.datasource.pooled.PooledDataSource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreacb.kais.Constants;
import com.koreacb.kais.data.server.load.DBDataLoadInfo;
import com.koreacb.kais.data.server.load.DataSetDataLoadInfo;
import com.koreacb.kais.data.server.load.FileDataLoadInfo;
import com.koreacb.kais.data.server.load.LoadingCondition;

public class MultiMyBatisUtils extends MyBatisUtils {

	Connection connection;
	PreparedStatement ps;
	ResultSet rs;
	List<Map<String,Object>> mapList = new ArrayList<Map<String,Object>>();
	String START_TAG = "${";
	String END_TAG = "}";
	String REPL_MARK = " ? ";
	long fetchSize;
	
	String[] jsonColumnType = {"CLOB"}; 
	String[] jsonColumnName = {"SCOL_ORIGINA_DATA","SCOL_LOADING_DATA","SCOL_RESULT_DATA"};
	Map<String,Boolean> columnCheckCache;
	
	DBDataLoadInfo dbDataLoadInfo;
	FileDataLoadInfo fileDataLoadInfo;
	DataSetDataLoadInfo dataSetDataLoadInfo;
	DataBaseReader reader;
	int MAX_ROW = 1000;
	int limit = -1;
	
	boolean breakInReading = false;
	
	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public boolean isBreakInReading() {
		return breakInReading;
	}

	public void setBreakInReading(boolean breakInReading) {
		this.breakInReading = breakInReading;
	}

	public DataBaseReader getReader() {
		return reader;
	}

	public void setReader(DataBaseReader reader) {
		this.reader = reader;
	}

	public DBDataLoadInfo getDbDataLoadInfo() {
		return dbDataLoadInfo;
	}

	public void setDbDataLoadInfo(DBDataLoadInfo dbDataLoadInfo) {
		this.dbDataLoadInfo = dbDataLoadInfo;
	}

	public FileDataLoadInfo getFileDataLoadInfo() {
		return fileDataLoadInfo;
	}

	public void setFileDataLoadInfo(FileDataLoadInfo fileDataLoadInfo) {
		this.fileDataLoadInfo = fileDataLoadInfo;
	}

	public DataSetDataLoadInfo getDataSetDataLoadInfo() {
		return dataSetDataLoadInfo;
	}

	public void setDataSetDataLoadInfo(DataSetDataLoadInfo dataSetDataLoadInfo) {
		this.dataSetDataLoadInfo = dataSetDataLoadInfo;
	}

	public long getFetchSize() {
		return fetchSize;
	}

	public void setFetchSize(long fetchSize) {
		this.fetchSize = fetchSize;
	}

	public MultiMyBatisUtils(boolean isBatch) {
		super(isBatch);
	}
	
	public MultiMyBatisUtils(String env,boolean isBatch) {
		super(env,isBatch);
	}
	
	public MultiMyBatisUtils(DBDataLoadInfo info,boolean isBatch) {
		super(isBatch);
		try {
			this.dbDataLoadInfo = info;
			DataSource ds = new PooledDataSource(this.getDbDataLoadInfo().getSourceDriver()
					,this.getDbDataLoadInfo().getSourceUrl()
					,this.getDbDataLoadInfo().getSourceId()
					,this.getDbDataLoadInfo().getSourcePw());
			this.setConnection(ds.getConnection());			
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}
	
	public MultiMyBatisUtils(FileDataLoadInfo info,boolean isBatch) {
		super(isBatch);
		try {
			this.fileDataLoadInfo = info;
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}	

	public MultiMyBatisUtils(DataSetDataLoadInfo info,boolean isBatch) {
		super(isBatch);
		try {
			this.dataSetDataLoadInfo = info;
			this.setConnection(this.getSession().getConnection());
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}	

	public MultiMyBatisUtils(DBDataLoadInfo info,boolean isBatch , DataBaseReader reader) {
		super(isBatch);
		try {
			this.dbDataLoadInfo = info;
			DataSource ds = new PooledDataSource(this.getDbDataLoadInfo().getSourceDriver()
					,this.getDbDataLoadInfo().getSourceUrl()
					,this.getDbDataLoadInfo().getSourceId()
					,this.getDbDataLoadInfo().getSourcePw());
			this.setConnection(ds.getConnection());			
			this.setReader(reader);
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}
	
	public MultiMyBatisUtils(FileDataLoadInfo info,boolean isBatch , DataBaseReader reader) {
		super(isBatch);
		try {
			this.fileDataLoadInfo = info;
			this.setReader(reader);
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}	

	public MultiMyBatisUtils(DataSetDataLoadInfo info,boolean isBatch , DataBaseReader reader) {
		super(isBatch);
		try {
			this.dataSetDataLoadInfo = info;
			this.setConnection(this.getSession().getConnection());
			this.setReader(reader);
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}	
	
	public MultiMyBatisUtils(String env, DataSetDataLoadInfo info,boolean isBatch , DataBaseReader reader) {
		super(env, isBatch);
		try {
			this.dataSetDataLoadInfo = info;
			this.setConnection(this.getSession().getConnection());
			this.setReader(reader);
		}catch(Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"Exception[MyBatisUtils] : " + e.toString());
		}
	}		
	
	public Map<String,Object> map(Map<String,Object> m , String...parameter){
		Map<String,Object> p = new HashMap<>();
		for(int i = 0 ; i < parameter.length; i=i+2) {
			p.put(parameter[i+1], m.get(parameter[i]));
		}
		return p;
	}
	
	public Map<String,Object> map(String...parameter){
		Map<String,Object> p = new HashMap<>();
		for(int i = 0 ; i < parameter.length; i=i+2) {
			p.put(parameter[i], parameter[i+1]);
		}
		return p;
	}
	
	public List<Map<String,Object>> select(String sql, Map<String,Object> m, String...parameter) throws Exception{
		return this.select(sql, this.map(m, parameter));
	}
	
	public boolean insert(String sql, Map<String,Object> m, String...parameter) throws Exception{
		return this.insert(sql, this.map(m, parameter));
	}
	
	public List<Map<String,Object>> select(String sql, String...parameter) throws Exception{
		return this.select(sql, this.map(parameter));
	}
	
	public boolean insert(String sql, String...parameter) throws Exception{
		return this.insert(sql, this.map(parameter));
	}
	
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public PreparedStatement getPs() {
		return ps;
	}

	public void setPs(PreparedStatement ps) {
		this.ps = ps;
	}

	public ResultSet getRs() {
		return rs;
	}

	public void setRs(ResultSet rs) {
		this.rs = rs;
	}
	
	public String replacedMyBatisDollarSign(String sql,Map<String,Object> param) {
		if(sql.indexOf(START_TAG) < 0) return sql;
		StringBuilder newSql = new StringBuilder();
		String startTag = START_TAG;
		String endTag = END_TAG;
		int s = sql.indexOf(startTag);
		int e = sql.indexOf(endTag);
		String name = sql.substring(s+startTag.length(), sql.indexOf(endTag, s));
		if(param.containsKey(name)) {
			newSql.append(sql.substring(0,s)).append(param.get(name).toString()).append(sql.substring(e+endTag.length()));
		}
		return newSql.toString();
	}
	
	public String getReplacedMyBatisSql(String sql,List<String> list) {
		if(sql.indexOf(START_TAG) < 0) return sql;
		StringBuilder newSql = new StringBuilder();
		String startTag = START_TAG;
		String endTag = END_TAG;
		int s = sql.indexOf(startTag);
		int e = sql.indexOf(endTag);
		String name = sql.substring(s+startTag.length(), sql.indexOf(endTag, s));
		newSql.append(sql.substring(0,s)).append(REPL_MARK).append(sql.substring(e+endTag.length()));
		list.add(name.trim());
		return newSql.toString();
	}
	
	public boolean executeInReading(Map<String,Object> resultSet,int rowCount , int columnCount , List<Map<String,Object>> mapList) throws Exception{
		if(this.getReader() != null) {
			putRecordToList(resultSet, mapList);
			return this.getReader().read(resultSet, rowCount, columnCount);
		}
		else {
			putRecordToList(resultSet, mapList);
			return true;
		}
	}

	private void putRecordToList(Map<String, Object> resultSet, List<Map<String, Object>> mapList) {
		// Fetch Size가 0보다 크면, 지정 레코드수를 가져와야 하므로, List에 입력한다.
		// Fetch Size가 -1 인 경우에는 배치 모드로  , List에 입력하지 않는다.
		if(this.getFetchSize() > 0 ) {
			mapList.add(new HashMap<String,Object>());
			for(String k : resultSet.keySet()) {
				mapList.get(mapList.size()-1).put(k,resultSet.get(k));
			}
		}
	}
	/*
	 * 데이터 셋을 로딩하여, 처리하는 부분은 모두 이곳을 수행함
	 * 조건이 들어 갈수 있으므로, 아래 처리부분은 MyBatis의 쿼리를 사용하지만,
	 * MyBatis를 실행하지는 않음.
	 */
	public List<Map<String,Object>> executeDataSetLoad(int fetchCount) throws Exception {
		
		Map<String,Object> record = null;
		String tableId = this.getDataSetDataLoadInfo().getDataSetLoadingTableId();
		StringBuilder sb = new StringBuilder();
		int andCount = 0;
		
		/*
		 * 로딩 아이디를 포함 시킬지, 판단.. 필요 없어짐.
		if(this.getDataSetDataLoadInfo().getDataLoadId() != null
		&& this.getDataSetDataLoadInfo().getDataLoadId().length() > 0) {
			sb.append(" AND SCOL_LOADING_ID = '");
			sb.append(this.getDataSetDataLoadInfo().getDataLoadId());
			sb.append("'");
		}
		*/
		
		// 필터링 옵션을 무시하지 않는지 확인 해야 함.
		if(!this.getDataSetDataLoadInfo().isIgnoreFiltering()) {
			if(this.getDataSetDataLoadInfo().getLoadingCond() != null) {
				for(String k : this.getDataSetDataLoadInfo().getLoadingCond().keySet()) {
					sb.append(" AND ");
					andCount++;
					sb.append("(");
					int cntInGroup = 0;
					for(LoadingCondition loadingCondition : this.getDataSetDataLoadInfo().getLoadingCond().get(k)) {
						if(cntInGroup != 0) sb.append(" OR ");
						sb.append(loadingCondition.toString());
						cntInGroup++;
					}
					sb.append(")");
				}
			}
		}
		
		Map<String,Object> parameter = new HashMap<>();
		parameter.put("DSET_TABLE", this.getDataSetDataLoadInfo().getDataSetLoadingTableId());
		parameter.put("SCOL_LOADING_ID", this.getDataSetDataLoadInfo().getDataLoadId());
		parameter.put("LOADING_ID", this.getDataSetDataLoadInfo().getDataLoadId());
		parameter.put("WK_EXE_ID", this.getDataSetDataLoadInfo().getDataLoadId());
		parameter.put("DSET_WSQL", sb.toString());
		String sql = null;
		
		// WK_EXE_ID 가 있는 경우 (ex: RULE_RESULT), Loading 조건이 달라져야 함.
		// 아래에서 사용하는 쿼리는 #{}를 사용하면 안됨.
		// 쿼리가 2개로 한정됨.
		//  - SELECT_DSET_WK_EXE_LOADING
		//  - SELECT_DSET_LOADING
		if(!this.getDataSetDataLoadInfo().isLoadAll()) {
			com.koreacb.kais.GlobalLogger.log(this,">>>>>>>> Loading... with WK_EXE_ID ["+this.getDataSetDataLoadInfo().getDataLoadId()+"]");
			sql = this.getSqlSessionFactory().getConfiguration().getMappedStatement(Constants.SELECT_DSET_WK_EXE_LOADING).getBoundSql(parameter).getSql();	
		}else {
			com.koreacb.kais.GlobalLogger.log(this,">>>>>>>> Loading... without WK_EXE_ID");
			sql = this.getSqlSessionFactory().getConfiguration().getMappedStatement(Constants.SELECT_DSET_LOADING).getBoundSql(parameter).getSql();
		}
		
		// SQL MyBatis의 ${}를 치환 해줘야 함.
		while(sql.indexOf(START_TAG) >= 0) {
			sql = this.replacedMyBatisDollarSign(sql, parameter);
		}
		
		if(fetchCount > 0) {
			sql += " LIMIT 0," + fetchCount;
		}
		com.koreacb.kais.GlobalLogger.log(this,">>>>>>>> DATA SET LOADING.... ["+sql+"]");
		this.executeSqlLoad(sql, parameter, false);
		return mapList;
		
	}
	
	public String getSql(String name , Map<String,Object> parameter) throws Exception {
		return this.getSqlSessionFactory().getConfiguration().getMappedStatement(name).getBoundSql(parameter).getSql();
	}
	
	public List<Map<String,Object>> executeDataSetLoad() throws Exception {
		return executeDataSetLoad(-1);
	}
	
	public List<Map<String,Object>> executeFileLoad(int fetchCount) throws Exception {
		Map<String,Object> record = null;
		Path path = Paths.get(this.getFileDataLoadInfo().getPath());
		
		try(BufferedReader reader = Files.newBufferedReader(path,Charset.forName("UTF-8"))){
			String line = null;
			List<String> header = null;
			int count = 0;
			while((line = reader.readLine()) != null) {
				count++;
				String[] headersOrRecord = line.split(this.getFileDataLoadInfo().getDelimeter());
				if(count == 1) {
					if(this.getFileDataLoadInfo().hasHeader()) {
						header = new ArrayList<String>(Arrays.asList(headersOrRecord));
						// 헤더가 있는 경우, 첫라인을 읽어서, 헤더를 인식하고, 한건을 더읽어야 함.
						// 첫라인을 한번 읽었으므로, 1개의 라인을 더 읽게 해야 함.
						if(fetchCount > 0) fetchCount++;
					}else {
						header = new ArrayList<String>();
						record = new HashMap<>();
						for(int i = 0; i < headersOrRecord.length; i++) {
							String col = "COL" + i;
							header.add(col);
							record.put(col, headersOrRecord[i]);
						}
						if(!this.executeInReading(record,count, headersOrRecord.length, mapList)) {
							this.setBreakInReading(true);
							break;
						}
					}
				}else {
					record = new HashMap<>();
					for(int i = 0; i < headersOrRecord.length; i++) {
						record.put(header.get(i), headersOrRecord[i]);
					}
					// 2018.08.22
					// 헤더가 있는 파일을 로딩 한 경우, 상태 정보를 저장하는 로직에서 row count 가 1인경우에만 상태를 변경하므로,
					// 아래처럼, 헤더가 있는 경우, row count 가 2이면, 처음 데이터를 읽으므로, 1로 변경해서 넘겨줌.
					int statusCount = count;
					if(this.getFileDataLoadInfo().hasHeader() && count == 2) statusCount = 1;
					if(!this.executeInReading(record,statusCount, headersOrRecord.length, mapList)) {
						this.setBreakInReading(true);
						break;
					}
				}
				if(fetchCount > 0) {
					if(count >= fetchCount) {
						break;
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return mapList;
	}
	
	public List<Map<String,Object>> executeFileLoad() throws Exception {
		return this.executeFileLoad(-1);
	}
	
	public List<Map<String,Object>> executeSqlLoad(String sql, Map<String,Object> parameter, boolean close){
		return this.executeSqlLoad(-1, sql, parameter, close);
	}
	
	public List<Map<String,Object>> executeSqlLoad(int limit, String sql, Map<String,Object> parameter, boolean close) {
		List<Map<String,Object>> result = null;
		
		try {
			if(parameter != null && parameter.size() > 0) {
				List<String> paramList = new ArrayList<>();
				String tmpSql = sql;
				
				while(tmpSql.indexOf(START_TAG) >= 0) {
					tmpSql = this.getReplacedMyBatisSql(tmpSql, paramList);
				}
				int i = 0;
				if(limit > 0) {
					tmpSql += " LIMIT 0," + limit;
				}
				ps = this.getConnection().prepareStatement(tmpSql);
				for(String name : paramList) {
					ps.setString(++i, parameter.get(name).toString());
				}
			}else {
				ps = this.getConnection().prepareStatement(sql);
			}
			
			if(sql.trim().toUpperCase().equals("INSERT")
			|| sql.trim().toUpperCase().equals("DELETE")
			|| sql.trim().toUpperCase().equals("UPDATE")
			|| sql.trim().toUpperCase().equals("DROP")
			|| sql.trim().toUpperCase().equals("CREATE")
			|| sql.trim().toUpperCase().equals("GRANT")) {
				ps.executeUpdate();
			}else {
				if(this.getFetchSize() > 0) ps.setFetchSize((int)this.getFetchSize());
				rs = ps.executeQuery();
				result = this.toList(limit, rs);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			this.clear(close);
		}
		return result;
	}
	
	public List<Map<String, Object>> getMapList() {
		return mapList;
	}

	public void setMapList(List<Map<String, Object>> mapList) {
		this.mapList = mapList;
	}

	public List<Map<String,Object>> toList(int limit, ResultSet result) throws Exception{
		columnCheckCache = new HashMap<>();
		ObjectMapper mapper = new ObjectMapper();
        int count = result.getMetaData().getColumnCount();
		int rowCount = 0;
		while(result.next()) {
			Map<String,Object> record = new HashMap<>();
			rowCount++;
			for(int i = 1; i <= count ; i++) {
				if(checkJsonColumn(result.getMetaData(),i)) {
					try {
						if(result.getString(i) != null && result.getString(i) instanceof String) {
							Map<String,Object> map = mapper.readValue(result.getString(i), new HashMap<String,Object>().getClass());
							record.putAll(map);
						}
					}catch(Exception e) {
						com.koreacb.kais.GlobalLogger.log(this,"Exception : Json Parsing...." + e.toString());
					}
				}else {
					record.put(result.getMetaData().getColumnLabel(i), result.getString(i));
				}
			}
			if(!this.executeInReading(record ,rowCount, count , mapList)) {
				this.setBreakInReading(true);
				break;
			}
			if(limit > 0) {
				if(rowCount >= limit) break;
			}
		}
		return mapList;
	}
	
	private boolean checkJsonColumn(ResultSetMetaData data ,int i) throws Exception {
		if(!columnCheckCache.containsKey(data.getColumnLabel(i))) {
			for(String type: jsonColumnType) {
				if(type.equals(data.getColumnTypeName(i))) {
					columnCheckCache.put(data.getColumnLabel(i),true);
					break;
				}
			}
			for(String name: jsonColumnName) {
				if(name.equals(data.getColumnLabel(i))) {
					columnCheckCache.put(data.getColumnLabel(i),true);
					break;
				}
			}
			if(!columnCheckCache.containsKey(data.getColumnLabel(i)))columnCheckCache.put(data.getColumnLabel(i),false);;
		}
		return columnCheckCache.get(data.getColumnLabel(i));	
	}
	
	public void clear(boolean close) {
		try {
			if(this.getRs() != null) this.getRs().close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		try {
			if(this.getPs() != null) this.getPs().close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		try {
			if(close == true && this.getConnection() != null) this.getConnection().close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		try {
			columnCheckCache.clear();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}


}
