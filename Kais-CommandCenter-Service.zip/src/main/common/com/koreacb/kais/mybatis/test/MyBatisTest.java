package com.koreacb.kais.mybatis.test;

import java.util.HashMap;
import java.util.Map;

import com.koreacb.kais.mybatis.MultiMyBatisUtils;

public class MyBatisTest {
	public static void main(String[] args) {
//		try {
//			MultiMyBatisUtils utils = new MultiMyBatisUtils(true);
//			Map<String,Object> parameter = new HashMap<>();
//			for(long i = 0; i <1000000000; i++) {
//				parameter.put("DS1", Math.round(Math.random()*100000));
//				parameter.put("DS2", Math.round(Math.random()*100000));
//				parameter.put("DS3", Math.round(Math.random()*100) + "");
//				parameter.put("DS4", Math.round(Math.random()*100000)%2 == 1 ? "C" : "D");
//				parameter.put("DS5", Math.round(Math.random()*100000));
//				parameter.put("DS6", Math.round(Math.random()*100000));
//				utils.insert("com.koreacb.kais.mapper.insertTestData", parameter);
//			}
//		}catch(Exception e) {
//			e.printStackTrace();
//		}

	}
}
