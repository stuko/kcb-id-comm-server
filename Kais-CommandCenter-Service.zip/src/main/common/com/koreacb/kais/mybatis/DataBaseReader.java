package com.koreacb.kais.mybatis;

import java.util.List;
import java.util.Map;

@FunctionalInterface
public interface DataBaseReader {
	public boolean read(Map<String,Object> rs,int rowCount, int colCount) throws Exception;
}
