package com.koreacb.kais.mybatis;

import java.util.List;
import java.util.Map;

@FunctionalInterface
public interface DataSetCallBack {
	public Map<String,Object> callBizLogicInReading(boolean noTransfer, int rowCount, boolean isLast, Map<String,Object> map,List<Map<String,Object>> itemList,  String code, int total, int err) throws Exception;
}
