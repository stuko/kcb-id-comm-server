package com.koreacb.kais.mybatis;

import java.util.ArrayList;
import java.util.List;

import com.koreacb.kais.Constants;

public class TableBuilder {
	
	StringBuilder sb = new StringBuilder();
	StringBuilder key = new StringBuilder();
	List<StringBuilder> colList = new ArrayList<>();
	static String ENTER = "\n";
	static String COMMA = ",";
	static String SPACE = " ";
	
	public TableBuilder() {
		
	}
	
	public String size(int len) {
		if(len == 0) return "";
		else return "(" + len + ")";
	}
	
	public String nul(boolean n) {
		return n ? "NULL" : "NOT NULL";
	}
	
	public String def(String d) {
		if(d == null) return "";
		else return "DEFAULT " + d;
	}
	
	public TableBuilder create(String tblName) {
		sb.append("CREATE TABLE").append(SPACE).append(tblName).append(SPACE).append("(").append(SPACE).append(ENTER);
		return this;
	}
	
	public TableBuilder append(String column, String type, int len , boolean nul , String def) {
		StringBuilder col = new StringBuilder();
		String t = Constants.ITEM_DATA_TYPE_STRING.equals(type) ? "VARCHAR" : 
			                   (Constants.ITEM_DATA_TYPE_NUMBER.equals(type) || Constants.ITEM_DATA_TYPE_INTEGER.equals(type) ? "INT" : 
			                	   (Constants.ITEM_DATA_TYPE_DATE.equals(type) ? "DATETIME" : "VARCHAR"));
		col.append(column)
		  .append(SPACE)
		  .append(t)
		  .append(size(len))
		  .append(SPACE)
		  .append(nul(nul))
		  .append(SPACE)
		  .append(def(def))
		  .append(SPACE)
		  ;
		colList.add(col);
		return this;
	}
	
	public TableBuilder key(String... k) {
		key.append("PRIMARY KEY (");
		for(int i = 0; i < k.length-1; i++) {
			key.append(k[i]).append(COMMA);
		}
		key.append(k[k.length-1]).append(")").append(ENTER);
		return this;
	}
	
	public String build() {
		for(int i = 0; i < colList.size()-1; i++) {
			sb.append(colList.get(i).toString()).append(COMMA).append(ENTER);
		}
		sb.append(colList.get(colList.size()-1).toString()).append(COMMA).append(ENTER);
		sb.append(key.toString()).append(")");
		return sb.toString();
	}
	
	
}
