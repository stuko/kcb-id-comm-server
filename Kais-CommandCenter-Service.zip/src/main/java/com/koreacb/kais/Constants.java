package com.koreacb.kais;

public class Constants {
	
	public static String SELECT_DSET_LOADING = "selectDsetLoading";
	public static String SELECT_DSET_WK_EXE_LOADING = "selectDsetWkExeLoading";
	
	public static String RESPONSE_INFO = "RESPONSE_INFO";
	
	public static String DATA_SET_RES_LOADING_ID = "DAT_SET_LDN_ID";
	public static String DATA_SET_RES_LOADING_STEP = "DAT_LDN_STP";
	public static String DATA_SET_RES_LOADING_RETURN = "DAT_LDN_RTN_DS";
	public static String DATA_SET_RES_LOADING_RETURN_MSG = "DAT_LDN_RTN_MSG";
	public static String DATA_SET_RES_LOADING_PROGRESS_STATUS = "DAT_SET_PGRS_STS";
	public static String DATA_SET_RES_LOADING_STEP_DATETIME = "DAT_LDN_STP_DTM";
	public static String DATA_SET_RES_LOADING_ALL_COUNT = "DAT_LDN_ALL_CNT";
	public static String DATA_SET_RES_LOADING_SUCCESS_COUNT = "DAT_LDN_SUCS_CNT";
	public static String DATA_SET_RES_LOADING_ERROR_COUNT = "DAT_LDN_FALR_CNT";
	
	public static String DATA_SET_BASIC_CHAR_SET = "UTF-8";
	public static String DATA_SET_BASIC_INF = "LOADING_DATA";
	
	public static String TEST_DATA = "TEST_DATA";
	public static String RULE_DATA = "RULE_DATA";
	public static String ITEM_DATA = "ITEM_DATA";
	public static String ITEM_LIST = "ITEM_LIST";
	public static String TEST_MAP = "TEST_MAP";
	
	public static String ITM_ID = "ITM_ID";
	public static String ITM_TST_VL = "ITM_TST_VL";
		
	public static String SPECIAL_VALUE_INF = "svInf";
	
	public static String ANALYSIS_ITEM_DATA = "ANALYSIS_ITEM_DATA";
	public static String ANL_ITM_ID = "ANL_ITM_ID";
	public static String SPECIAL_VALUE = "SPECIAL_VALUE";

	public static String ANALYSIS_DM_ITEM_DATA = "ANALYSIS_DM_ITEM_DATA";
	public static String ANALYSIS_FT_ITEM_DATA = "ANALYSIS_FT_ITEM_DATA";
	public static String ANALYSIS_DM_V_TYPE = "V";
	public static String ANALYSIS_DM_R_TYPE = "R";
	
	public static String ANAL_DM_ITM_ID = "ANL_DM_ITM_ID";
	public static String ANAL_DM_ITM_TP = "ANL_DM_ITM_TP";
	public static String ANAL_DM_ITM_NM = "ANL_DM_ITM_NM";
	public static String GROUP_TP = "GROUP_TP";
	public static String CNVT_RULE_ID = "CNVT_RULE_ID";
	
	public static String SPRT_LIST = "SPRT_LIST";
	public static String SPRT_ITM_ID = "SPRT_ITM_ID";
	public static String SPRT_ITM_TP = "SPRT_ITM_TP";
	public static String SPRT_LWLM_CND_TP = "SPRT_LWLM_CND_TP";
	public static String SPRT_LWLM_CND_VL = "SPRT_LWLM_CND_VL";
	public static String SPRT_HGLM_CND_TP = "SPRT_HGLM_CND_TP";
	public static String SPRT_HGLM_CND_VL = "SPRT_HGLM_CND_VL";
	
	public static String ANL_FT_ITM_ID = "ANL_FT_ITM_ID";
	public static String ANL_FT_ITM_TP = "ANL_FT_ITM_TP";
	public static String ANL_FT_ITM_NM = "ANL_FT_ITM_NM";
	public static String FT_CNT = "FT_CNT";
	public static String FT_MIN = "FT_MIN";
	public static String FT_MAX = "FT_MAX";
	public static String FT_SUM = "FT_SUM";
	public static String FT_AVG = "FT_AVG";
	public static String SQN = "SQN";
	
	public static String ITEM_INF = "ITEM_MAPPING";
	
	public static String ITEM_ID = "DAT_SET_ITM_ID";
	public static String ITEM_USE_TYPE = "DAT_SET_ITM_US_TP";
	public static String ITEM_USE_TYPE_GENERAL = "G";
	public static String ITEM_USE_TYPE_PERFORMANCE = "P";
	public static String ITEM_USE_TYPE_FILTER = "F";
	public static String ITEM_DATA_LENGTH = "DAT_SET_ITM_DAT_LEN";
	public static String ITEM_USE_NAME = "DAT_SET_ITM_NM";
	public static String ITEM_DATA_TYPE = "DAT_SET_ITM_DAT_TP";
	public static String ITEM_DATA_BASIC_VALUE = "DAT_SET_ITM_BSC_VL";

	public static String DAT_SET_ITM_TP = "DAT_SET_ITM_TP";
	
	public static String ITEM_DATA_TYPE_STRING = "STR"; //SC, SD
	public static String ITEM_DATA_TYPE_NUMBER = "NUM"; //ND, NI
	public static String ITEM_DATA_TYPE_INTEGER = "ITG"; //ND, NI
	public static String ITEM_DATA_TYPE_DATE = "DTE";   
	public static String ITEM_DATA_TYPE_SDATE = "SDT";
	public static String ITEM_DATA_TYPE_BOOL = "BLN";
	public static String ITEM_MAP_ID = "DAT_SET_MPN_ID";
	
	public static String LOADING_RULE_TP_SRC_TP = "DAT_SRC_TP";
	public static String LOADING_RULE_TP_SRC_TP_FILE = "FL";
	public static String LOADING_RULE_TP_SRC_TP_SQL = "DB";
	public static String LOADING_RULE_TP_SRC_TP_DS = "DS";
	
	public static String LOADING_RULE_FILE_PATH = "DAT_SRC_PATH";
	public static String LOADING_RULE_FILE_NAME = "DAT_FILE_NAME";
	public static String LOADING_RULE_FILE_DELM = "DAT_FILE_SEPERATOR";
	public static String LOADING_RULE_FILE_HEADER = "DAT_HEADER_YN";

	public static String LOADING_RULE_DB_DRIVER = "DAT_BASE_DRIVER";
	public static String LOADING_RULE_DB_URL = "DAT_BASE_URL";
	public static String LOADING_RULE_DB_ID = "LOGIN_ID";
	public static String LOADING_RULE_DB_PW = "LOGIN_PASSWD";
	public static String LOADING_RULE_DB_SQL = "SQL";
	
	public static String RULE_TP_LOADING_OPT = "DAT_LDN_OPTION";
	public static String RULE_TP_LOADING_OPT_TRUNCATE = "D";
	public static String RULE_TP_LOADING_OPT_DROP = "T";
	
	public static String DATA_SET_BASIC_ID = "DAT_SET_ID";
	
	public static String DATA_SET_BASIC_RECORD_ID = "recordId";
	public static String DATA_SET_BASIC_EXPORT_FILE = "DAT_FILE_NAME";
	public static String DATA_SET_BASIC_EXPORT_PATH = "DAT_SRC_PATH";
	public static String DATA_SET_BASIC_EXPORT_FORMAT = "DAT_EXP_TP";
	public static String DATA_SET_BASIC_EXPORT_DELIM = "DAT_FILE_SEPERATOR";
	public static String DATA_SET_BASIC_EXPORT_HEADER = "DAT_HEADER_YN";
	
	public static String DATA_SET_BASIC_EXPORT_RESULT_INFO_HEADER = "HEADER";
	public static String DATA_SET_BASIC_EXPORT_RESULT_INFO_SEPARATOR = "SEPARATOR";
	
	public static String DATA_SET_BASIC_EXPORT_RESULT_META_INF = "EXPORT_ITEM_DATA";
	public static String DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT = "METADATA_LIST";
	public static String DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_ORDER = "METADATA_ORDER";
	public static String DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_ID = "METADATA_ID";
	public static String DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_NAME = "METADATA_NM";
	public static String DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_TYPE = "METADATA_TYPE";

	public static String DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_ORDER = "SQN";
	public static String DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_ID = "DAT_SET_ITM_ID";
	public static String DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_NAME = "DAT_SET_ITM_NM";
	public static String DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_TYPE = "DAT_SET_ITM_TP";

	
	public static String DATA_SET_BASIC_EXPORT_REQUEST_LAYOUT = "METADATA_LIST";
	public static String DATA_SET_BASIC_EXPORT_REQUEST_LAYOUT_ORDER = "METADATA_ORDER";
	public static String DATA_SET_BASIC_EXPORT_REQUEST_LAYOUT_ID = "METADATA_ID";
	public static String DATA_SET_BASIC_EXPORT_REQUEST_LAYOUT_NAME = "METADATA_NM";
	public static String DATA_SET_BASIC_EXPORT_REQUEST_LAYOUT_TYPE = "METADATA_TYPE";
	
	
	public static String RULE_RESULT_TABLE_PREFIX = "RULE_";
	public static String IGNORE_FILTERING = "IGNORE_FILTERING";
	public static String IGNORE = "Y";
	public static String NOT_IGNORE = "N";
	public static String RULE_RESULT_TABLE = "RULE_RESULT";
	// public static String RULE_RESULT_TABLE = "RULE_RESULT_TABLE";
	public static String DATA_SET_BASIC_LOADING_ID = "WK_EXE_ID";
	public static String DATA_SET_TABLE_ID = "DATA_SET_TABLE_ID";
	public static String DATA_SET_BASIC_LOADING_TABLE_ID = "DAT_LDN_TABLE_ID";
	public static String DATA_SET_BASIC_SOURCE_TABLE_ID = "DAT_SRC_TABLE_ID";
	
	public static String DATA_SET_BASIC_LOADING_COND = "FILTERING_OPTION";
	
	public static String DATA_SET_BASIC_LOADING_COND_OR_GROUP = "DAT_SET_ITM_LGC_DS";
	public static String DATA_SET_BASIC_LOADING_COND_ITEM_ID = "DAT_SET_ITM_ID";
	public static String DATA_SET_BASIC_LOADING_COND_IN_VALUE = "DAT_SET_ITM_IN_VL";
	public static String DATA_SET_BASIC_LOADING_COND_OPERAND = "DAT_SET_ITM_OPR";
	
	public static String DATA_SET_ANALYSIS_ID = "statsAnalId";
	
	public static String EQ0 = "EQ0";
	public static String EQN = "EQN";
	public static String GT0 = "GT0";
	public static String GTE = "GTE";
	public static String LT0 = "LT0";
	public static String LTE = "LTE";
	public static String LK0 = "LK0";
	public static String LKN = "LKN";
	public static String BW0 = "BW0";
	public static String BWN = "BWN";
	public static String IN0 = "IN0";
	public static String INN = "INN";
	public static String NL0 = "NL0";
	public static String NLN = "NLN";
	
	//-----------------------------------
	// One level
	//-----------------------------------
	public static String KAIS_OUT_CODE = "KOUT_CODE";
	public static String KAIS_OUT_BASIC_MAP = "KOUT_BASIC";
	public static String KAIS_OUT_RESULT_MAP = "KOUT_RESULT";
	public static String KAIS_OUT_DEBUG_MAP = "KOUT_DEBUG";
	public static String KAIS_OUT_REFDATA_MAP = "KOUT_REFDATA";
	public static String KAIS_OUT_LOADINGTEST_MAP = "LOADINGTESTDATA";
	//-----------------------------------
	
	//-----------------------------------
	// Basic map
	//-----------------------------------
	public static String KAIS_OUT_BASIC_RULE_ID = "RULE_ID";
	public static String KAIS_OUT_BASIC_RULE_TYPE = "RULE_TYPE"; 
	public static String KAIS_OUT_BASIC_RULE_VER_DATE = "RULE_VERDATE";
	public static String KAIS_OUT_BASIC_RULE_EXE_DATE = "RULE_EXEDATE";
	public static String KAIS_OUT_BASIC_RULE_EXE_USER = "RULE_EXEUSER";
	//-----------------------------------
	
	public static String KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP = "RESULT_OUTPUT";
	public static String KAIS_OUT_BASIC_SCORE_OUTPUT_MAP = "RESULT_SCORE";
	public static String VERIFY_MAPPING = "VERIFY_MAPPING";
	public static String VRF_RSLT_ITM_ID = "VRF_RSLT_ITM_ID";
	public static String VRF_TGT_ITM_ID = "VRF_TGT_ITM_ID";
	//-----------------------------------
	// KOUT_RESULT MAP
	//-----------------------------------
	public static String KAIS_OUT_RESULT_SCORE_MAP = "RESULT_SCORE";
	//-----------------------------------
	
	//-----------------------------------
	// Score map IN KOUT_RESULT
	//-----------------------------------	
	public static String KAIS_OUT_BASIC_SCORE_SEG_ID = "SCORE_SEGID";
	public static String KAIS_OUT_BASIC_SCORE_MIN = "SCORE_MIN";
	public static String KAIS_OUT_BASIC_SCORE_MAX = "SCORE_MAX";
	public static String KAIS_OUT_BASIC_SCORE_SUM = "SCORE_SUM";
	public static String KAIS_OUT_BASIC_SCORE_AVG = "SCORE_AVG";
	public static String KAIS_OUT_BASIC_SCORE_POINT = "SCORE_POINT";
	
	public static String KAIS_OUT_BASIC_SCORE_POINT_MAP = "SCORE_POINTMAP";
	
	public static String KAIS_OUT_BASIC_SCORE_CLASS_MAP = "SCORE_CLASSMAP";
	
	public static String KAIS_OUT_BASIC_SCORE_PLUS_REASON_MAP = "SCORE_PLSRSN";
	
	public static String KAIS_OUT_BASIC_SCORE_MINUS_REASON_MAP = "SCORE_MUSRSN";
	
	public static String KAIS_OUT_BASIC_SCORE_GRADE = "SCORE_GRADE";
	public static String KAIS_OUT_BASIC_SCORE_GRADE_RULE_ID = "SCORE_GRDRULEID";
		
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_MAP = "SCORE_TIMEBIN";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_ITEM_ID = "ITEM_ID";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_ITEM_TYPE = "ITEM_TYPE";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_ITEM_VALUE = "ITEM_VALUE";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_BIN_ID = "BIN_ID";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_BIN_POINT = "BIN_POINT";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_BIN_CLASS = "BIN_CLASS";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_REASON_PLUS = "RSN_PLUS";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_REASON_MINUS = "RSN_MINUS";
	public static String KAIS_OUT_BASIC_SCORE_TIMEBIN_REASON_POINT = "RSN_POINT";

	public static String SIM_DATASET_INF = "SIMUL_DATA";
	public static String SIM_MAP_INF = "ITEM_MAPPING";
	public static String SIM_FILTERING_INF = "FILTERING_OPTION";
	public static String SIM_PERF_INF = "PERFORMANCE_ITEM";
	
	public static String EXE_RULE_TYPE_MS = "MAINSTG";
	public static String EXE_RULE_TYPE_SS = "SUBSTG";
	public static String EXE_RULE_TYPE_SC = "SCORECARD";
	public static String EXE_RULE_TYPE = "RULE_TYPE";
	
	public static String SIM_BASIC_INFO = "BASIC_INFO";
	public static String SIM_BASIC_DATA = "BASIC_DATA";
	public static String SIM_RULE_ID = "RULE_ID";

	public static String PERFORMANCE_ITEM = "PERFORMANCE_ITEM";
	public static String PERFORMANCE_ITM_LIST = "PERFORMANCE_ITM_LIST";
	public static String PERFORMANCE_ITM_ID = "DAT_SET_ITM_ID";
	public static String PRMC_VL = "PRMC_VL";
	public static String LWLM_CND_TP = "LWLM_CND_TP";
	public static String USE_YN = "USE_YN";
	public static String HGLM_CND_VL = "HGLM_CND_VL";
	public static String LWLM_CND_VL = "LWLM_CND_VL";
	public static String PRMC_ITM_NM = "PRMC_ITM_NM";
	public static String HGLM_CND_TP = "HGLM_CND_TP";
	
	public static String PERF_COLUMN = "SCOL_PERF_VAL";
	public static String PERF_NOT_USE = "9";
	public static String PERF_NORMAL = "0";
	public static String PERF_BAD = "1";
	public static String PERF_NONE = "2";
}
