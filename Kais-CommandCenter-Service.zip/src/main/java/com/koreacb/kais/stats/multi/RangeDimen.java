package com.koreacb.kais.stats.multi;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreacb.kais.Constants;

public class RangeDimen implements Cloneable{
	
	String itemId;
	String type;
	String itemType;
	List<RangeCond> rangeCondTemplate;
	List<RangeCond> rangeCond;
	DecimalFormat f;
	Map<String,RangeDimen> distinctTable;
	List<ValueDimen> factTemplate;
	RangeDimen childNonRangeDimenTemplate;
	RangeDimen parentRangeDimen;
	RangeDimen childRangeDimen;
	List<ValueDimen> valueDimen;
	StringBuilder parentDimenNames;

	public RangeDimen() {
		distinctTable = new HashMap<String,RangeDimen>();
	    factTemplate = new ArrayList<>();
	    f = new DecimalFormat("#0.##");
	    rangeCondTemplate = new ArrayList<>();
	    parentDimenNames = new StringBuilder();
	}

	/*
	 * 2018-09-27 수정
	 * Value 기준 다차원 정보와 Range 기준 다차원 정보 초기화
	 * ChildRangeDimen clone 후 초기화 필요 
	 */
	public void clear() {
		this.distinctTable = new HashMap<String,RangeDimen>();
		this.newRangeCond(); 
	}
	
	public List<ValueDimen> getValueDimen() {
		return valueDimen;
	}

	public void setValueDimen(List<ValueDimen> valueDimen) {
		this.valueDimen = valueDimen;
	}

	// 화면에 보여주기 위해 필요한 차원의 이름 값
	// 객체생성 비용을 줄이기 위해, String으로 저장
	// Comma로 연결된 String
	public void appendParentDimenNames(String name) {
		if(parentDimenNames.length() == 0)parentDimenNames.append(name);
		else parentDimenNames.append(",").append(name);
	}

	public String getParentDimenNameString() {
		return this.parentDimenNames.toString();
	}
	
	public String[] getParentDimenNames() {
		if(this.parentDimenNames.length() == 0) return null;
		else return this.parentDimenNames.toString().split(",");
	}
	
	public RangeDimen getChildRangeDimen() {
		return childRangeDimen;
	}

	public void setChildRangeDimen(RangeDimen childRangeDimen) {
		this.childRangeDimen = childRangeDimen;
	}

	public RangeDimen getParentRangeDimen() {
		return parentRangeDimen;
	}

	public void setParentRangeDimen(RangeDimen parentRangeDimen) {
		this.parentRangeDimen = parentRangeDimen;
	}
	
	public RangeDimen getChildNonRangeDimenTemplate() {
		return childNonRangeDimenTemplate;
	}

	public void setChildNonRangeDimenTemplate(RangeDimen childNonRangeDimenTemplate) {
		this.childNonRangeDimenTemplate = childNonRangeDimenTemplate;
	}

	public List<ValueDimen> getFactTemplate() {
		return factTemplate;
	}

	public void setFactTemplate(List<ValueDimen> factTemplate) {
		this.factTemplate = factTemplate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public void newDistinctTable() {
		this.distinctTable = new HashMap<String, RangeDimen>();
	}
	
	public Map<String, RangeDimen> getDistinctTable() {
		return distinctTable;
	}

	public void setDistinctTable(Map<String, RangeDimen> distinctTable) {
		this.distinctTable = distinctTable;
	}
	
	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public void newRangeCond() {
		this.rangeCond = new ArrayList<RangeCond>();
	}
	
	public List<RangeCond> getRangeCond() {
		return rangeCond;
	}

	public void setRangeCond(List<RangeCond> rangeCond) {
		this.rangeCond = rangeCond;
	}
	
	public List<RangeCond> getRangeCondTemplate() {
		return rangeCondTemplate;
	}

	public void setRangeCondTemplate(List<RangeCond> rangeCondTemplate) {
		this.rangeCondTemplate = rangeCondTemplate;
	}

	public List<ValueDimen> newValueDimenList(String rangeKey) throws Exception{
		List<ValueDimen> vm = new ArrayList<>();
		this.getFactTemplate().forEach((m)->{
			vm.add(new ValueDimen());
			// 2019.08.03
			// 아래의 ItemId로 값을 가져와야 하므로, 원복
			// R타입은 Template의 getItemId, V타입은 evaluation 시점에 생성해서 rangeKey를 넘겨준다.
			// vm.get(vm.size()-1).setItemId(rangeKey == null ? m.getItemId() : rangeKey);
			// vm.get(vm.size()-1).setItemId(rangeKey);
			vm.get(vm.size()-1).setItemId(m.getItemId());
			vm.get(vm.size()-1).setItemName(m.getItemName());
			vm.get(vm.size()-1).setType(m.getType());
			vm.get(vm.size()-1).setEnableCount(m.isEnableCount());
			vm.get(vm.size()-1).setEnableMax(m.isEnableMax());
			vm.get(vm.size()-1).setEnableMin(m.isEnableMin());
			vm.get(vm.size()-1).setEnableSum(m.isEnableSum());
			vm.get(vm.size()-1).setEnableAvg(m.isEnableAvg());
			vm.get(vm.size()-1).setCount(m.getCount());
			vm.get(vm.size()-1).setMax(m.getMax());
			vm.get(vm.size()-1).setMin(m.getMin());
			vm.get(vm.size()-1).setSum(m.getSum());
		});
		return vm;
	}
	
	public RangeCond addRangeCond(String range_name, String name, String u_tp, String u_vl, String l_tp, String l_vl) throws Exception{
		RangeCond rc = new RangeCond();
		this.getRangeCond().add(rc);
		// 해당 차원의 서브 조건 명
		rc.setRangeName(range_name);
		// 해당 차원의 항목명
		rc.setSprtId(name);
		rc.setName(name);
		rc.setType(this.getItemType());
		rc.setLowerOperand(l_tp);
		rc.setLower(l_vl);
		rc.setUpperOperand(u_tp);
		rc.setUpper(u_vl);
		
		// com.koreacb.kais.GlobalLogger.log(this,"##### RANGECOND ##### " + rc.toMap());
		
		return rc;
		
	}
	
	public RangeCond addRangeCondTemplate(String range_name, String name, String u_tp, String u_vl, String l_tp, String l_vl) {
		RangeCond rc = new RangeCond();
		this.getRangeCondTemplate().add(rc);
		// 해당 차원의 서브 조건 명
		rc.setRangeName(range_name);
		// 해당 차원의 항목명
		rc.setSprtId(name);
		rc.setName(name);
		rc.setType(this.getItemType());
		rc.setLowerOperand(l_tp);
		rc.setLower(l_vl);
		rc.setUpperOperand(u_tp);
		rc.setUpper(u_vl);
		
		return rc;
		
	}	
	
	public List<Map<String,Object>> toList(List<Map<String,Object>> list) throws Exception{
		
		if(list == null) list = new ArrayList<>(); 
		if(this.getType().equals(Constants.ANALYSIS_DM_R_TYPE)) {
			// 2018.08.09 
			// 범위 가 생성되지 않은 경우가 있음.
			// Null 체크 추가함.
			if(this.getRangeCond() != null) {
				for(int i = 0; i < this.getRangeCond().size() ; i++) {
					if(this.getRangeCond().get(i).getRangeDimen().getChildRangeDimen() != null) {
						this.getRangeCond().get(i).getRangeDimen().getChildRangeDimen().toList(list);
					}else {
						int idx = 0;
						Map<String,Object> m = this.getRangeCond().get(i).toMap();
						for(String dims : this.getRangeCond().get(i).getRangeDimen().getParentDimenNames()) {
							m.put("DM_" + (++idx), dims);
						}
						com.koreacb.kais.GlobalLogger.log(this,">>>>>>>> Map : " + m);
						list.add(m);
					}
				}
			}
		}else {
			for(String k : this.getDistinctTable().keySet()) {
				if(this.getDistinctTable().get(k).getChildRangeDimen() != null) {
					this.getDistinctTable().get(k).getChildRangeDimen().toList(list);
				}else {
					int idx = 0;
					Map<String,Object> m = toMap(k, this.getDistinctTable().get(k).getValueDimen());
					for(String dims : this.getDistinctTable().get(k).getParentDimenNames()) {
						m.put("DM_" + (++idx), dims);
					}
					com.koreacb.kais.GlobalLogger.log(this,">>>>>>>> Map : " + m);
					list.add(m);
				}
			}
		}
		return list;
	}

	private Map<String, Object> toMap(String key, List<ValueDimen> vlist)  throws Exception{
		Map<String,Object> m = new HashMap<>();
		m.put("FACT_LIST", this.getValueDimenListToMap(key, vlist));
		return m;
	}
	
	private List<Map<String, Object>> getValueDimenListToMap(String key, List<ValueDimen> vlist) throws Exception {
		List<Map<String,Object>> vs = new ArrayList<>();
		for(ValueDimen vd : vlist) {
			Map<String,Object> m = vd.toMap();
			m.put("F_ID" , key);
			vs.add(m);
		}
		return vs;
	}

	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		if(this.getType().equals(Constants.ANALYSIS_DM_R_TYPE)) {
			if(this.getRangeCond() != null) {
				for(int i = 0; i < this.getRangeCond().size() ; i++) {
					RangeCond r = this.getRangeCond().get(i);
					sb.append(r.getName());
					sb.append(" : " );
					sb.append(r.getLower());
					sb.append(r.getLowerOperand());
					sb.append(" and ");
					sb.append(r.getUpper());
					sb.append(r.getUpperOperand());
					sb.append(" -> " );
					sb.append("\n");
				}
			}
		}else {
			if(this.getDistinctTable() != null) {
				this.getDistinctTable().forEach((k,v)->{
					v.getValueDimen().forEach((vd)->{
						sb.append("["+k+"]["+vd.toMap()+"]");
					});
				});
			}
		}
		return this.getItemId() + "\n" + sb.toString();
	}
	
	// RangeDimen의 복사본에 저장된 중요한 정보
	// Range(R)타입의 경우: 현재 차원의 항목아이디(getItemId) 존재함
	//                , ValueDimen에 구해야할 통계/분석 항목아이디(getItemId) 존재함
	//                , RangeCond에 해당항목(차원의) 아이디와(getSprtId,getName) 차원의 서브조건명(getRangeName)이 존재함.
	// V 타입의 경우: 현재 차원의 항목아이디(getItemId) 존재함
	//                , ValueDimen에 구해야할 통계/분석 항목아이디 존재함
	public void eval(Map<String,Object> rs , String parentDimenName) throws Exception {
		
		// 대소문자를 모두 관리 하도록 해야 함.
		// V타입에서는 결과 맵의 F_ID 정보로 사용됨.
		String strItemValue = checkCapsLetter(rs);
		
		if(strItemValue == null) {
			com.koreacb.kais.GlobalLogger.log(this,"Record does not have the Factor!!!!!!!!!!");
			return;
		}
		
		// 다차원 분석중 현재 차원의 유형인 V 즉 값에 따른 분류 인 경우
		if(this.getType().equals(Constants.ANALYSIS_DM_V_TYPE)) {
			
			if(this.getDistinctTable() == null) {
				this.newDistinctTable();
			}
			
			// V 로 현재 차원의 통계를 낼경우, Value를 기준으로 하게 됨.
			// distinctTable 라는 Map(Value,RangeDimen) 구조를 사용함.
			if(!this.getDistinctTable().containsKey(strItemValue)) {
				
				// 최초 호출이 된 경우, Value 키값이 없는 경우 이므로, RangeDimen을 생성함.
				this.getDistinctTable().put(strItemValue,new RangeDimen());
				this.getDistinctTable().get(strItemValue).setValueDimen(newValueDimenList(strItemValue));
				this.getDistinctTable().get(strItemValue).setType(Constants.ANALYSIS_DM_V_TYPE);
				this.getDistinctTable().get(strItemValue).setItemId(this.getItemId()); // 현재 차원의 항목 아이디

				if(this.getChildRangeDimen() != null) {
					if(this.getDistinctTable().get(strItemValue).getChildRangeDimen() == null) {
						this.getDistinctTable().get(strItemValue).setChildRangeDimen((RangeDimen)this.getChildRangeDimen().clone());
						/*
						 * 2018-09-27 수정
						 * Value 기준 다차원 정보와 Range 기준 다차원 정보 초기화
						 * ChildRangeDimen clone 후 초기화 필요 
						 */
						this.getDistinctTable().get(strItemValue).getChildRangeDimen().clear();
					}
				}
				// 부모 노드의 조건이름을 추가(누적됨)
				if(parentDimenName != null) {
					this.getDistinctTable().get(strItemValue).appendParentDimenNames(parentDimenName);
				}
				// 현재 노드의 조건 이름을 추가 (마지막에)
				this.getDistinctTable().get(strItemValue).appendParentDimenNames(strItemValue);
			}
			
			// 현재 조건 노드가 생성되었으므로, 해당 노드를 읽어서, 값을 계산한다.
			for(ValueDimen vd : this.getDistinctTable().get(strItemValue).getValueDimen()) {
				vd.eval(rs);
			}
			
			// 자식노드가 있는 경우, 해당 자식 노드의 계산(EVAL)을 호출한다. 호출시, 현재 자신의 노드 조건이름을 넘겨 준다.
			if(this.getDistinctTable().get(strItemValue).getChildRangeDimen() != null) {
				this.getDistinctTable().get(strItemValue).getChildRangeDimen().eval(rs, this.getDistinctTable().get(strItemValue).getParentDimenNameString());
			}
			
		}else if(this.getType().equals(Constants.ANALYSIS_DM_R_TYPE)) {

			int i = 0;
			if(this.getRangeCond() == null) {
				this.newRangeCond();
				for(RangeCond org : this.getRangeCondTemplate()) {
					RangeCond cond = (RangeCond) org.clone();
					this.getRangeCond().add(cond);	
				}
			}
			
			for(RangeCond cond : this.getRangeCond()) {
				
				if(cond.getRangeDimen() == null) {
					
					cond.setRangeDimen(new RangeDimen());
					cond.getRangeDimen().setValueDimen(newValueDimenList(null));
					cond.getRangeDimen().setType(this.getType());
					cond.getRangeDimen().setItemId(this.getItemId());

					if(this.getChildRangeDimen() != null) {
						if(cond.getRangeDimen().getChildRangeDimen() == null) {
							cond.getRangeDimen().setChildRangeDimen((RangeDimen)this.getChildRangeDimen().clone());
							/*
							 * 2018-09-27 수정
							 * Value 기준 다차원 정보와 Range 기준 다차원 정보 초기화
							 * ChildRangeDimen clone 후 초기화 필요 
							 */
							cond.getRangeDimen().getChildRangeDimen().clear();
						}
					}
					
					if(parentDimenName != null) {
						cond.getRangeDimen().appendParentDimenNames(parentDimenName);
					}
					
					cond.getRangeDimen().appendParentDimenNames(cond.getRangeName());
				}
				

				
				// 현재 차원의 조건이 TRUE 인경우
				// 아래에서 ValueDimen 을 처리 해줘야 함.
				// 하위 차원이 있는 경우, 계산 해줘야 함.
				if(cond.eval(rs)) {
					RangeDimen me = cond.getRangeDimen();
					for(ValueDimen vd : me.getValueDimen()) {
						vd.eval(rs);
					}
					if(cond.getRangeDimen().getChildRangeDimen() != null) {
						cond.getRangeDimen().getChildRangeDimen().eval(rs , cond.getRangeDimen().getParentDimenNameString());
					}
				}
				
			}
		}else {
			com.koreacb.kais.GlobalLogger.log(this,"[DimenAnalysis's Type Error] = " + this.getType());
		}
	}

	// 읽어 들일 항목의 값(this.getItemId()에 해당하는)을 읽었으나, Filtering 항목은 대문자이므로
	// 소문자(this.getItemId()에 해당하는)로 읽을 경우, 값이 없는 경우 발생함.
	// 이경우, 소문자(this.getItemId())를 대문자로 읽어서 읽혀진 경우, 해당 값을 리턴해 주고,
	// rs 에 소문자에 해당하는 값을 Put 해준다.
	private String checkCapsLetter(Map<String, Object> rs)  throws Exception{
		Object itemValue = rs.get(this.getItemId());
		if(itemValue == null) {
			itemValue = rs.get(this.getItemId().toUpperCase());
		}
		if(itemValue == null) {
			com.koreacb.kais.GlobalLogger.log(this,"ItemValue does not exist["+this.getItemId()+"]");
			return null;
		}else {
			rs.put(this.getItemId(), itemValue);  // 대소문자구분 때문에 추가 해줌.
		}
		return (String)itemValue;
	}
	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
}
