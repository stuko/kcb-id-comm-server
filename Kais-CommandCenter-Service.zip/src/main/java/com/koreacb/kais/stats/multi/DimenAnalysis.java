package com.koreacb.kais.stats.multi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DimenAnalysis {
	// 다차원 분석을 할 전체 정보(Root 차원의 정보)
	// Root 차원이 여러개일 경우를 대비하여, List로 개발함.(현재는 1개만 사용)
	List<RangeDimen> rangeDimenList = new ArrayList<>();
	public List<RangeDimen> getRangeDimenList() {
		return rangeDimenList;
	}
	public void setRangeDimenList(List<RangeDimen> rangeDimenList) {
		this.rangeDimenList = rangeDimenList;
	}
	public List<Map<String,Object>> toList() throws Exception{
		return this.getRangeDimenList().get(0).toList(null);
	}
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < this.getRangeDimenList().size() ; i++) {
			RangeDimen r = this.getRangeDimenList().get(i);
			sb.append(r.toString());
			sb.append("\n");
		}
		return sb.toString();
	}
}
