package com.koreacb.kais.stats.multi;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class ValueDimen{
	
	String itemId;
	String itemName;
	String type;
	boolean enableCount = false;
	boolean enableMin = false;
	boolean enableMax = false;
	boolean enableSum = false;
	boolean enableAvg = false;
	double count;
	double min;
	double max;
	double sum;
	double avg;
	double tot;
	boolean startMax = false;
	boolean startMin = false;
	
	DecimalFormat f = new DecimalFormat("#0.##");
	
	public boolean isStartMax() {
		return startMax;
	}
	public void setStartMax(boolean startMax) {
		this.startMax = startMax;
	}
	public boolean isStartMin() {
		return startMin;
	}
	public void setStartMin(boolean startMin) {
		this.startMin = startMin;
	}
	public boolean isEnableCount() {
		return enableCount;
	}
	public void setEnableCount(boolean enableCount) {
		this.enableCount = enableCount;
	}
	public boolean isEnableMin() {
		return enableMin;
	}
	public void setEnableMin(boolean enableMin) {
		this.enableMin = enableMin;
	}
	public boolean isEnableMax() {
		return enableMax;
	}
	public void setEnableMax(boolean enableMax) {
		this.enableMax = enableMax;
	}
	public boolean isEnableSum() {
		return enableSum;
	}
	public void setEnableSum(boolean enableSum) {
		this.enableSum = enableSum;
	}
	public boolean isEnableAvg() {
		return enableAvg;
	}
	public void setEnableAvg(boolean enableAvg) {
		this.enableAvg = enableAvg;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getCount() {
		return count;
	}
	public void setCount(double count) {
		this.count = count;
	}
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public double getTot() {
		return tot;
	}
	public void setTot(double tot) {
		this.tot = tot;
	}
	public double getAvg() {
		if(this.isEnableAvg()) {
			if(this.getCount() > 0)
				return this.getSum()/this.getCount();
			else return 0;
		}
		else return -1;
	}
	public Map<String,Object> toMap(){
		Map<String,Object> map = new HashMap<>();
		map.put("F_ID", this.getItemId());
		//map.put("ITEM_NAME", this.getItemName());
		map.put("AVG", f.format(this.getAvg()));
		map.put("MIN", f.format(this.getMin()));
		map.put("MAX", f.format(this.getMax()));
		map.put("SUM", f.format(this.getSum()));
		map.put("CNT", f.format(this.getCount()));
		map.put("TOT", f.format(this.getTot()));
		
		return map;
	}
	public String toString() {
		StringBuilder sb =new StringBuilder();
		sb.append("ID  = " + this.getItemId() + ",");
		sb.append("NAME  = " + this.getItemName() + ",");
		sb.append("ENABLE AVG = " + this.isEnableAvg() + ",");
		sb.append("ENABLE MIN = " + this.isEnableMin() + ",");
		sb.append("ENABLE MAX = " + this.isEnableMax() + ",");
		sb.append("ENABLE SUM = " + this.isEnableSum() + ",");
		sb.append("ENABLE CNT = " + this.isEnableCount() + "");
		sb.append("AVG = " + f.format(this.getAvg()) + ",");
		sb.append("MIN = " + f.format(this.getMin()) + ",");
		sb.append("MAX = " + f.format(this.getMax()) + ",");
		sb.append("SUM = " + f.format(this.getSum()) + ",");
		sb.append("CNT = " + f.format(this.getCount()) + "");
		sb.append("TOT = " + f.format(this.getTot()) + "");
		return sb.toString();
	}
	public void eval(Map<String, Object> rs) {
		// if(this.isEnableCount())this.setCount(this.getCount() + 1);
		// 카운트는 무조건 계산한다.
		this.setTot(this.getTot() + 1);
		if(rs.get(this.getItemId()) != null) this.setCount(this.getCount() + 1);
		if(this.isEnableMax()) {
			if(!this.isStartMax()) {
				this.setMax(Double.parseDouble(rs.get(this.getItemId()).toString()));
				this.setStartMax(true);
			}else {
				if(Double.parseDouble(rs.get(this.getItemId()).toString()) > this.getMax()) this.setMax(Double.parseDouble(rs.get(this.getItemId()).toString()));
			}
		}
		if(this.isEnableMin()) {
			if(!this.isStartMin()) {
				this.setMin(Double.parseDouble(rs.get(this.getItemId()).toString()));
				this.setStartMin(true);
			}else {
				if(Double.parseDouble(rs.get(this.getItemId()).toString()) < this.getMin()) this.setMin(Double.parseDouble(rs.get(this.getItemId()).toString()));
			}
		}
		if(this.isEnableSum())this.setSum(this.getSum() + Double.parseDouble(rs.get(this.getItemId()).toString()));
		
		com.koreacb.kais.GlobalLogger.log(this,this.toString());
		
	}
}
