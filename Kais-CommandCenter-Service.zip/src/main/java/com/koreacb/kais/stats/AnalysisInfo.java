package com.koreacb.kais.stats;

import java.util.HashMap;
import java.util.Map;

import com.koreacb.kais.stats.dist.DistAnalysis;
import com.koreacb.kais.stats.levelone.LevelOne;
import com.koreacb.kais.stats.leveltwo.LevelTwo;

public class AnalysisInfo {

	LevelOne levelOne;
	LevelTwo levelTwo;
	DistAnalysis distAnalysis;
	
	public AnalysisInfo() {
		levelOne = new LevelOne();
		levelTwo = new LevelTwo();
		distAnalysis = new DistAnalysis();
	}
	
	public LevelOne getLevelOne() {
		return levelOne;
	}
	public void setLevelOne(LevelOne levelOne) {
		this.levelOne = levelOne;
	}
	public LevelTwo getLevelTwo() {
		return levelTwo;
	}
	public void setLevelTwo(LevelTwo levelTwo) {
		this.levelTwo = levelTwo;
	}

	public DistAnalysis getDistAnalysis() {
		return distAnalysis;
	}

	public void setDistAnalysis(DistAnalysis distAnalysis) {
		this.distAnalysis = distAnalysis;
	}
	
	public Map<String,Object> toMap() throws Exception{
		Map<String,Object> m = new HashMap<>();
		m.put("LEVEL_ONE",this.getLevelOne().toMap());
		m.put("LEVEL_TWO",this.getLevelTwo().toMap());
		m.put("DIST_STATS",this.getDistAnalysis().toMap());
		return m;
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("---------------------------\n");
		sb.append(this.getLevelOne().toString());
		sb.append("\n");
		sb.append(this.getLevelTwo().toString());
		sb.append("\n");
		sb.append(this.getDistAnalysis().toString());
		sb.append("\n");
		sb.append("---------------------------\n");
		return sb.toString();
	}
	
}
