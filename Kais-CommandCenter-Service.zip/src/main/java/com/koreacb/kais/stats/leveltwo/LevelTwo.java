package com.koreacb.kais.stats.leveltwo;

import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.koreacb.kais.rule.util.CDF;

public class LevelTwo {
	
	int valueCount;
	double mode = 0;
	String modeValue = "0";
	String p5;
	String p10;
	String p25;
	String p50;
	String p75;
	String p90;
	String p95;
	CDF cdf = new CDF();
	
	LinkedHashMap<Object,Integer> distinctTable = new LinkedHashMap<>();
	Map<String,Integer> badCountTable = new HashMap<>();
	
	public String getModeValue() {
		return modeValue;
	}
	public void setModeValue(String modeValue) {
		this.modeValue = modeValue;
	}
	public LinkedHashMap<Object, Integer> getDistinctTable() {
		return distinctTable;
	}
	public void setDistinctTable(LinkedHashMap<Object, Integer> distinctTable) {
		this.distinctTable = distinctTable;
	}
	public Map<String, Integer> getBadCountTable() {
		return badCountTable;
	}
	public void setBadCountTable(Map<String, Integer> badCountTable) {
		this.badCountTable = badCountTable;
	}
	public int getValueCount() {
		return valueCount;
	}
	public void setValueCount(int valueCount) {
		this.valueCount = valueCount;
	}
	// 최빈값.
	public double getMode() {
		return mode;
	}
	public void setMode(double mode) {
		this.mode = mode;
	}
	public String getP5() {
		return p5;
	}
	public void setP5(String p5) {
		this.p5 = p5;
	}
	public String getP10() {
		return p10;
	}
	public void setP10(String p10) {
		this.p10 = p10;
	}
	public String getP25() {
		return p25;
	}
	public void setP25(String p25) {
		this.p25 = p25;
	}
	public String getP50() {
		return p50;
	}
	public void setP50(String p50) {
		this.p50 = p50;
	}
	public String getP75() {
		return p75;
	}
	public void setP75(String p75) {
		this.p75 = p75;
	}
	public String getP90() {
		return p90;
	}
	public void setP90(String p90) {
		this.p90 = p90;
	}
	public String getP95() {
		return p95;
	}
	public void setP95(String p95) {
		this.p95 = p95;
	}
	public Map<String,Object> toMap() throws Exception{
		Map<String,Object> m =new HashMap<>();
		DecimalFormat f = new DecimalFormat("#0.##");
		m.put("MODE",cdf.IS_NUMBER(this.getModeValue()) ? f.format(Double.parseDouble(this.getModeValue())) : this.getModeValue());
		m.put("P5", cdf.IS_NUMBER(this.getP5()) ? f.format(Double.parseDouble(this.getP5())) : this.getP5() );
		m.put("P10",cdf.IS_NUMBER(this.getP10()) ? f.format(Double.parseDouble(this.getP10())) : this.getP10() );
		m.put("P25",cdf.IS_NUMBER(this.getP25()) ? f.format(Double.parseDouble(this.getP25())) : this.getP25() );
		m.put("P50",cdf.IS_NUMBER(this.getP50()) ? f.format(Double.parseDouble(this.getP50())) : this.getP50() );
		m.put("P75",cdf.IS_NUMBER(this.getP75()) ? f.format(Double.parseDouble(this.getP75())) : this.getP75() );
		m.put("P90",cdf.IS_NUMBER(this.getP90()) ? f.format(Double.parseDouble(this.getP90())) : this.getP90() );
		m.put("P95",cdf.IS_NUMBER(this.getP95()) ? f.format(Double.parseDouble(this.getP95())) : this.getP95() );
		m.put("VALUE",cdf.IS_NUMBER(this.getValueCount()) ? f.format(this.getValueCount()) : this.getValueCount() );
		return m;
	}
	public String toString() {
		return "Mode = " + this.getModeValue()
			+ ", P5 = " + this.getP5() 
			+ ", P10 = " + this.getP10() 
			+ ", P25 = " + this.getP25() 
			+ ", P50 = " + this.getP50() 
			+ ", P75 = " + this.getP75() 
			+ ", P90 = " + this.getP90() 
			+ ", P95 = " + this.getP95() 
			+ ", VC = " + this.getValueCount();
	}
	
	public void preAnalysis(Object v )  throws Exception{
		this.preAnalysis(v, false);
	}
	
	public void preAnalysis(Object v , boolean bad)  throws Exception{
		if(!this.getDistinctTable().containsKey(v.toString())) this.getDistinctTable().put(v.toString() , 1);
		else this.getDistinctTable().put(v.toString() , this.getDistinctTable().get(v.toString())+1);
		if(bad) {
			if(! this.getBadCountTable().containsKey(v.toString())) this.getBadCountTable().put(v.toString(), 1);
			else this.getBadCountTable().put(v.toString() , this.getBadCountTable().get(v.toString())+1);
		}
	}
	
	public void eval(int totalCount ,Object min , Object max)  throws Exception{
		int mod = 0;
		String modValue = "";
		
		this.setValueCount(this.getDistinctTable().size());
		
		// 최빈값.
		for(Object k : this.getDistinctTable().keySet()) {
			if(this.getDistinctTable().get(k) != null 
		   && !this.getDistinctTable().get(k).toString().equals("")
		   && this.getDistinctTable().get(k) > mod) {
				mod = this.getDistinctTable().get(k);
				modValue = k.toString();
			}
		}
		// 가장 건수가 많은 값.
		this.setMode(mod);
		this.setModeValue(modValue);
		
		// Consider about the MEMORY : OOM
		LinkedHashMap<Object,Integer> map = new LinkedHashMap<>(); 

		this.getDistinctTable().entrySet()
							   .stream()
							   .sorted(new Comparator<Entry<Object,Integer>>() {
									@Override
									public int compare(Entry<Object, Integer> comp1, Entry<Object, Integer> comp2) {
										// MIN,MAX가 숫자형이면, 키값을 Double로 변형하여, 비교후 소팅
										com.koreacb.kais.GlobalLogger.log(this," MIN/MAX : " + min + "/" + max);
										
										// 2018.08.22
										// min / max 가 0(초기화) 상태인 경우가 있음.
										// 아래 계산 가능한 값들인지 확인후, 처리하도록 변경함.
										boolean isCalculatable = false;
										String s1 = null ;
										String s2 = null;
										Double d1 = null ;
										Double d2 = null;
										try {
											s1 = (String)comp1.getKey();
											s2 = (String)comp2.getKey();
											d1 = Double.valueOf(s1);
											d2 = Double.valueOf(s2);
											isCalculatable = true;
										}catch(Exception e) {}
										
										if(isCalculatable && cdf.IS_NUMBER(min) && cdf.IS_NUMBER(max) && d1 != null && d2 != null) {
											return d1.compareTo(d2);
										}
										// MIN,MAX가 숫자형이 아니면, String으로 변환 하여, 비교후 소팅
										else {
											return s1.compareTo(s2);
										}
									}
							   }).forEachOrdered((x) -> map.put(x.getKey(), x.getValue()));
		
		
		
		this.setDistinctTable(map);
		double[] currentAcumTotal = new double[2];
		currentAcumTotal[1] = totalCount;
		
		map.forEach((k, v) -> {
			currentAcumTotal[0] += v;
			double percent = 100 * (currentAcumTotal[0]/currentAcumTotal[1]);
			// com.koreacb.kais.GlobalLogger.log(this,">>>>>>>>>>> Percent = ["+currentAcumTotal[0]+"]/["+totalCount+"]" + percent + "%");
			if(this.getP5() == null && percent >= 5 && percent < 10) {
				this.setP5(k + "");
				com.koreacb.kais.GlobalLogger.log(this," SET P5 : " + k);
			}
			if(this.getP10() == null && percent >= 10 && percent < 25) {
				if(this.getP5() == null) this.setP5(k + "");
				this.setP10(k + "");
				com.koreacb.kais.GlobalLogger.log(this," SET P10 : " + k);
			}
			if(this.getP25() == null && percent >= 25 && percent < 50) {
				if(this.getP5() == null) this.setP5(k + "");
				if(this.getP10() == null) this.setP10(k + "");
				this.setP25(k + "");
				com.koreacb.kais.GlobalLogger.log(this," SET P25 : " + k);
			}
			if(this.getP50() == null && percent >= 50 && percent < 75) {
				if(this.getP5() == null) this.setP5(k + "");
				if(this.getP10() == null) this.setP10(k + "");
				if(this.getP25() == null) this.setP25(k + "");
				this.setP50(k + "");
				com.koreacb.kais.GlobalLogger.log(this," SET P50 : " + k);
			}
			if(this.getP75() == null && percent >= 75 && percent < 90) {
				if(this.getP5() == null) this.setP5(k + "");
				if(this.getP10() == null) this.setP10(k + "");
				if(this.getP25() == null) this.setP25(k + "");
				if(this.getP50() == null) this.setP50(k + "");
				this.setP75(k + "");
				com.koreacb.kais.GlobalLogger.log(this," SET P75 : " + k);
			}
			if(this.getP90() == null && percent >= 90 && percent < 95) {
				if(this.getP5() == null) this.setP5(k + "");
				if(this.getP10() == null) this.setP10(k + "");
				if(this.getP25() == null) this.setP25(k + "");
				if(this.getP50() == null) this.setP50(k + "");
				if(this.getP75() == null) this.setP75(k + "");
				this.setP90(k + "");
				com.koreacb.kais.GlobalLogger.log(this," SET P90 : " + k);
			}
			if(this.getP95() == null && percent >= 95) {
				if(this.getP5() == null) this.setP5(k + "");
				if(this.getP10() == null) this.setP10(k + "");
				if(this.getP25() == null) this.setP25(k + "");
				if(this.getP50() == null) this.setP50(k + "");
				if(this.getP75() == null) this.setP75(k + "");
				if(this.getP90() == null) this.setP90(k + "");
				this.setP95(k + "");
				com.koreacb.kais.GlobalLogger.log(this," SET P95 : " + k);
			}
		});

		if(this.getP5() == null) this.setP5("-1");
		if(this.getP10() == null) this.setP10("-1");
		if(this.getP25() == null) this.setP25("-1");
		if(this.getP50() == null) this.setP50("-1");
		if(this.getP75() == null) this.setP75("-1");
		if(this.getP90() == null) this.setP90("-1");
		if(this.getP95() == null) this.setP95("-1");
		
		com.koreacb.kais.GlobalLogger.log(this,">>>>>>>> LevelTwo :  " + this.toString());
	}
	
}
