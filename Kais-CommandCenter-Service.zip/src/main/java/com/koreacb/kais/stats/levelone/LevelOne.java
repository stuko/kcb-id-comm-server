package com.koreacb.kais.stats.levelone;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import com.koreacb.kais.rule.util.CDF;

public class LevelOne {
	
	CDF cdf = new CDF();
	boolean number = true;
	int totalCount;
	int validCount;
	int nullCount;
	int specialValueCount;
	int zeroCount;
	double max;
	String strMax ="";
	double min;
	String strMin ="";
	double sum;
	double avg;
	boolean startMin = false;
	boolean startMax = false;
	
	public boolean isStartMin() {
		return startMin;
	}
	public void setStartMin(boolean startMin) {
		this.startMin = startMin;
	}
	public boolean isStartMax() {
		return startMax;
	}
	public void setStartMax(boolean startMax) {
		this.startMax = startMax;
	}
	public String getStrMax() {
		return strMax;
	}
	public void setStrMax(String strMax) {
		this.strMax = strMax;
	}
	public String getStrMin() {
		return strMin;
	}
	public void setStrMin(String strMin) {
		this.strMin = strMin;
	}
	public boolean isNumber() {
		return number;
	}
	public void setNumber(boolean number) {
		this.number = number;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public int getValidCount() {
		return this.getTotalCount() - (this.getNullCount() + this.getSpecialValueCount());
	}
	public void setValidCount(int validCount) {
		this.validCount = validCount;
	}
	public int getNullCount() {
		return nullCount;
	}
	public void setNullCount(int nullCount) {
		this.nullCount = nullCount;
	}
	public int getSpecialValueCount() {
		return specialValueCount;
	}
	public void setSpecialValueCount(int specialValueCount) {
		this.specialValueCount = specialValueCount;
	}
	public int getZeroCount() {
		return zeroCount;
	}
	public void setZeroCount(int zeroCount) {
		this.zeroCount = zeroCount;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public double getAvg() {
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	public Map<String,Object> toMap() throws Exception{
		Map<String,Object> m =new HashMap<>();
		DecimalFormat f = new DecimalFormat("#0.##");
		m.put("AVG",f.format(this.getAvg()));
		m.put("MAX", this.isNumber() ? f.format(this.getMax()) : this.getStrMax());
		m.put("MIN", this.isNumber() ? f.format(this.getMin()) : this.getStrMin());
		m.put("NULL",f.format(this.getNullCount()));
		m.put("SV",f.format(this.getSpecialValueCount()));
		m.put("SUM", f.format(this.getSum()));
		m.put("TOTAL", f.format(this.getTotalCount()));
		m.put("VALID",f.format(this.getValidCount()));
		m.put("ZERO", f.format(this.getZeroCount()));
		return m;
	}
	
	public String toString() {
		return "AVG = " + this.getAvg() 
			+ ", MAX = " + (this.isNumber() ? this.getMax() : this.getStrMax()) 
			+ ", MIM = " + (this.isNumber() ? this.getMin() : this.getStrMin()) 
			+ ", NULL = " + this.getNullCount() 
			+ ", SV = " + this.getSpecialValueCount() 
			+ ", SUM = " + this.getSum() 
			+ ", TOT = " + this.getTotalCount() 
			+ ", VALID = " + this.getValidCount() 
			+ ", ZERO = " + this.getZeroCount();
	}
	
	public void eval(Object v , String[] svArray)  throws Exception{
		
		this.setTotalCount(this.getTotalCount()+1);
		if(v == null || v.toString().trim().equals("")) {
			this.setNullCount(this.getNullCount()+1);
			return;
		}
		
		boolean findSv = false;
		if(svArray != null && svArray.length > 0) {
			for(String sv : svArray) {
				if(v.toString().trim().equals(sv)) {
					this.setSpecialValueCount(this.getSpecialValueCount()+1);
					findSv = true;
					break;
				}		
				if(findSv)break;
			}
		}
		if(findSv)return;
		
		if(cdf.IS_NUMBER(v)) {
			this.setNumber(true);
		}else {
			this.setNumber(false);
		}
		
		if(cdf.IS_NUMBER(v)) {
			if(!this.isStartMax()) {
				this.setMax(Double.parseDouble(v.toString()));
				this.setStartMax(true);
			}else {
				this.setMax(Double.parseDouble(v.toString()) > this.getMax() ? Double.parseDouble(v.toString()) :this.getMax());
			}
		}else {
			if(!this.isStartMax()) {
				this.setStrMax(v.toString());
				this.setStartMax(true);
			}else {
				if(this.getStrMax().equals(null)) {
					this.setStrMax(v.toString());
				}else {
					this.setStrMax((String)cdf.MAX(this.getStrMax(),v.toString()));
				}
			}
		}
		
		if(cdf.IS_NUMBER(v)) {
			if(!this.isStartMin()) {
				this.setMin(Double.parseDouble(v.toString()));
				this.setStartMin(true);
			}else {
				this.setMin(Double.parseDouble(v.toString()) < this.getMin() ? Double.parseDouble(v.toString()) :this.getMin());
			}
		}else {
			if(!this.isStartMin()) {
				this.setStrMin(v.toString());
				this.setStartMin(true);
			}else {
				this.setStrMin((String)cdf.MIN(this.getStrMin(),v.toString()));
			}
		}
		
		if(cdf.IS_NUMBER(v))this.setSum(Double.parseDouble(v.toString()) + this.getSum());
		if(cdf.IS_NUMBER(v))this.setAvg(this.getSum()/(this.getTotalCount()-this.getNullCount()));
		if(v.toString().equals("0")) this.setZeroCount(this.getZeroCount() + 1);
	}
	
}
