package com.koreacb.kais.stats.multi;

import java.util.HashMap;
import java.util.Map;

import com.koreacb.kais.rule.constant.Constant;
import com.koreacb.kais.rule.parser.eo.EDataType;
import com.koreacb.kais.rule.parser.eo.EHighConditionType;
import com.koreacb.kais.rule.parser.eo.ELowConditionType;
import com.koreacb.kais.rule.script.ScriptCore;
import com.koreacb.kais.rule.script.ScriptRunner;
import com.koreacb.kais.rule.util.useScript.KAIF;

public class RangeRule {
	
	String upperOperand;
	String upper;
	double doubleUpper;
	String lowerOperand;
	String lower;
	double doubleLower;
	String name;
	String type;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUpper() {
		return upper;
	}
	public void setUpper(String upper) {
		this.upper = upper;
	}
	public String getLower() {
		return lower;
	}
	public void setLower(String lower) {
		this.lower = lower;
	}
	public double getDoubleUpper() {
		return doubleUpper;
	}
	public void setDoubleUpper(double doubleUpper) {
		this.doubleUpper = doubleUpper;
	}
	public double getDoubleLower() {
		return doubleLower;
	}
	public void setDoubleLower(double doubleLower) {
		this.doubleLower = doubleLower;
	}
	public String getUpperOperand() {
		return upperOperand;
	}
	public void setUpperOperand(String upperOperand) {
		this.upperOperand = upperOperand;
	}
	public String getLowerOperand() {
		return lowerOperand;
	}
	public void setLowerOperand(String lowerOperand) {
		this.lowerOperand = lowerOperand;
	}
	public boolean eval(Map<String,Object> rs) throws Exception{
		String lower = this.getCondition(true, rs, this.getName(), this.getType(), this.getLowerOperand() , this.getLower());
		String upper = this.getCondition(false, rs, this.getName(), this.getType(), this.getUpperOperand() , this.getUpper());
		ScriptCore sc = new ScriptCore();
		Map<String,Object> map = new HashMap<>();
		map.put(ScriptRunner.KAIS_PARAM_PREFIX, rs);
		Boolean b1 = false;
		try{b1 = (Boolean)sc.runScript("("+lower+")", map);}catch(Exception e) {e.printStackTrace(); throw new Exception("RangRule condition script Exception(Upper)");}
		Boolean b2 = false;
		try{b2 = (Boolean)sc.runScript("("+upper+")", map);}catch(Exception e) {e.printStackTrace(); throw new Exception("RangRule condition script Exception(Lower)");}
		// com.koreacb.kais.GlobalLogger.log(this,"#### EVAL #### ["+this.getName()+"] LOWER : ["+lower+"]["+b1+"], MAP : ["+rs+"]");
		// com.koreacb.kais.GlobalLogger.log(this,"#### EVAL #### ["+this.getName()+"] UPPER : ["+upper+"]["+b2+"], MAP : ["+rs+"]");

		return (b1 && b2);
	}

	public String getCondition(boolean isLower, Map<String,Object> rs, String name, String type, String op, String v) {
		com.koreacb.kais.GlobalLogger.log(this,"name = ["+name+"]");
		com.koreacb.kais.GlobalLogger.log(this,"op = ["+op+"]");
		com.koreacb.kais.GlobalLogger.log(this,"type = ["+type+"]");
		StringBuilder sb = new StringBuilder();
		if(isLower) {
			//================================================================
			//< generate the low condition
			//================================================================
			//< none
			if(ELowConditionType.conditionTypOf(op) == ELowConditionType.AN) {
				sb.append(ELowConditionType.AN.getValue());
			}
			//< script
			else if(ELowConditionType.conditionTypOf(op) == ELowConditionType.ST) {
				sb.append("(").append(v).append(")");
			}
			else if(ELowConditionType.conditionTypOf(op) == ELowConditionType.IN) {
				sb.append(ScriptRunner.KAIS_FUNCTION_PREFIX).append(".IN(")
				.append(ScriptRunner.KAIS_PARAM_PREFIX)
				.append(Constant.SCRIPT_DOT)
				.append("get(")
				.append("\"" + name + "\"")
				.append(")")
				.append(", \"")
				.append(v).append("\")");
			}
			else if(ELowConditionType.conditionTypOf(op) == ELowConditionType.NN) {
				sb.append("!" + ScriptRunner.KAIS_FUNCTION_PREFIX)
				.append(".IN(")
				.append(ScriptRunner.KAIS_PARAM_PREFIX)
				.append(Constant.SCRIPT_DOT)
				.append("get(")
				.append("\"" + name + "\"")
				.append(")")
				.append(", \"")
				.append(v).append("\")");
			}
			else {
				sb.append(getConditionExpression(rs,name, type, op,v,true));
			}
		}else {				
			
			//================================================================
			//< generate the high condition
			//================================================================
			//< none
			if(EHighConditionType.conditionTypOf(op) == EHighConditionType.AN) {
				sb.append(EHighConditionType.AN.getValue());
			}
			//< script
			else if(EHighConditionType.conditionTypOf(op) == EHighConditionType.ST) {
				sb.append("(").append(v).append(")");
			}
			else {
				sb.append(getConditionExpression(rs,name, type, op,v,false));
			}
		}
		
		return sb.toString();
	}
	
	public String getConditionExpression(Map<String,Object> rs, String name, String type, String op, String v , boolean isLowCondition) {
		StringBuilder sb = new StringBuilder();
		
		//< set the item identifier
		String itemId = name;
		//< set the condition value
		String conditionValue = v + "";
		//< set the condition type
		String conditionType = (isLowCondition ? ELowConditionType.conditionTypOf(op).getValue() : EHighConditionType.conditionTypOf(op).getValue());
		
		//< if item data is exist
		if(rs.containsKey(itemId)) {
			//< get the data type
			EDataType eDataType = EDataType.dataTypeOf(type);
			if(eDataType == EDataType.STR || eDataType == EDataType.SDT || eDataType == EDataType.DTE) {
				sb.append(ScriptRunner.KAIS_PARAM_PREFIX)
				.append(Constant.SCRIPT_DOT)
				.append("get(")
				.append("\"" + itemId + "\"")
				.append(")")
				.append(" != null && ")
				.append(ScriptRunner.KAIS_PARAM_PREFIX)
				.append(Constant.SCRIPT_DOT)
				.append("get(")
				.append("\"" + itemId + "\"")
				.append(")")
				.append(Constant.SCRIPT_DOT)
				.append("compareTo(")
				.append((eDataType == EDataType.DTE ? "" : "\""))
				.append(conditionValue).append((eDataType == EDataType.DTE ? "" : "\""))
				.append(")")
				.append(conditionType).append("0");
			}
			else if(eDataType == EDataType.BLN) {
				sb.append(Constant.SCRIPT_MEANINGLESS);
			}
			//< integer and number
			else {
				sb.append(ScriptRunner.KAIS_PARAM_PREFIX)
				.append(Constant.SCRIPT_DOT)
				.append("get(")
				.append("\"" + itemId + "\"")
				.append(")")
				.append(conditionType)
				.append(KAIF.TO_NUMBER(conditionValue));
			}
		} 
		else {
			sb.append(Constant.SCRIPT_MEANINGLESS);
		}
		
		return sb.toString();
	}
}
