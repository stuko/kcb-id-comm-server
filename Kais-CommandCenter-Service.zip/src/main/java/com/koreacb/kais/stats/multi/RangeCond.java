package com.koreacb.kais.stats.multi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RangeCond extends RangeRule implements Cloneable{

	String sprtId;
	
	RangeDimen rangeDimen;
	String rangeName;
	
	public RangeDimen getRangeDimen() {
		return rangeDimen;
	}

	public void setRangeDimen(RangeDimen rangeDimen) {
		this.rangeDimen = rangeDimen;
	}

	public String getRangeName() {
		return rangeName;
	}
	
	public void setRangeName(String rangeName) {
		this.rangeName = rangeName;
	}
	
	public String getSprtId() {
		return sprtId;
	}
	public void setSprtId(String sprtId) {
		this.sprtId = sprtId;
	}


	public Map<String,Object> toMap(){
		Map<String,Object> map = new HashMap<>();
		// map.put("SPRTID", this.getSprtId());
		List<Map<String,Object>> list = new ArrayList<>();
		
		for(ValueDimen vd : this.getRangeDimen().getValueDimen()) {
			Map<String,Object> m = vd.toMap();
			// m.put("F_ID" , this.getSprtId());
			list.add(m);
		}
		map.put("FACT_LIST",list );
		return map;
	}
	
	public List<Map<String,Object>> toList(){
		Map<String,Object> map = new HashMap<>();
		// map.put("SPRTID", this.getSprtId());
		List<Map<String,Object>> list = new ArrayList<>();
		for(ValueDimen vd : this.getRangeDimen().getValueDimen()) {
			Map<String,Object> m = vd.toMap();
			// m.put("F_ID" , this.getSprtId());
			list.add(m);
		}
		return list;
	}
	
	public boolean eval2(Map<String,Object> rs) {
		if(eval2(rs,this.getName(),this.getUpperOperand(),this.getDoubleUpper())
		    && eval2(rs,this.getName(),this.getLowerOperand(),this.getDoubleLower())) return true;
		else return false;
	}
	
	public boolean eval2(Map<String,Object> rs, String name, String op, double v) {
		if(op.equals("==")) {
			if(Double.parseDouble(rs.get(name).toString()) == v) return true;
			else return false;
		}else if(op.equals("!=")) {
			if(Double.parseDouble(rs.get(name).toString()) != v) return true;
			else return false;
		}else if(op.equals(">=")) {
			if(Double.parseDouble(rs.get(name).toString()) >= v) return true;
			else return false;
		}else if(op.equals("<=")) {
			if(Double.parseDouble(rs.get(name).toString()) <= v) return true;
			else return false;
		}else if(op.equals(">")) {
			if(Double.parseDouble(rs.get(name).toString()) > v) return true;
			else return false;
		}else if(op.equals("<")) {
			if(Double.parseDouble(rs.get(name).toString()) < v) return true;
			else return false;
		}
		return false;
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	
	
}