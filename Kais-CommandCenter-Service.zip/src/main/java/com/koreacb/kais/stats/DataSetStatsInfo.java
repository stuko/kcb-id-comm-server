package com.koreacb.kais.stats;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreacb.kais.Constants;
import com.koreacb.kais.data.server.load.DataSetDataLoadInfo;
import com.koreacb.kais.mybatis.DataSetCallBack;
import com.koreacb.kais.mybatis.MultiMyBatisUtils;
import com.koreacb.kais.rule.constant.Constant;
import com.koreacb.kais.stats.multi.DimenAnalysis;
import com.koreacb.kais.stats.multi.RangeDimen;
import com.koreacb.kais.status.LoadingAndStatsStatusManager;
import com.koreacb.kais.status.StatsStore;
import com.koreacb.kais.status.StatusManager;

public class DataSetStatsInfo {
	
	String dataSetId;
	String dataSetLoadingTableId;
	String dataLoadId;
	String analId;

	StatusManager status;
	
	DataSetDataLoadInfo dataSetDataLoadInfo;
	
	List<Map<String,Object>> itemInf;
	List<Map<String,Object>> cond;

	int analysisType = 0;
	public static int BASIC = 0;
	public static int DIMEN = 1;
	
	Map<String,AnalysisInfo> analysisMap;
	DimenAnalysis dimenAnalysis;
	
	DataSetCallBack callBack;
	
	int totalCount = 0;
	int errCount = 0;

	StringBuilder sb;
	
	public DataSetStatsInfo() {
		sb = new StringBuilder();
		status = new StatusManager();
		analysisMap = new HashMap<>();
		dimenAnalysis = new DimenAnalysis();
	}
	
	public DataSetStatsInfo(DataSetCallBack callBack) {
		this.setCallBack(callBack);
		sb = new StringBuilder();
		status = new StatusManager();
		analysisMap = new HashMap<>();
		dimenAnalysis = new DimenAnalysis();
	}

	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public int getErrCount() {
		return errCount;
	}
	public void setErrCount(int errCount) {
		this.errCount = errCount;
	}
	public StatusManager getStatus() {
		return status;
	}

	public void setStatus(StatusManager status) {
		this.status = status;
	}

	public DataSetCallBack getCallBack() {
		return callBack;
	}
	public void setCallBack(DataSetCallBack callBack) {
		this.callBack = callBack;
	}
	public DimenAnalysis getDimenAnalysis() {
		return dimenAnalysis;
	}
	public void setDimenAnalysis(DimenAnalysis dimenAnalysis) {
		this.dimenAnalysis = dimenAnalysis;
	}
	public DataSetDataLoadInfo getDataSetDataLoadInfo() {
		return dataSetDataLoadInfo;
	}
	public void setDataSetDataLoadInfo(DataSetDataLoadInfo dataSetDataLoadInfo) {
		this.dataSetDataLoadInfo = dataSetDataLoadInfo;
	}
	public List<Map<String, Object>> getItemInf() {
		return itemInf;
	}
	public void setItemInf(List<Map<String, Object>> itemInf) {
		this.itemInf = itemInf;
	}
	public Map<String, AnalysisInfo> getAnalysisMap() {
		return analysisMap;
	}
	public void setAnalysisMap(Map<String, AnalysisInfo> analysisMap) {
		this.analysisMap = analysisMap;
	}
	public int getAnalysisType() {
		return analysisType;
	}
	public void setAnalysisType(int analysisType) {
		this.analysisType = analysisType;
	}
	public List<Map<String, Object>> getCond() {
		return cond;
	}
	public void setCond(List<Map<String, Object>> cond) {
		this.cond = cond;
	}
	public String getDataSetLoadingTableId() {
		return dataSetLoadingTableId;
	}
	public void setDataSetLoadingTableId(String dataSetLoadingTableId) {
		this.dataSetLoadingTableId = dataSetLoadingTableId;
	}
	public String getAnalId() {
		return analId;
	}
	public void setAnalId(String analId) {
		this.analId = analId;
	}
	public String getDataSetId() {
		return dataSetId;
	}
	public void setDataSetId(String dataSetId) {
		this.dataSetId = dataSetId;
	}
	public String getDataLoadId() {
		return dataLoadId;
	}
	public void setDataLoadId(String dataLoadId) {
		this.dataLoadId = dataLoadId;
	}

	public String toString() {
		for(String k : this.getAnalysisMap().keySet()) {
			sb.append(this.getAnalysisMap().get(k).toString());
			sb.append("\n");
		}
		return sb.toString();
	}

	public boolean analysis(boolean status) throws Exception {
		return analysis(status, null,true);
	}

	public boolean analysis(boolean status, String env) throws Exception {
		return analysis(status, env,true);
	}

	public boolean analysis(boolean status, String env, boolean isSave) throws Exception {
		StatsStore store = new StatsStore();
		MultiMyBatisUtils source = null;
		if(env != null) source = new MultiMyBatisUtils(env, this.getDataSetDataLoadInfo(),true,(rs,rowCount, colCount)->{
									if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(getDataSetId(),getDataLoadId()))return false;
									return analysisOneRecord(status , rs, rowCount);
								});
		else source = new MultiMyBatisUtils(this.getDataSetDataLoadInfo(),true,(rs,rowCount, colCount)->{
							if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(getDataSetId(),getDataLoadId()))return false;
							return analysisOneRecord(status , rs, rowCount);
						});

		source.setFetchSize(500); 
		source.executeDataSetLoad();
		source.clear();
		
		// 중간에 취소가 요청된 경우
		if(source.isBreakInReading()) {
			return false;
		}
		
		// 통계 분석시, 데이터 건수가 0 이면, 에러로 상태를 업데이트 한다.
		if(this.getTotalCount() == 0) {
			this.err(getDataSetId(),getDataLoadId());
			return false;
		}
		
		analysisLevelTwo();
		
		if(this.getCallBack() != null) {
			this.getCallBack().callBizLogicInReading(status, this.getTotalCount(), true, null, null, "C", getTotalCount() , getErrCount());
		}else {
			this.ok(getDataSetId(),getDataLoadId());
		}
		
		if(isSave) {
			if(this.getErrCount() == 0) {
				store.saveStatsLevelOneTwoResultInTable(this.getDataSetDataLoadInfo().getDataSetId()
														, this.getDataLoadId()
														, this.getDataSetDataLoadInfo().getDataSetLoadingTableId()
														, this.getDataSetDataLoadInfo().getLoadingCond()
														, this.getAnalysisMap());
			}
		}
		com.koreacb.kais.GlobalLogger.log(this,">>>>>>>>>>>>> Forced Updating....: Status");
		this.ok(getDataSetId(),getDataLoadId(), getTotalCount() , getErrCount());
		com.koreacb.kais.GlobalLogger.log(this,">>>>>>>>>>>>> Forced Updated.. : Status");
		
		return true;
	}

	private boolean analysisOneRecord(boolean status, Map<String, Object> rs, int rowCount) throws Exception{
		try {
			//com.koreacb.kais.GlobalLogger.log(this,"[Analysis] : ["+rs+"]");
			this.setTotalCount(this.getTotalCount()+1);
			if(this.getCallBack() != null) {
				this.getCallBack().callBizLogicInReading(status, rowCount, false, rs , null , "X", getTotalCount() , getErrCount());
			}
			analysisLevelOne(rs);	
			LoadingAndStatsStatusManager.getInstance().setLoadingAndStatsCount(getDataSetId(),getDataLoadId() , rowCount);
			if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(getDataSetId(),getDataLoadId()))return false;
			setTotalCount(rowCount);
		} catch (Exception e) {
			setErrCount(getErrCount()+1);
			this.err(getDataSetId(),getDataLoadId());
			e.printStackTrace();
			com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+e.toString()+"]");
		}
		return true;
	}	
	
	public void analysisLevelTwo() throws Exception {
		for(String k : this.getAnalysisMap().keySet()) {
			AnalysisInfo v = this.getAnalysisMap().get(k);
			v.getLevelTwo().eval(v.getLevelOne().getTotalCount(), v.getLevelOne().getMin(), v.getLevelOne().getMax());
			v.getDistAnalysis().setItemId(k);
			v.getDistAnalysis().eval(v.getLevelTwo().getDistinctTable(), v.getLevelTwo().getBadCountTable(), v.getLevelOne().getMin(), v.getLevelOne().getMax());
			com.koreacb.kais.GlobalLogger.log(this,"Analysis : ["+k+"] : " + v.toMap());
		}
	}
	
	// RS : 데이터 셋의 로딩된 모든 칼럼 + JSON칼럼의 각 키/값들을 RS에 넣어줌.
	// 2018.08.02
	// Preformance 칼럼을 분석하여 통계에 추가하는 작업 필요
	public void analysisLevelOne(Map<String, Object> rs) throws Exception {
		// ITEM 지정한 항목에 대해서, 분석을 실행함.
		if(this.getItemInf() != null && this.getItemInf().size() > 0) {
			for(Map<String,Object> item : getItemInf()) {
				String svs = null;
				String[] sva = null;
				// 2018.08.13
				// Special Value 처리 로직 추가 함.
				if(item.containsKey(Constants.SPECIAL_VALUE) && item.get(Constants.SPECIAL_VALUE) != null) {
					svs = (String)item.get(Constants.SPECIAL_VALUE);
					sva = svs.split(",");
				}
				for(String k : item.keySet()) {
					Object v = item.get(k);
					if(k.equals(Constants.ANL_ITM_ID) && v != null) {
						
						if(getAnalysisMap().get(v.toString()) == null)getAnalysisMap().put(v.toString(), new AnalysisInfo());
						getAnalysisMap().get(v.toString()).getLevelOne().eval(rs.get(v), sva);
						if(rs.get(v) != null) {
							if(rs.containsKey(Constants.PERF_COLUMN) && rs.get(Constants.PERF_COLUMN) != null) {
								boolean bad = "1".equals(rs.get(Constants.PERF_COLUMN).toString()) ? true : false;
								getAnalysisMap().get(v.toString()).getLevelTwo().preAnalysis(rs.get(v), bad);
							}else {
								getAnalysisMap().get(v.toString()).getLevelTwo().preAnalysis(rs.get(v));
							}
						}
					}
				}
			}
		}
	}

	public boolean analysisDimention() throws Exception{
		return this.analysisDimention(null, true);
	}
	
	public boolean analysisDimention(String env) throws Exception{
		return this.analysisDimention(env, true);
	}
	
	public boolean analysisDimention(String env, boolean isSave) throws Exception {
		
		StatsStore store = new StatsStore();
		
		MultiMyBatisUtils source = null;
		if(env != null) source = new MultiMyBatisUtils(env, this.getDataSetDataLoadInfo(),true,(rs,rowCount, colCount)->{
										if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(getDataSetId(),getDataLoadId()))return false;
										return analysisDimenOneRecord(rs, rowCount);
									});
		else source = new MultiMyBatisUtils(this.getDataSetDataLoadInfo(),true,(rs,rowCount, colCount)->{
										if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(getDataSetId(),getDataLoadId()))return false;
										return analysisDimenOneRecord(rs, rowCount);
									});
		
		source.setFetchSize(500); 
		source.executeDataSetLoad();
		source.clear();

		// 중간에 취소가 요청된 경우
		if(source.isBreakInReading()) {
			return false;
		}

		// 통계 분석시, 데이터 건수가 0 이면, 에러로 상태를 업데이트 한다.
		if(this.getTotalCount() == 0) {
			this.err(getDataSetId(),getDataLoadId());
			return false;
		}
		
		if(this.getCallBack() != null) {
			this.getCallBack().callBizLogicInReading(true, this.getTotalCount(), true, null , null,  "C", getTotalCount() , getErrCount());
		}
		
		if(isSave) {
			if(this.getErrCount() == 0) {
				store.saveStatsDimensionResultInTable(this.getDataSetDataLoadInfo().getDataSetId()
													, this.getDataLoadId()
													, this.getDataSetDataLoadInfo().getDataSetLoadingTableId()
													, this.getDataSetDataLoadInfo().getLoadingCond()
													, this.getDimenAnalysis());
			}
		}
		
		com.koreacb.kais.GlobalLogger.log(this,">>>>>>>>>>>>> Forced Updating....: Status");
		this.ok(getDataSetId(),getDataLoadId(), getTotalCount() , getErrCount());
		com.koreacb.kais.GlobalLogger.log(this,">>>>>>>>>>>>> Forced Updated.. : Status");
		
		return true;
	}

	private boolean analysisDimenOneRecord(Map<String, Object> rs, int rowCount) throws Exception {
		try {
			com.koreacb.kais.GlobalLogger.log(this,"[DimenAnalysis's Data] = " + rs);
			if(this.getCallBack() != null) {
				this.getCallBack().callBizLogicInReading(true, rowCount, false, rs , null, "X", getTotalCount() , getErrCount());
			}
			if(getDimenAnalysis().getRangeDimenList() != null &&  getDimenAnalysis().getRangeDimenList().size() > 0) {
				for(RangeDimen rd : getDimenAnalysis().getRangeDimenList()) {
					com.koreacb.kais.GlobalLogger.log(this,"#### DimenAnalysis ####");
					com.koreacb.kais.GlobalLogger.log(this,rd.toString());
					com.koreacb.kais.GlobalLogger.log(this,"#### DimenAnalysis ####");
					rd.eval(rs , null);
				}
			}
			setTotalCount(getTotalCount()+1);
		} catch (Exception e) {
			setErrCount(getErrCount()+1);
			this.err(getDataSetId(),getDataLoadId());
			com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+e.toString()+"]");
			throw new Exception("MultiDimension Exception : reading record and evaluating");
		}
		return true;
	}
	
	private void err(String id, String wrk_id) {
		this.getStatus().update(null, id, wrk_id, "E" , 0, 0); 
	}
	
	private void ok(String id, String wrk_id) {
		this.getStatus().status( id, wrk_id, "C" );
	}
	
	private void ok(String id, String wrk_id , int tot, int err) {
		this.getStatus().statusAndCount(id, wrk_id, "C" , tot, err);
	}

}
