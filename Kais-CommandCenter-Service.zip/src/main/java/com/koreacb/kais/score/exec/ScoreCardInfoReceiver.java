package com.koreacb.kais.score.exec;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.koreacb.kais.Constants;
import com.koreacb.kais.rule.KaisRuleExecutor;
import com.koreacb.kais.rule.core.KaisRuleExecutorImpl;

public class ScoreCardInfoReceiver {
	public Map<String,Object> requestScoreCard(Map<String,Object> parameter) throws Exception{
		Map<String,Object> ruleInf = (Map<String,Object>)parameter.get(Constants.RULE_DATA);
		Map<String,Object> testInf = (Map<String,Object>)parameter.get(Constants.TEST_DATA);
		Map<String,Object> itemInf = (Map<String,Object>)testInf.get(Constants.TEST_MAP);
		
		String paramString = new JSONObject(parameter).toString();
		com.koreacb.kais.GlobalLogger.log(this,"############## " + paramString);
		
		/*
		List<Map<String,Object>> itemList = (List<Map<String,Object>>)ruleInf.get(Constants.ITEM_LIST);
		Map<String,Object> itemInf = new HashMap<>();
		itemList.forEach((m)->{
			itemInf.put(m.get(Constants.ITM_ID).toString(),m.get(Constants.ITM_TST_VL));
		});
		com.koreacb.kais.GlobalLogger.log(this,"########## ["+ruleInf+"]" );
		com.koreacb.kais.GlobalLogger.log(this,"########## ["+itemInf+"]" );
		*/
		
		KaisRuleExecutor executor = new KaisRuleExecutorImpl();
		Map<String,Object> scoreResult = executor.exeScoreCard(ruleInf, itemInf ,KaisRuleExecutor.OPT_ONLY_EXE_DBG_RTN_OUT, true);
		
		Map<String,Object> result = new HashMap<>();
		Map<String,Object> response_info = new HashMap<>();
		Map<String,Object> basic_info = new HashMap<>();
		Map<String,Object> rule_data = new HashMap<>();
		response_info.put("RESPONSE_DS", "RR50");
		result.put("RESPONSE_INFO", response_info);
		basic_info.put("KOUT_CODE",scoreResult.get("KOUT_CODE"));
		basic_info.put("KOUT_BASIC",scoreResult.get("KOUT_BASIC"));
		rule_data.put("KOUT_RESULT", scoreResult.get("KOUT_RESULT"));
		
		result.put("RESPONSE_INFO",response_info);
		result.put("BASIC_INFO",basic_info);
		result.put("RULE_DATA",rule_data);
		
		com.koreacb.kais.GlobalLogger.log(this,"----- Score Result -----");
		com.koreacb.kais.GlobalLogger.log(this,result.toString());
		com.koreacb.kais.GlobalLogger.log(this,"----- Score Result -----");
		return result;
	}
}
