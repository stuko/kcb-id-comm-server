package com.koreacb.kais;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GlobalLogger {
	
	private static Logger logger = LoggerFactory.getLogger(GlobalLogger.class);
	
	public static void log(String message) {
		if(logger.isDebugEnabled())logger.debug(message);
	}

	public static void log(Object object, String message) {
		if(logger.isDebugEnabled())logger.debug("\t["+object.getClass().getName()+"]\t" + message);
	}
	
	public static void err(Exception ex , String message) {
		logger.error(message, ex);
	}
	
	public static void err(String message) {
		logger.error(message);
	}
	
	public static void err(Exception ex) {
		logger.error(ex.toString());
	}
	
}
