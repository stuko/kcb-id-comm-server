package com.koreacb.kais.status;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import org.json.JSONObject;

public class TransferByHttp {
	
	public void transfer(String restUrl, String method, Map<String,Object> dataSetMap) throws Exception{
		URL url = new URL(restUrl);
		HttpURLConnection con  = (HttpURLConnection)url.openConnection();
		con.setRequestMethod(method);
		con.setAllowUserInteraction(false);
		con.setDoOutput(true);
		con.setRequestProperty("Content-Type", "text/json");
		con.setRequestProperty("accept" , "text/json");
		JSONObject json = new JSONObject(dataSetMap);
		String request = json.toString();
		OutputStream os = con.getOutputStream();
		try {
			os.write(request.getBytes());
			os.flush();
		}catch(Exception e) {
			throw new Exception("",e);
		}finally {
			try {if(os != null) os.close();}catch(Exception e) {}
		}
		con.setDoInput(true);
		InputStream is = con.getInputStream();
		InputStreamReader isr = null;
		BufferedReader br = null;
		try {
			isr = new InputStreamReader(is);
			br = new BufferedReader(isr);
			String line = null;
			StringBuilder sb = new StringBuilder();
			while((line = br.readLine()) != null) {
				sb.append(line);
			}
		}catch(Exception e) {
			throw new Exception("",e);
		}finally {
			try {if(br != null) br.close();}catch(Exception e) {}
			try {if(isr != null) isr.close();}catch(Exception e) {}
			try {if(is != null) is.close();}catch(Exception e) {}
			try {if(con != null) con.disconnect();}catch(Exception e) {}
		}
	}
}
