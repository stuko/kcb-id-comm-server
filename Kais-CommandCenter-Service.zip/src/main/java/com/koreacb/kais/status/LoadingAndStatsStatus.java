package com.koreacb.kais.status;

public class LoadingAndStatsStatus {
	
	String loadingOrStatsId;
	int count;
	int status = -1;
	boolean stop;
	long workTime = System.currentTimeMillis();
	
	public LoadingAndStatsStatus(String id) {
		this.setLoadingOrStatsId(id);
	}
	public String getLoadingOrStatsId() {
		return loadingOrStatsId;
	}
	public void setLoadingOrStatsId(String loadingOrStatsId) {
		this.loadingOrStatsId = loadingOrStatsId;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public boolean isStop() {
		return stop;
	}
	public void setStop(boolean stop) {
		this.stop = stop;
	}
	public long getWorkTime() {
		return workTime;
	}
	public void setWorkTime(long workTime) {
		this.workTime = workTime;
	}

	
}
