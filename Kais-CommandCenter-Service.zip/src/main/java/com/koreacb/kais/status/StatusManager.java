package com.koreacb.kais.status;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.koreacb.kais.Constants;
import com.koreacb.kais.mybatis.MyBatisUtils;

public class StatusManager extends TransferByHttp{
	
	MyBatisUtils utils;
	ExecutorService service = Executors.newFixedThreadPool(1);
	public StatusManager() {
		utils = new MyBatisUtils("resultDataSource",false);
	}

	public int getDataLoadCount(String stageDB, String id, String table_id , String wrk_id) throws Exception{
		// RULE_RESULT 테이블의 총 카운트를 가져와야 하는데, 해당 DB가 resultDataSource로 참조 가능함.
		// Rule : selectRuleResultTableTotalCount, selectRuleResultTableErrorCount
		// Data : selectDsetTotalCount, selectDsetTableErrorCount
		String sqlId = "selectDsetTableTotalCount";
		if(table_id.equals(Constants.RULE_RESULT_TABLE)) {
			stageDB = "resultDataSource";
			sqlId = "selectRuleResultTableTotalCount";
		}
		MyBatisUtils db = stageDB == null ? new MyBatisUtils(false) : new MyBatisUtils(stageDB,false);
		Map<String,Object> m = new HashMap<>();
		m.put("DAT_LDN_TABL_ID", table_id);
		m.put("DAT_SET_ID", id);
		m.put("WK_EXE_ID", wrk_id);
		
		List<Map<String,Object>> result = db.select(sqlId, m);
		db.clear();
		if(result == null || result.size() == 0) return 0;
		else return Integer.parseInt(result.get(0).get("COUNT").toString());
	}
	
	public int getDataLoadErrorCount(String stageDB, String id, String table_id , String wrk_id)  throws Exception{
		// RULE_RESULT 테이블의 총 카운트를 가져와야 하는데, 해당 DB가 resultDataSource로 참조 가능함.
		// Rule : selectRuleResultTableTotalCount, selectRuleResultTableErrorCount
		// Data : selectDsetTotalCount, selectDsetTableErrorCount
		String sqlId = "selectDsetTableErrorCount";
		if(table_id.equals(Constants.RULE_RESULT_TABLE)) {
			stageDB = "resultDataSource";
			sqlId = "selectRuleResultTableErrorCount";
		}
		MyBatisUtils db = stageDB == null ? new MyBatisUtils(false) : new MyBatisUtils(stageDB,false);
		Map<String,Object> m = new HashMap<>();
		m.put("DAT_LDN_TABL_ID", table_id);
		m.put("DAT_SET_ID", id);
		m.put("WK_EXE_ID", wrk_id);
		
		List<Map<String,Object>> result = db.select(sqlId, m);
		db.clear();
		if(result == null || result.size() == 0) return 0;
		else return Integer.parseInt(result.get(0).get("COUNT").toString());
	}
	
	public void transfer(String env, Map<String,Object> map,String loading_table_id, String id, String wrk_id, String code,int total,int err) {
		try {
			Map<String,Object> m = new HashMap<>();
			m.put("STATUS", code);
			m.put("DAT_SET_ID", id);
			m.put("WK_EXE_ID", wrk_id);
			m.put("WTOTAL", total);
			m.put("WERROR", err);
			m.put("DAT_LDN_TABL_ID", loading_table_id);
			m.put("TOTAL", this.getDataLoadCount(env, id, loading_table_id, wrk_id));
			m.put("ERROR", this.getDataLoadErrorCount(env, id, loading_table_id, wrk_id));
			long elapsed = System.currentTimeMillis() - LoadingAndStatsStatusManager.getInstance().getStatus(id, wrk_id).getWorkTime();
			m.put("W_SEC", elapsed/1000);
			
			utils.insert("saveStatus",m);
		}catch(Exception e) {
			this.update(null, id, wrk_id, "E", total, err);
			e.printStackTrace();
		}
	}
	
	public void cancel(Map<String,Object> map,String id, String wrk_id, String code,int total,int err) {
		try {
			Map<String,Object> m = new HashMap<>();
			m.put("STATUS", code);
			m.put("DAT_SET_ID", id);
			m.put("WK_EXE_ID", wrk_id);
			long elapsed = System.currentTimeMillis() - LoadingAndStatsStatusManager.getInstance().getStatus(id, wrk_id).getWorkTime();
			m.put("W_SEC", elapsed/1000);
			
			utils.insert("updateStatus",m);
		}catch(Exception e) {
			this.update(null, id, wrk_id, "E", total, err);
			e.printStackTrace();
		}
	}

	
	public void update(Map<String,Object> map,String id, String wrk_id, String code,int total,int err) {
		try {
			Map<String,Object> m = new HashMap<>();
			m.put("RESULT", code);
			m.put("DAT_SET_ID", id);
			m.put("WK_EXE_ID", wrk_id);
			long elapsed = System.currentTimeMillis() - LoadingAndStatsStatusManager.getInstance().getStatus(id, wrk_id).getWorkTime();
			m.put("W_SEC", elapsed/1000);

			utils.insert("updateResult",m);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void status(String id, String wrk_id, String code) {
		try {
			Map<String,Object> m = new HashMap<>();
			m.put("STATUS", code);
			m.put("DAT_SET_ID", id);
			m.put("WK_EXE_ID", wrk_id);
			long elapsed = System.currentTimeMillis() - LoadingAndStatsStatusManager.getInstance().getStatus(id, wrk_id).getWorkTime();
			m.put("W_SEC", elapsed/1000);

			utils.insert("updateStatus",m);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void statusAndCount(String id, String wrk_id, String code,int total,int err) {
		try {
			Map<String,Object> m = new HashMap<>();
			m.put("STATUS", code);
			m.put("DAT_SET_ID", id);
			m.put("WK_EXE_ID", wrk_id);
			m.put("WTOTAL", total);
			m.put("WERROR", err);
			long elapsed = System.currentTimeMillis() - LoadingAndStatsStatusManager.getInstance().getStatus(id, wrk_id).getWorkTime();
			m.put("W_SEC", elapsed/1000);

			utils.insert("updateStatusAndCount",m);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
