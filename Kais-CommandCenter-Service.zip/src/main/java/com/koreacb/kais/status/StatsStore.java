package com.koreacb.kais.status;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.koreacb.kais.data.server.load.LoadingCondition;
import com.koreacb.kais.mybatis.MyBatisUtils;
import com.koreacb.kais.stats.AnalysisInfo;
import com.koreacb.kais.stats.multi.DimenAnalysis;

public class StatsStore {
	
	MyBatisUtils utils;
	StatusManager status;
	
	public StatsStore() {
		utils = new MyBatisUtils("resultDataSource",false);
		status = new StatusManager();
	}
	
	public void saveStatsLevelOneTwoResultInTable(String dataSetId
												, String dataLoadId
												, String dataLoadTableId
												, Map<String, List<LoadingCondition>> cond
												, Map<String,AnalysisInfo> analysisMap) {
		Map<String,Object> map = new HashMap<>();
		try {
			
			if(analysisMap == null || analysisMap.size() == 0) {
				status.update(null, dataSetId, dataLoadId, "E", 0, 0);
				return;
			}
			
			map.put("DAT_SET_ID", dataSetId);
			map.put("WK_EXE_ID", dataLoadId);
			map.put("DAT_LDN_TABL_ID", dataLoadTableId);
			map.put("DSET_TABLE", dataLoadTableId);
			
			Map<String,Object> stats = new HashMap<>();
			for(String k : analysisMap.keySet()) {
				AnalysisInfo v = analysisMap.get(k);
				stats.put(k,v.toMap());
			}
			map.put("RESULT", new JSONObject(stats).toString());
			utils.insert("insertAnalysisBS",map);
		}catch(Exception e) {
			status.update(null, dataSetId, dataLoadId, "E", 0, 0);
			e.printStackTrace();
		}
	}
	
	public void saveStatsDimensionResultInTable(String dataSetId
												, String dataLoadId
												, String dataLoadTableId
												, Map<String, List<LoadingCondition>> cond
												, DimenAnalysis dimenAnalysis) {
		Map<String,Object> map = new HashMap<>();
		try {
			List<Map<String,Object>> statsList = dimenAnalysis.toList();
			if(statsList == null || statsList.size() == 0) {
				status.update(null, dataSetId, dataLoadId, "E", 0, 0);
				return;
			}
			if(statsList.get(0) == null) {
				status.update(null, dataSetId, dataLoadId, "E", 0, 0);
				return;
			}
			Map<String,Object> resultMap = new HashMap<>();
			resultMap.put("RESULT",statsList);
			map.put("DAT_SET_ID", dataSetId);
			map.put("WK_EXE_ID", dataLoadId);
			map.put("DAT_LDN_TABL_ID", dataLoadTableId);
			map.put("DSET_TABLE", dataLoadTableId);
			map.put("RESULT", new JSONObject(resultMap).toString());
			utils.insert("insertAnalysisDM",map);
		}catch(Exception e) {
			status.update(null, dataSetId, dataLoadId, "E", 0, 0);
			e.printStackTrace();
		}
	}
	
}
