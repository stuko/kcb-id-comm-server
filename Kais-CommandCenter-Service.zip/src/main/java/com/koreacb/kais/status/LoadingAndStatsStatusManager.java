package com.koreacb.kais.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoadingAndStatsStatusManager {
	
	static LoadingAndStatsStatusManager INSTANCE = null;
	private Map<String,List<LoadingAndStatsStatus>> repository = null;
	
	static Object lock = new Object();
	
	private LoadingAndStatsStatusManager() {
		repository = new HashMap<>();
	}
	
	public static LoadingAndStatsStatusManager getInstance() {
		synchronized(lock) {
			if(INSTANCE == null) INSTANCE = new LoadingAndStatsStatusManager();
		}
		return INSTANCE;
	}
		
	public Map<String, List<LoadingAndStatsStatus>> getRepository() {
		return repository;
	}

	public void setRepository(Map<String, List<LoadingAndStatsStatus>> repository) {
		this.repository = repository;
	}
	
	public void init(String dataSetId, String loadingAndStatsId) {
		if(this.getRepository().containsKey(dataSetId)) {
			boolean find = false;
			List<LoadingAndStatsStatus> list= this.getRepository().get(dataSetId);
			for(LoadingAndStatsStatus status  : list) {
				if(status.getLoadingOrStatsId().equals(loadingAndStatsId)) {
					find = true;
					return;
				}
			}
			if(!find) {
				list.add(new LoadingAndStatsStatus(loadingAndStatsId));
			}
		}
		else {
			List<LoadingAndStatsStatus> list = new ArrayList<>();
			LoadingAndStatsStatus status = new LoadingAndStatsStatus(loadingAndStatsId);
			status.setLoadingOrStatsId(loadingAndStatsId);
			list.add(status);
			this.getRepository().put(dataSetId,list);
		}
	}

	public void clear(String dataSetId) {
		if(this.getRepository().containsKey(dataSetId)) {
			this.getRepository().remove(dataSetId);
		}
	}

	
	public LoadingAndStatsStatus getStatus(String dataSetId, String loadingAndStatsId) {
		this.init(dataSetId, loadingAndStatsId);
		for(LoadingAndStatsStatus status : this.getRepository().get(dataSetId)) {
			if(status.getLoadingOrStatsId().equals(loadingAndStatsId)) {
				return status;
			}
		}
		return null;
	}
	
	// 진행 상태 업데이트
	public void setLoadingAndStatsCount(String dataSetId, String loadingAndStatsId ,int status) {
		this.getStatus(dataSetId, loadingAndStatsId).setCount(status);
	}
	// 작업 완료 상태 업데이트
	public void setLoadingAndStatsComplete(String dataSetId, String loadingAndStatsId) {
		this.getStatus(dataSetId, loadingAndStatsId).setStatus(1);
	}
	public void setLoadingAndStatsRunning(String dataSetId, String loadingAndStatsId) {
		this.getStatus(dataSetId, loadingAndStatsId).setStatus(0);
	}
	// 작업 상태 가져오기
	public int getLoadingAndStatsCount(String dataSetId, String loadingAndStatsId) {
		return this.getStatus(dataSetId, loadingAndStatsId).getCount();
	}
	// 작업 완료 상태 가져오기
	public boolean isLoadingAndStatsComplete(String dataSetId, String loadingAndStatsId) {
		boolean result = this.getStatus(dataSetId, loadingAndStatsId).getStatus() == 1 ? true : false;
		return result;
	}
	public boolean isLoadingAndStatsRunning(String dataSetId, String loadingAndStatsId) {
		return this.getStatus(dataSetId, loadingAndStatsId).getStatus() == 0 ? true : false;
	}
	// 작업 중단 설정
	public void setLoadingAndStatsStop(String dataSetId, String loadingAndStatsId) {
		this.getStatus(dataSetId, loadingAndStatsId).setStop(true);
	}
	public void setLoadingAndStatsStart(String dataSetId, String loadingAndStatsId) {
		this.getStatus(dataSetId, loadingAndStatsId).setStop(false);
	}
	// 작업 중단 여부 가져오기
	public boolean isLoadingAndStatsStop(String dataSetId, String loadingAndStatsId) {
		return this.getStatus(dataSetId, loadingAndStatsId).isStop();
	}
	public void refresh(String dataSetId, String loadingAndStatsId) {
		this.getStatus(dataSetId, loadingAndStatsId).setStop(false);
	}
	
}
