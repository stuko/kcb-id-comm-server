package com.koreacb.kais.simulation.server.exec;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreacb.kais.Constants;
import com.koreacb.kais.data.server.load.DataSetDataLoadInfo;
import com.koreacb.kais.mybatis.MultiMyBatisUtils;
import com.koreacb.kais.rule.KaisRuleExecutor;
import com.koreacb.kais.rule.core.KaisRuleExecutorImpl;
import com.koreacb.kais.rule.server.exec.RuleInfoReceiver;
import com.koreacb.kais.rule.server.exec.RuleResultStore;
import com.koreacb.kais.stats.DataSetStatsInfo;
import com.koreacb.kais.status.LoadingAndStatsStatusManager;

public class SimulationInfoReceiver  extends RuleInfoReceiver{

	/*
	 * 시뮬레이션 인터페이스 항목 
	 * ----------------------
	 * <시뮬레이션 실행 요청 >
	 * ----------------------
	 * 시뮬레이션 Id
	 * 전략 Id
	 * 데이터셋   Id
	 * 데이터 샘플링 옵션[{항목Id, type, length, operator, value, or / and}]
	 * 데이터 항목 매핑
	 * 전략 항목과 데이터 셋 항목 매핑 정보 [{전략항목 id, 전략항목 type, 전략항목 length, 데이터셋 항목 id, 데이터셋 항목 type, 데이터셋 항목 length}]
	 * 
	 * ----------------------
	 * <시뮬레이션 결과 응답 >
	 * ----------------------
	 * 시뮬레이션 Id
	 * 전략 Id
	 * 데이터셋   Id
	 * 데이터 샘플링 옵션[{항목Id, type, length, operator, value, or / and}]
	 * 데이터 항목 매핑
	 * 전략 항목과 데이터 셋 항목 매핑 정보 [{전략항목 id, 전략항목 type, 전략항목 length, 데이터셋 항목 id, 데이터셋 항목 type, 데이터셋 항목 length}]
	 * 
	 * 등록일시
	 * 완료일시
	 * 소요시간
	 * 건당처리시간
	 * 데이터 건수
	 * 통계정보
	 *    {}
	 * 결과정보
	 *    {}
	 * 
	 * ----------------------
	 * <시뮬레이션 진행 상태 응답 >
	 * ----------------------
	 * 시뮬레이션 Id
	 * 시뮬레이션 진행 상태
	 *
	 * ----------------------
	 * <시뮬레이션 작업 취소 요청>
	 * ----------------------
	 * 시뮬레이션 Id
	 *
	 */
	public Map<String,Object> requestSimulation(Map<String,Object> parameter) throws Exception{
		return requestEngine(parameter);
	}
	
	// 아래 기능은 사용하지 않음.
	public boolean requestSimulationLegacy(Map<String,Object> parameter) throws Exception{
		
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.SIM_DATASET_INF);
		List<Map<String,Object>> mapInf = (List<Map<String,Object>>)parameter.get(Constants.SIM_MAP_INF);
		Map<String,Object> perfInf = (Map<String,Object>)parameter.get(Constants.SIM_PERF_INF);
		
		Map<String,Object> ruleInf = (Map<String,Object>)parameter.get(Constants.RULE_DATA);

		DataSetDataLoadInfo info = new DataSetDataLoadInfo();
		info.setDataSetId(dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString());
		info.setDataSetLoadingTableId(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString());
		info.addLoadingCondition((List<Map<String,Object>>)parameter.get(Constants.SIM_FILTERING_INF));
		
		// 추후 엔진 클래스 변경 해야 함.
		KaisRuleExecutor executor = new KaisRuleExecutorImpl();
		
		String strDebug = null ; //((Map<String,Object>)parameter.get(Constants.EXE_RULE_INF)).get(Constants.EXE_RULE_DEBUG).toString();
		
		boolean debug = strDebug.equals("true") ? true : false;
		
		DataSetStatsInfo stats = new DataSetStatsInfo();
		stats.setDataSetId(dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString());
		stats.setDataLoadId(dataSetBscInf.get(Constants.DATA_SET_ANALYSIS_ID).toString());
		
		MultiMyBatisUtils source = new MultiMyBatisUtils(info,true,(rs, rowCount,colCount)->{
			// 데이터(rs) + 룰에서 필요한 정보를 룰엔진에 넘겨줘야 함.
			Map<String,Object> resultMap = null;
			if(Constants.EXE_RULE_TYPE_MS.equals(dataSetBscInf.get(Constants.EXE_RULE_TYPE).toString())) {
				if(debug) resultMap = executor.exeStrategyMain(ruleInf, rs, KaisRuleExecutor.OPT_ONLY_EXE_DBG_RTN_OUT,true);
				else resultMap = executor.exeStrategyMain(ruleInf, rs, KaisRuleExecutor.OPT_ONLY_EXE,true);
			}else if(Constants.EXE_RULE_TYPE_SS.equals(dataSetBscInf.get(Constants.EXE_RULE_TYPE).toString())) {
				if(debug) resultMap = executor.exeStrategySub(ruleInf, rs, KaisRuleExecutor.OPT_ONLY_EXE_DBG_RTN_OUT,true);
				else resultMap = executor.exeStrategySub(ruleInf, rs, KaisRuleExecutor.OPT_ONLY_EXE,true);
			}else if(Constants.EXE_RULE_TYPE_SC.equals(dataSetBscInf.get(Constants.EXE_RULE_TYPE).toString())) {
				if(debug) resultMap = executor.exeScoreCard(ruleInf, rs, KaisRuleExecutor.OPT_ONLY_EXE_DBG_RTN_OUT,true);
				else resultMap = executor.exeScoreCard(ruleInf, rs, KaisRuleExecutor.OPT_ONLY_EXE,true);
			}

			try {
				// 항목정보를 1차원으로 변경해서 넘겨줘야 함.
				stats.analysisLevelOne(resultMap);
				LoadingAndStatsStatusManager.getInstance().setLoadingAndStatsCount(stats.getDataSetId(),stats.getDataLoadId() , rowCount);
				if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(stats.getDataSetId(),stats.getDataLoadId()))return false;

			} catch (Exception e) {
				e.printStackTrace();
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+e.toString()+"]");
			}
			return true;
		});
		List<Map<String,Object>> listMap = source.executeDataSetLoad();
		source.clear();
		stats.analysisLevelTwo();
		
		return true;
	}


}
 