package com.koreacb.kais.data.server.load;

public class DataLoadInfo {
	
	String targetTableName;
	String targetEnvName = "targetDataSource";
	String targetCreateMapperName = "com.koreacb.kais.mapper.createDsetTable";
	String targetSelectMapperName = "com.koreacb.kais.mapper.selectDsetDATA";
	String targetTruncateMapperName = "com.koreacb.kais.mapper.truncDsetTable";
	String targetDropMapperName = "com.koreacb.kais.mapper.dropDsetTable";
	String targetInsertMapperName = "com.koreacb.kais.mapper.insertDsetTableWithFilter";
	
	String resultEnvName = "resultDataSource";
	String resultCreateMapperName = "com.koreacb.kais.mapper.createResultTable";
	String resultInsertMapperName = "com.koreacb.kais.mapper.insertResultTable";
	
	boolean load;
	boolean result;
	boolean loadAll = true;
		
	public boolean isLoadAll() {
		return loadAll;
	}

	public void setLoadAll(boolean loadAll) {
		this.loadAll = loadAll;
	}

	public boolean isResult() {
		return result;
	}

	public void setResult(boolean result) {
		this.result = result;
	}

	public boolean isLoad() {
		return load;
	}

	public void setLoad(boolean load) {
		this.load = load;
	}

	public String getTargetEnvName() {
		return targetEnvName;
	}

	public void setTargetEnvName(String targetEnvName) {
		this.targetEnvName = targetEnvName;
	}

	public String getTargetTableName() {
		return targetTableName;
	}

	public void setTargetTableName(String targetTableName) {
		this.targetTableName = targetTableName;
	}
	public String getTargetCreateMapperName() {
		return targetCreateMapperName;
	}

	public void setTargetCreateMapperName(String targetCreateMapperName) {
		this.targetCreateMapperName = targetCreateMapperName;
	}

	public String getTargetSelectMapperName() {
		return targetSelectMapperName;
	}

	public void setTargetSelectMapperName(String targetSelectMapperName) {
		this.targetSelectMapperName = targetSelectMapperName;
	}

	public String getTargetTruncateMapperName() {
		return targetTruncateMapperName;
	}

	public void setTargetTruncateMapperName(String targetTruncateMapperName) {
		this.targetTruncateMapperName = targetTruncateMapperName;
	}

	public String getTargetDropMapperName() {
		return targetDropMapperName;
	}

	public void setTargetDropMapperName(String targetDropMapperName) {
		this.targetDropMapperName = targetDropMapperName;
	}

	public String getTargetInsertMapperName() {
		return targetInsertMapperName;
	}

	public void setTargetInsertMapperName(String targetInsertMapperName) {
		this.targetInsertMapperName = targetInsertMapperName;
	}

	public String getResultEnvName() {
		return resultEnvName;
	}

	public void setResultEnvName(String resultEnvName) {
		this.resultEnvName = resultEnvName;
	}

	public String getResultCreateMapperName() {
		return resultCreateMapperName;
	}

	public void setResultCreateMapperName(String resultCreateMapperName) {
		this.resultCreateMapperName = resultCreateMapperName;
	}

	public String getResultInsertMapperName() {
		return resultInsertMapperName;
	}

	public void setResultInsertMapperName(String resultInsertMapperName) {
		this.resultInsertMapperName = resultInsertMapperName;
	}

}
