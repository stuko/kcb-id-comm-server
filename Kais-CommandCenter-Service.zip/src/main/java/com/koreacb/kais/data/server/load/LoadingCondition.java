package com.koreacb.kais.data.server.load;

import com.koreacb.kais.Constants;

public class LoadingCondition {
	String itemId;
	String inputValue;
	String operation;
	String orGroup;
	String type;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getOrGroup() {
		return orGroup;
	}
	public void setOrGroup(String orGroup) {
		this.orGroup = orGroup;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getInputValue() {
		return inputValue;
	}
	public void setInputValue(String inputValue) {
		this.inputValue = inputValue;
	}
	
	public String toSQLValue() {
		return toValue(this.getInputValue());
	}
	
	public String toValue(String v) {
		if(Constants.ITEM_DATA_TYPE_NUMBER.equals(this.getType())
		|| Constants.ITEM_DATA_TYPE_INTEGER.equals(this.getType())) {
			return v;
		}else {
			return "'" + v + "'";
		}
	}
	
	public String toBWValue() {
		StringBuilder sb = new StringBuilder();
		String[] vs = this.getInputValue().split(",");
		if(vs.length == 1) {
			sb.append(toValue(vs[0])).append(" AND ").append(toValue(vs[0]));
		}else {
			sb.append(toValue(vs[0])).append(" AND ").append(toValue(vs[1]));
		}
		return sb.toString();
	}
	
	public String toINValue() {
		StringBuilder sb = new StringBuilder();
		String[] vs = this.getInputValue().split(",");
		int i = 0;
		for(String v : vs) {
			i++;
			sb.append(toValue(v));
			if(i != vs.length) {
				sb.append(",");
			}
		}
		return sb.toString();
	}
	
	public String toString() {
		
		if(this.operation.equals(Constants.EQ0)) {
			return this.itemId + " " + "= " + toSQLValue();
		}else if(this.operation.equals(Constants.EQN)) {
			return this.itemId + " " + "<> " + toSQLValue();
		}else if(this.operation.equals(Constants.GT0)) {
			return this.itemId + " " + "> " + toSQLValue();
		}else if(this.operation.equals(Constants.GTE)) {
			return this.itemId + " " + ">= " + toSQLValue();
		}else if(this.operation.equals(Constants.LT0)) {
			return this.itemId + " " + "< " + toSQLValue();
		}else if(this.operation.equals(Constants.LTE)) {
			return this.itemId + " " + "<= " + toSQLValue();
		}else if(this.operation.equals(Constants.LK0)) {
			return this.itemId + " " + "LIKE" + " '%" + this.getInputValue() + "%'";
		}else if(this.operation.equals(Constants.LKN)) {
			return this.itemId + " " + "NOT LIKE" + " '%" + this.getInputValue() + "%'";
		}else if(this.operation.equals(Constants.BW0)) {
			return this.itemId + " " + "BETWEEN "  + toBWValue();
		}else if(this.operation.equals(Constants.BWN)) {
			return this.itemId + " " + "NOT BETWEEN "  + toBWValue();
		}else if(this.operation.equals(Constants.IN0)) {
			return this.itemId + " " + "IN ("  + toINValue() + ")";
		}else if(this.operation.equals(Constants.INN)) {
			return this.itemId + " " + "NOT IN ("  + toINValue() + ")";
		}else if(this.operation.equals(Constants.NL0)) {
			return this.itemId + " " + "IS NULL";
		}else if(this.operation.equals(Constants.NLN)) {
			return this.itemId + " " + "IS NOT NULL";
		}else {
			return this.itemId + " == "  + toSQLValue();
		}
		
		
	}
	
	
}
