package com.koreacb.kais.data.server.load;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.koreacb.kais.Constants;
import com.koreacb.kais.mybatis.DataSetCallBack;
import com.koreacb.kais.mybatis.MultiMyBatisUtils;
import com.koreacb.kais.mybatis.MyBatisUtils;
import com.koreacb.kais.status.LoadingAndStatsStatusManager;

public class DataSetLoader {
	
	boolean batch = false;
	int fetchSize = 1000;
	int limit = -1;
	int errCount = 0;
	int totalCount = 0;
	DataSetCallBack callBack;
	
	Map<String,Object> lastResult;
	
	public DataSetLoader() {}
	
	public DataSetLoader(DataSetCallBack callBack) {
		this.setCallBack(callBack);
	}
	
	public Map<String, Object> getLastResult() {
		return lastResult;
	}

	public void setLastResult(Map<String, Object> lastResult) {
		this.lastResult = lastResult;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getErrCount() {
		return errCount;
	}

	public void setErrCount(int errCount) {
		this.errCount = errCount;
	}

	public DataSetCallBack getCallBack() {
		return callBack;
	}

	public void setCallBack(DataSetCallBack callBack) {
		this.callBack = callBack;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getFetchSize() {
		return fetchSize;
	}

	public void setFetchSize(int fetchSize) {
		this.fetchSize = fetchSize;
	}

	public boolean isBatch() {
		return batch;
	}

	public void setBatch(boolean batch) {
		this.batch = batch;
	}

	public void createTable(DataLoadInfo info, Map<String,Object> parameter) throws Exception{
		MyBatisUtils utils = new MyBatisUtils(info.getTargetEnvName(),this.isBatch());
		utils.insert(info.getTargetCreateMapperName(), parameter);
	}
	
	public void dropTable(DataLoadInfo info, Map<String,Object> parameter) throws Exception{
		MyBatisUtils utils = new MyBatisUtils(info.getTargetEnvName(),this.isBatch());
		utils.insert(info.getTargetDropMapperName(), parameter);
	}
	
	public void truncateTable(DataLoadInfo info, Map<String,Object> parameter) throws Exception{
		MyBatisUtils utils = new MyBatisUtils(info.getTargetEnvName(),this.isBatch());
		utils.insert(info.getTargetTruncateMapperName(), parameter);
	}
	public List<Map<String,Object>> sql(DBDataLoadInfo info, Map<String,Object> parameter , List<Map<String,Object>> itemList ) throws Exception{
		return sql(info,parameter,itemList);
	}
	public List<Map<String,Object>> sql(DBDataLoadInfo info, Map<String,Object> parameter , List<Map<String,Object>> itemList ,int limit) throws Exception{
		List<Map<String,Object>> resultList = null;
		final MultiMyBatisUtils target = new MultiMyBatisUtils(info.getTargetEnvName(),this.isBatch());
		MultiMyBatisUtils source = new MultiMyBatisUtils(info,this.isBatch(),(rs,rowCount, colCount)->{
			try {
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+this.getTotalCount()+"]");
				Map<String,Object> one = getOneRecord(info,parameter,rowCount,itemList,rs);
				if(info.isLoad())target.insert(info.getTargetInsertMapperName(), one);
				if(this.getCallBack() != null) {
					Map<String,Object> result = this.getCallBack().callBizLogicInReading(true, rowCount, false, one ,itemList, "X", getTotalCount() , getErrCount());
					if(info.isResult()) {
						target.insert(info.getResultInsertMapperName(), getOneRecord(info,parameter,rowCount,itemList,result));
					}
				}
				if(parameter.containsKey(Constants.DATA_SET_BASIC_LOADING_ID)) {
					LoadingAndStatsStatusManager.getInstance().setLoadingAndStatsCount(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString() , rowCount);
					if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString())){
						LoadingAndStatsStatusManager.getInstance().refresh(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
						return false;
					}
				}
				this.setTotalCount(this.getTotalCount() + 1);
			} catch (Exception e) {
				this.setErrCount(this.getErrCount() + 1);
				e.printStackTrace();
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+e.toString()+"]");
			}
			return true;
		});

		if(this.isBatch()) source.setFetchSize(this.getFetchSize()); 
		if(limit > 0 ) {
			source.setFetchSize(limit);
 			resultList = source.executeSqlLoad(limit, info.getSourceSql(), parameter, true);
		}else {
			source.setFetchSize(-1);
			source.executeSqlLoad(info.getSourceSql(), parameter, true);
		}
		
		source.clear();
		target.clear();
		if(this.getCallBack() != null) {
			this.getCallBack().callBizLogicInReading(true, this.getTotalCount(), true, null, itemList, "C", getTotalCount() , getErrCount());
		}
		return resultList;
	}
	public List<Map<String,Object>> file(FileDataLoadInfo info, Map<String,Object> parameter , List<Map<String,Object>> itemList ) throws Exception{
		return file(info,parameter,itemList,-1);
	}
	public List<Map<String,Object>> file(FileDataLoadInfo info, Map<String,Object> parameter , List<Map<String,Object>> itemList ,int limit) throws Exception{
		List<Map<String,Object>>  resultList = null;
		final MultiMyBatisUtils target = new MultiMyBatisUtils(info.getTargetEnvName(),this.isBatch());
		MultiMyBatisUtils source = new MultiMyBatisUtils(info,this.isBatch(),(rs,rowCount, colCount)->{
			try {
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+this.getTotalCount()+"]");
				Map<String,Object> one = getOneRecord(info,parameter,rowCount,itemList,rs);
				if(info.isLoad()) {
					target.insert(info.getTargetInsertMapperName(), one);
				}
				if(this.getCallBack() != null) {
					com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... [rowCount : "+rowCount+"]");
					Map<String,Object> result = this.getCallBack().callBizLogicInReading(true, rowCount, false, rs ,itemList, "X", getTotalCount() , getErrCount());
					if(info.isResult()) {
						target.insert(info.getResultInsertMapperName(), getOneRecord(info,parameter,rowCount,itemList,result));
					}
				}
				if(parameter.containsKey(Constants.DATA_SET_BASIC_LOADING_ID)) {
					LoadingAndStatsStatusManager.getInstance().setLoadingAndStatsCount(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString() , rowCount);
					if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString())){
						LoadingAndStatsStatusManager.getInstance().refresh(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
						return false;
					}
				}
				this.setTotalCount(this.getTotalCount() + 1);
			} catch (Exception e) {
				this.setErrCount(this.getErrCount() + 1);
				e.printStackTrace();
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+e.toString()+"]");
			}
			return true;
		});
		
		if(limit > 0 ) {
			source.setFetchSize(limit);
			resultList = source.executeFileLoad(limit);
		}else {
			source.setFetchSize(-1);
			source.executeFileLoad();
		}
		source.clear();
		target.clear();
		if(this.getCallBack() != null) {
			this.getCallBack().callBizLogicInReading(true, this.getTotalCount(), true, null, itemList, "C", getTotalCount() , getErrCount());
		}
		return resultList;
	}
	public List<Map<String,Object>> dataSet(DataSetDataLoadInfo info, Map<String,Object> parameter , List<Map<String,Object>> itemList) throws Exception{
		return dataSet(info,parameter,itemList,-1);
	}
	public List<Map<String,Object>> dataSet(DataSetDataLoadInfo info, Map<String,Object> parameter , List<Map<String,Object>> itemList ,int limit) throws Exception{
		List<Map<String,Object>> resultList = null;
		final MultiMyBatisUtils target = new MultiMyBatisUtils(info.getTargetEnvName(),this.isBatch());
		MultiMyBatisUtils source = new MultiMyBatisUtils(info,this.isBatch(),(rs,rowCount, colCount)->{
			try {
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+this.getTotalCount()+"]");
				Map<String,Object> one = getOneRecord(info,parameter,rowCount,itemList,rs);
				if(info.isLoad()) {
					target.insert(info.getTargetInsertMapperName(), one);
				}
				if(this.getCallBack() != null) {
					Map<String,Object> result = this.getCallBack().callBizLogicInReading(true, rowCount, false, one ,itemList, "X", getTotalCount() , getErrCount());
					if(info.isResult()) {
						target.insert(info.getResultInsertMapperName(), getOneRecord(info,parameter,rowCount,itemList,result) );
					}
				}
				if(parameter.containsKey(Constants.DATA_SET_BASIC_LOADING_ID)) {
					LoadingAndStatsStatusManager.getInstance().setLoadingAndStatsCount(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString() , rowCount);
					if(LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsStop(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString())) {
						LoadingAndStatsStatusManager.getInstance().refresh(parameter.get(Constants.DATA_SET_BASIC_ID).toString(),parameter.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
						return false;
					}
				}
				this.setTotalCount(this.getTotalCount() + 1);
				
			} catch (Exception e) {
				this.setErrCount(this.getErrCount() + 1);
				e.printStackTrace();
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... ["+e.toString()+"]");
			}
			return true;	
		});
		
		if(this.isBatch()) source.setFetchSize(this.getFetchSize()); 
		if(limit > 0 ) {
			source.setFetchSize(limit);
			resultList = source.executeDataSetLoad(limit);
		}else {
			source.setFetchSize(-1);
			source.executeDataSetLoad();
		}
		source.clear();
		target.clear();
		if(this.getCallBack() != null) {
			this.getCallBack().callBizLogicInReading(true, this.getTotalCount(), true, null , itemList, "C", getTotalCount() , getErrCount());
		}
		return resultList;
	}
	
	public Map<String,Object> getOneRecord(   DataLoadInfo info
											, Map<String,Object> parameter
											, int record_id
											, List<Map<String,Object>> itemList 
											, Map<String,Object> rs
											) {
		Map<String,Object> map = new HashMap<String,Object>();
		StringBuilder strColumn = new StringBuilder();
		StringBuilder strValue = new StringBuilder();
		map.putAll(parameter);
		map.put("DSET_TABLE",parameter.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID) );
		map.put("SCOL_DATASET_ID",parameter.get(Constants.DATA_SET_BASIC_ID) );
		map.put("SCOL_LOADING_ID",parameter.get(Constants.DATA_SET_BASIC_LOADING_ID) );
		map.put("SCOL_RANDOM_NO",(Math.floor( Math.random()*(10000 - 1 + 1) ) + 1)/100); // 0.01 ~ 100.00
		map.put("SCOL_RECORD_ID", record_id);
		map.put("SCOL_ORIGNAL_DATA",new JSONObject(rs).toString());
		map.put("SIMUL_DATA",rs);
		
		Map<String,Object> json = new HashMap<>();
		String error = "N";
		if(itemList != null && itemList.size() > 0 && itemList.get(0).containsKey(Constants.ITEM_ID)) {
			for(Map<String,Object> item : itemList) {
				if("N".equals(error)) error = isError(item,rs);
				String itemType = item.get(Constants.ITEM_USE_TYPE) != null ? item.get(Constants.ITEM_USE_TYPE).toString().trim() : null;
				String dataType = !item.containsKey(Constants.ITEM_DATA_TYPE) ?  Constants.ITEM_DATA_TYPE_STRING :  item.get(Constants.ITEM_DATA_TYPE).toString().trim();
				int dataLen = !item.containsKey(Constants.ITEM_DATA_LENGTH) ? 255 : item.get(Constants.ITEM_DATA_LENGTH) != null ? Integer.parseInt(item.get(Constants.ITEM_DATA_LENGTH).toString().trim()) : 0;
				String itemId = item.get(Constants.ITEM_ID).toString().trim();
				
				String mappedId = null , value = null;
				if(!item.containsKey(Constants.ITEM_MAP_ID) || item.get(Constants.ITEM_MAP_ID) == null) mappedId = null;
				else mappedId = item.get(Constants.ITEM_MAP_ID).toString();
	
				if(mappedId == null || mappedId.trim().length() == 0 || !rs.containsKey(mappedId) || rs.get(mappedId) == null) {
					if(!rs.containsKey(itemId) || rs.get(itemId) == null) value = "";
					else value = rs.get(itemId).toString();
				}else {
					value = rs.get(mappedId.trim()).toString();
				}

				// 값이 NULL 이거나 "" 이면, Default 값을 입력함
				// 2018.08.02
				if(value == null || value.equals("")) {
					if(item.containsKey(Constants.ITEM_DATA_BASIC_VALUE) && item.get(Constants.ITEM_DATA_BASIC_VALUE) != null)
						value = item.get(Constants.ITEM_DATA_BASIC_VALUE).toString();
				}
				
				if(itemType != null && itemType.equals(Constants.ITEM_USE_TYPE_GENERAL)) {
					if(!json.containsKey(itemId))json.put(itemId, value);
				}else {
					if(!map.containsKey(itemId))map.put(itemId, value);
					strColumn.append("," + itemId);
					if(dataType.equals(Constants.ITEM_DATA_TYPE_STRING)) strValue.append(",'" + value + "'");
					else  strValue.append("," + value + "");
				}
				
			}
		}else {
			json = rs;
			rs.forEach((k,v) ->{
				if(!map.containsKey(k)) map.put(k, v);
			});
		}
		
		// 2018.08.02
		// 아래 전체 건수와 에러 건수는 외부에서 처리 하도록 함.
		// this.setTotalCount(this.getTotalCount()+1);
		// if("Y".equals(error)) this.setErrCount(this.getErrCount()+1);
		
		map.put("SCOL_ERR_YN", error);
		map.put("SCOL_LOADING_DATA",new JSONObject(json).toString() );
		map.put("SCOL_LOADING_MAP",json );
		map.put("FILTERING_COLUMN", strColumn.toString());
		map.put("FILTERING_VALUE", strValue.toString());

		return map;
	}

	private String isError(Map<String,Object> item , Map<String,Object> record) {
		
		if(!item.containsKey(Constants.ITEM_USE_TYPE)) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM USE TYPE ERROR:");
			return "Y";
		}
		if(!item.containsKey(Constants.ITEM_DATA_TYPE)) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM DATA TYPE ERROR:");
			return "Y";
		}
		if(!item.containsKey(Constants.ITEM_DATA_LENGTH)) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM DATA LENGTH ERROR:");
			return "Y";
		}
		// if(!item.containsKey(KaisConstants.ITEM_MAP_ID)) return "Y";
		if(!item.containsKey(Constants.ITEM_ID)) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM ID ERROR:");
			return "Y";
		}
		if(item.get(Constants.ITEM_USE_TYPE) == null) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM USE TYPE NULL ERROR:");
			return "Y";
		}
		if(item.get(Constants.ITEM_DATA_TYPE) == null) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM DATA TYPE NULL ERROR:");
			return "Y";
		}
		if(item.get(Constants.ITEM_DATA_LENGTH) == null) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM DATA LENGTH NULL ERROR:");
			return "Y";
		}
		// if(item.get(KaisConstants.ITEM_MAP_ID) == null)  return "Y";
		if(item.get(Constants.ITEM_ID) == null) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM ID NULL ERROR:");
			return "Y";
		}
		
		if(!isNumber(item.get(Constants.ITEM_DATA_LENGTH).toString())) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM DATA LENGTH IS NOT NUMBER ERROR:");
			return "Y";
		}
		double dataLen = Double.parseDouble(item.get(Constants.ITEM_DATA_LENGTH).toString());
		
		if(item.get(Constants.ITEM_USE_TYPE).toString().trim().equals("F") || item.get(Constants.ITEM_USE_TYPE).toString().trim().equals("P")) {
			if(
				(
					(item.get(Constants.ITEM_DATA_TYPE)).toString().trim().equals(Constants.ITEM_DATA_TYPE_STRING) 
				||  (item.get(Constants.ITEM_DATA_TYPE)).toString().trim().equals(Constants.ITEM_DATA_TYPE_DATE)
				)
			    && (item.containsKey(Constants.ITEM_MAP_ID)
			    	&& item.get(Constants.ITEM_MAP_ID) != null
			    	&& record.containsKey(item.get(Constants.ITEM_MAP_ID).toString().trim())
			    	&& record.get(item.get(Constants.ITEM_MAP_ID).toString().trim()) != null
			    	&& record.get(item.get(Constants.ITEM_MAP_ID).toString().trim()).toString().length() > dataLen)) {
				com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM MAPPING 1 ERROR:" + "["+item+"]["+record+"]");
				return "Y";
			}
		}
		
		if(item.get(Constants.ITEM_DATA_TYPE).toString().equals(Constants.ITEM_DATA_TYPE_NUMBER) 
				&& item.containsKey(Constants.ITEM_MAP_ID)
		    	&& item.get(Constants.ITEM_MAP_ID) != null
		    	&& record.get(item.get(Constants.ITEM_MAP_ID).toString().trim()) != null
				&& !isNumber(record.get(item.get(Constants.ITEM_MAP_ID).toString().trim()).toString())) {
			com.koreacb.kais.GlobalLogger.log(this,"#### [DATA ERROR] : ITEM MAPPING 2  ERROR:" + "["+item+"]["+record+"]");
			return "Y";
		}
		return "N";
	}
	
	private boolean isNumber(String num ) {
		try {
			Double.parseDouble(num);
			return true;
		}catch(Exception e) {return false;}
	}

	public void executeInReading(String mapperName, MyBatisUtils target, Map<String, Object> result) throws Exception {
		target.insert(mapperName, result);
	}
}
