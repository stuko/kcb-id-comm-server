package com.koreacb.kais.data.server.load;

public class DBDataLoadInfo extends DataLoadInfo{
	
	String sourceUrl;
	String sourceId;
	String sourcePw;
	String sourceSql;
	String sourceDriver;
	String sourceEnvName = "sourceDataSource";
	String sourceMapper;
	
	public String getSourceMapper() {
		return sourceMapper;
	}

	public void setSourceMapper(String sourceMapper) {
		this.sourceMapper = sourceMapper;
	}

	public String getSourceUrl() {
		return sourceUrl;
	}

	public void setSourceUrl(String sourceUrl) {
		this.sourceUrl = sourceUrl;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getSourcePw() {
		return sourcePw;
	}

	public void setSourcePw(String sourcePw) {
		this.sourcePw = sourcePw;
	}

	public String getSourceSql() {
		return sourceSql;
	}

	public void setSourceSql(String sourceSql) {
		this.sourceSql = sourceSql;
	}
	
	public String getSourceDriver() {
		return sourceDriver;
	}

	public void setSourceDriver(String sourceDriver) {
		this.sourceDriver = sourceDriver;
	}

	
	public String getSourceEnvName() {
		return sourceEnvName;
	}

	public void setSourceEnvName(String sourceEnvName) {
		this.sourceEnvName = sourceEnvName;
	}


	
	
}
