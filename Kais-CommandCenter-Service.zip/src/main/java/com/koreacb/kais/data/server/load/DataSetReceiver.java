package com.koreacb.kais.data.server.load;

import java.io.File;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.koreacb.kais.Constants;
import com.koreacb.kais.ExecutorInLoading;
import com.koreacb.kais.status.StatusManager;

public class DataSetReceiver extends ExecutorInLoading{
	
	StatusManager tf = new StatusManager();
	/*
	 * ------------------------------------------------------
	 *  데이터셋 로딩 요청 (파일, SQL, 기존 데이터 셋) 
	 * ------------------------------------------------------
	 */
	
	public void requestDataSetLoad(Map<String,Object> parameter) throws Exception{
		
		String ddl = null;
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		List<Map<String,Object>> itmInf = (List<Map<String,Object>>)parameter.get(Constants.ITEM_INF);
		if(dataSetBscInf == null) return;
        
		if(!this.checkDataSetInfo(dataSetBscInf)) {
			ddl = this.executeCreateDataSetDDL(dataSetBscInf, itmInf, this.getUtils(), ddl );
		}
		
		if(Constants.RULE_TP_LOADING_OPT_TRUNCATE.equals(dataSetBscInf.get(Constants.RULE_TP_LOADING_OPT).toString())) {
			// com.koreacb.kais.GlobalLogger.log(this,"### Data loading table will be truncated.... ###");
			this.executeTruncateDataSetSQL(this.getUtils(),dataSetBscInf);
		}else if(Constants.RULE_TP_LOADING_OPT_DROP.equals(dataSetBscInf.get(Constants.RULE_TP_LOADING_OPT).toString())) {
			this.executeDROPSQL(this.getUtils(),dataSetBscInf);
			ddl = this.executeCreateDataSetDDL(dataSetBscInf, itmInf, this.getUtils(), ddl);
		}

		this.ready(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
				,dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
				,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
		
		load(true, dataSetBscInf, itmInf, LOAD_ALL);
		
	}
	
	/*
	 * ------------------------------------------------------
	 *  데이터셋 로딩 전 10개의 레코드 요청 
	 * ------------------------------------------------------
	 */
	public List<Map<String,Object>> requestDataSet10Record(Map<String,Object> parameter) throws Exception{
		String ddl = null;
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.TEST_DATA);
		List<Map<String,Object>> itmInf = (List<Map<String,Object>>)parameter.get(Constants.ITEM_INF);
		
		List<Map<String,Object>> result = load(false, dataSetBscInf, itmInf, LOAD_10_RECORD);
		List<Map<String,Object>> reverse = new ArrayList<>();
		
		com.koreacb.kais.GlobalLogger.log(this,"OUTPUT : ["+result+"]");
		
		if(result.size() > 0) {
			for(String k : result.get(0).keySet()) {
				Map<String,Object> record = new HashMap<>();
				record.put("ITM_ID",k);
				int row = 0;
				for(Map<String,Object> m : result) {
					record.put("VAL"+(row+1), m.get(k));
					row++;
				}
				reverse.add(record);
			}
		}
		
		com.koreacb.kais.GlobalLogger.log(this,"REVERSE OUTPUT : ["+reverse+"]");
		
		return reverse;
	}
	
	/*
	 * ------------------------------------------------------
	 *  데이터셋 기본 통계 요청 
	 * ------------------------------------------------------
	 */
	public boolean requestDataSetStats(Map<String,Object> parameter) throws Exception{
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		try {
			return this.proceedAnalysis(true, parameter);
		}catch(Exception e) {
			this.error( dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
					   ,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString(), 0,0);
			e.printStackTrace();
			return false;
		}
	}

	/*
	 * ------------------------------------------------------
	 *  데이터셋 다차원 통계 요청 
	 * ------------------------------------------------------
	 */
	public boolean requestMultiDimenStats(Map<String,Object> parameter) throws Exception{
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		try {
			return this.proceedDimenAnalysis(parameter);
		}catch(Exception e) {
			this.error( dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
					   ,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString(), 0,0);
			e.printStackTrace();
			return false;
		}
	}
	
	/*
	 * ------------------------------------------------------
	 *  데이터셋 로딩 취소 요청 
	 * ------------------------------------------------------
	 */
	public boolean cancelLoadingDataSet(Map<String,Object> parameter) throws Exception{
		return cancelBatch(parameter);
	}
	/*
	 * ------------------------------------------------------
	 *  데이터셋 통계 취소 요청 
	 * ------------------------------------------------------
	 */
	public boolean cancelAnalysisDataSet(Map<String,Object> parameter) throws Exception{
		return cancelBatch(parameter);
	}
	/*
	 * ------------------------------------------------------
	 *  데이터셋 파일 Export 취소 요청 
	 * ------------------------------------------------------
	 */
	public boolean cancelExportDataSet(Map<String,Object> parameter) throws Exception{
		return cancelBatch(parameter);
	}
	/*
	 * ------------------------------------------------------
	 *  데이터셋 파일 Export 요청 
	 * ------------------------------------------------------
	 */
	public boolean exportDataSet(Map<String,Object> parameter) throws Exception{
		
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		List<Map<String,Object>> metaInf = parameter.containsKey(Constants.DATA_SET_BASIC_EXPORT_RESULT_META_INF) ? (List<Map<String,Object>>)parameter.get(Constants.DATA_SET_BASIC_EXPORT_RESULT_META_INF) : null;
		
		try {
			
			if(!this.checkDataSetInfo(dataSetBscInf)) {
				return false;
			}
			this.ready(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
					,dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
					,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
	
			DataSetDataLoadInfo info = new DataSetDataLoadInfo();
			// com.koreacb.kais.GlobalLogger.log(this,dataSetBscInf);
			String format = dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_FORMAT).toString();
			String delim = dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_DELIM).toString();
			String header = dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_HEADER).toString();
			info.setDataSetId(dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString());
			info.setDataSetLoadingTableId(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString());
			
			if(dataSetBscInf.containsKey(Constants.DATA_SET_BASIC_LOADING_COND)) {
				List<Map<String,Object>> cond =  (List<Map<String,Object>>)dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_COND);
				info.addLoadingCondition(cond);
			}
	
			if(!this.createExportedInfoFile(Paths.get(dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_PATH).toString() + File.separator + dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_FILE).toString() + ".csv.info"), header, delim)) {
				throw new Exception("Can not create file Exception" );
			}
			if(!this.createExportedMetaFile(Paths.get(dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_PATH).toString() + File.separator + dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_FILE).toString() + ".csv.meta"), metaInf)) {
				throw new Exception("Can not create Meta file Exception" );
			}
			Path path = Paths.get(dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_PATH).toString() + File.separator + dataSetBscInf.get(Constants.DATA_SET_BASIC_EXPORT_FILE).toString() + ".csv");
			
			if(header != null && "Y".equals(header)) {
				appendHeaderToExportedFile(metaInf, path, delim);
			}else {
				createExportedFile(metaInf,path,delim);
			}
			
			info.setLoad(false);
			
			DataSetLoader loader = new DataSetLoader( (status, rowCount, last , rs , itemList, code, total , err)-> {
				try {
					if((rowCount == 1 || last) && dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null)
						if(status ) getStatus().transfer( null, rs
														, dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
								                        , dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
								                        , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString()
								                        , code
								                        , total
								                        , err);
					if(rs != null) {
						// com.koreacb.kais.GlobalLogger.log(this,"File Exporting... before file append --> ["+itemList+"]["+rs+"]");
						if(!appendDataToExportedFile(itemList, path, delim, rs)) {
							throw new Exception("Can not append file Exception" );
						}
					}
				} catch (Exception e) {
					this.error( dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
							   ,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString(), 0,0);
					com.koreacb.kais.GlobalLogger.log(this,"File Exporting... ["+e.toString()+"]");
					throw new Exception(e);
				}
				return null;
			});
			
			loader.setBatch(true);
			loader.setFetchSize(100);
			loader.dataSet(info, dataSetBscInf, metaInf);
		}catch(Exception e) {
			this.error( dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
					   ,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString(), 0,0);
			e.printStackTrace();
		}
		return true;
	}

	private boolean createExportedInfoFile(Path path, String header, String delim) throws Exception {
		try(PrintWriter writer = new PrintWriter(Files.newBufferedWriter(path,Charset.forName(Constants.DATA_SET_BASIC_CHAR_SET),StandardOpenOption.CREATE))){
			Map<String,Object> infoMap = new HashMap<>();
			infoMap.put(Constants.DATA_SET_BASIC_EXPORT_RESULT_INFO_HEADER, header);
			infoMap.put(Constants.DATA_SET_BASIC_EXPORT_RESULT_INFO_SEPARATOR, delim);
			writer.println(new JSONObject(infoMap).toString() );
			return true;
		} catch (Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"File Exporting... ["+e.toString()+"]");
			return false;
		}
	}
	
	public boolean createExportedMetaFile(Path path, List<Map<String,Object>> metaInf) throws Exception{
		
		try(PrintWriter writer = new PrintWriter(Files.newBufferedWriter(path,Charset.forName(Constants.DATA_SET_BASIC_CHAR_SET),StandardOpenOption.CREATE))){
			Map<String,Object> metaMap = new HashMap<>();
			
			List<Map<String,Object>> metaList = new ArrayList<>();
			for(Map<String,Object> m : metaInf) {
				Map<String,Object> metaRecord = new HashMap<>();
				metaRecord.put(Constants.DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_ORDER,m.get(Constants.DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_ORDER));
				metaRecord.put(Constants.DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_ID,m.get(Constants.DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_ID));
				metaRecord.put(Constants.DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_NAME,m.get(Constants.DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_NAME));
				metaRecord.put(Constants.DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT_TYPE,m.get(Constants.DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_TYPE));
				metaList.add(metaRecord);
			}
			metaMap.put(Constants.DATA_SET_BASIC_EXPORT_RESULT_META_LAYOUT, metaList);
			writer.println(new JSONObject(metaMap).toString() );
			return true;
		} catch (Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"File Exporting... ["+e.toString()+"]");
			return false;
		}

	}
	
	private boolean appendHeaderToExportedFile(List<Map<String, Object>> itmInf, Path path, String delim) throws Exception {
		try(PrintWriter writer = new PrintWriter(Files.newBufferedWriter(path,Charset.forName(Constants.DATA_SET_BASIC_CHAR_SET),StandardOpenOption.CREATE))){
			StringBuilder sb = new StringBuilder();
			int i = 0;
			// com.koreacb.kais.GlobalLogger.log(this,"File Exporting... OK let's append header!!! ["+itmInf+"]");
			for(Map<String,Object> item : itmInf) {
				i++;
				sb.append(item.get(Constants.DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_ID).toString());
				if(itmInf.size() > i)sb.append(delim);
			}
			writer.println(sb.toString());
			return true;
		} catch (Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"File Exporting... ["+e.toString()+"]");
			return false;
		}
	}
	
	private boolean createExportedFile(List<Map<String, Object>> itmInf, Path path, String delim) throws Exception {
		try(PrintWriter writer = new PrintWriter(Files.newBufferedWriter(path,Charset.forName(Constants.DATA_SET_BASIC_CHAR_SET),StandardOpenOption.CREATE))){
			return true;
		} catch (Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"File Exporting... ["+e.toString()+"]");
			return false;
		}
	}


	private boolean appendDataToExportedFile(List<Map<String, Object>> itmInf, Path path, String delim,Map<String, Object> rs) throws Exception {
		try(PrintWriter writer = new PrintWriter(Files.newBufferedWriter(path,Charset.forName(Constants.DATA_SET_BASIC_CHAR_SET),StandardOpenOption.CREATE,StandardOpenOption.APPEND))){
			StringBuilder sb = new StringBuilder();
			if(itmInf != null) {
				int i = 0;
				// com.koreacb.kais.GlobalLogger.log(this,"File Exporting... let's append!!! ---> ["+itmInf+"]["+rs+"]");
				for(Map<String,Object> item : itmInf) {
					i++;
					sb.append(rs.get(item.get(Constants.DATA_SET_BASIC_EXPORT_RESULT_PARAM_LAYOUT_ID)).toString());
					if(itmInf.size() > i)sb.append(delim);
				}
				writer.println(sb.toString());
			}else {
				int i = 0;
				for(String k : rs.keySet()) {
					i++;
					sb.append(rs.get(k).toString());
					if(rs.size() > i)sb.append(delim);
				}
				writer.println(sb.toString());
			}
			return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}



