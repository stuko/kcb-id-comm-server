package com.koreacb.kais.data.server.load;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreacb.kais.Constants;

public class DataSetDataLoadInfo  extends DataLoadInfo{
	
	String dataSetId;
	String dataLoadId;
	String dataSetLoadingTableId;
	boolean ignoreFiltering = false;
	
	Map<String,List<LoadingCondition>> loadingCond;
	
	public DataSetDataLoadInfo() {
		loadingCond = new HashMap<>();
	}
	public boolean isIgnoreFiltering() {
		return ignoreFiltering;
	}
	public void setIgnoreFiltering(boolean ignoreFiltering) {
		this.ignoreFiltering = ignoreFiltering;
	}
	public String getDataLoadId() {
		return dataLoadId;
	}
	public void setDataLoadId(String dataLoadId) {
		this.dataLoadId = dataLoadId;
	}
	public String getDataSetId() {
		return dataSetId;
	}
	public void setDataSetId(String dataSetId) {
		this.dataSetId = dataSetId;
	}
	public Map<String, List<LoadingCondition>> getLoadingCond() {
		return loadingCond;
	}
	public void setLoadingCond(Map<String, List<LoadingCondition>> loadingCond) {
		this.loadingCond = loadingCond;
	}
	public String getDataSetLoadingTableId() {
		return dataSetLoadingTableId;
	}
	public void setDataSetLoadingTableId(String dataSetLoadingTableId) {
		this.dataSetLoadingTableId = dataSetLoadingTableId;
	}
	public void addLoadingCondition(List<Map<String,Object>> cond) {
		if(cond != null) {
			for(Map<String,Object> c : cond) {
				if(c.get(Constants.DATA_SET_BASIC_LOADING_COND_OR_GROUP) != null
				&& c.get(Constants.DATA_SET_BASIC_LOADING_COND_ITEM_ID) != null
				&& c.get(Constants.DATA_SET_BASIC_LOADING_COND_IN_VALUE) != null
				&& c.get(Constants.DATA_SET_BASIC_LOADING_COND_OPERAND) != null) {
					this.addLoadingCondition(c.get(Constants.DATA_SET_BASIC_LOADING_COND_OR_GROUP).toString()
										   , c.get(Constants.DATA_SET_BASIC_LOADING_COND_ITEM_ID).toString()
										   , c.get(Constants.DAT_SET_ITM_TP).toString()
										   , c.get(Constants.DATA_SET_BASIC_LOADING_COND_IN_VALUE).toString()
										   , c.get(Constants.DATA_SET_BASIC_LOADING_COND_OPERAND).toString());
				}
			}
		}
	}
	public void addLoadingCondition(String orGroup, String itemId, String type, String inputValue, String operation) {
		LoadingCondition loadingCondition = new LoadingCondition();
		loadingCondition.setInputValue(inputValue);
		loadingCondition.setItemId(itemId);
		loadingCondition.setType(type);
		loadingCondition.setOperation(operation);
		loadingCondition.setOrGroup(orGroup);
		if(!this.getLoadingCond().containsKey(orGroup)) {
			this.getLoadingCond().put(orGroup, new ArrayList<LoadingCondition>());
		}
		this.getLoadingCond().get(orGroup).add(loadingCondition);
	}
	
}
