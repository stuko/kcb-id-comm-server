package com.koreacb.kais.data.server.load;

public class FileDataLoadInfo  extends DataLoadInfo{
	boolean header;
	String delimeter;
	String path;
	public boolean hasHeader() {
		return header;
	}
	public void setHeader(boolean header) {
		this.header = header;
	}
	public String getDelimeter() {
		if(delimeter.equals("|")) return "\\|";
		else return delimeter;
	}
	public void setDelimeter(String delimeter) {
		this.delimeter = delimeter;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
}
