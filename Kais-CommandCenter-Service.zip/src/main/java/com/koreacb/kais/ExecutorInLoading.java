package com.koreacb.kais;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.koreacb.kais.data.server.load.DBDataLoadInfo;
import com.koreacb.kais.data.server.load.DataSetDataLoadInfo;
import com.koreacb.kais.data.server.load.DataSetLoader;
import com.koreacb.kais.data.server.load.FileDataLoadInfo;
import com.koreacb.kais.mybatis.MultiMyBatisUtils;
import com.koreacb.kais.mybatis.RuleResultExecutorInDataLoading;
import com.koreacb.kais.mybatis.TableBuilder;
import com.koreacb.kais.stats.DataSetStatsInfo;
import com.koreacb.kais.stats.multi.RangeCond;
import com.koreacb.kais.stats.multi.RangeDimen;
import com.koreacb.kais.stats.multi.ValueDimen;
import com.koreacb.kais.status.LoadingAndStatsStatusManager;
import com.koreacb.kais.status.StatusManager;

public class ExecutorInLoading {
	
	public static int LOAD_ALL = -1;
	public static int LOAD_10_RECORD = 10;
	
	MultiMyBatisUtils utils = new MultiMyBatisUtils(false);

	StatusManager status = new StatusManager();
	
	public MultiMyBatisUtils getUtils() {
		return utils;
	}
	public void setUtils(MultiMyBatisUtils utils) {
		this.utils = utils;
	}
	
	public StatusManager getStatus() {
		return status;
	}
	public void setStatus(StatusManager status) {
		this.status = status;
	}
	public void ready(String ldn_table_id, String id, String wrk_id) {
		// LoadingAndStatsStatusManager.getInstance().clear(id);
		this.getStatus().transfer(null, null, ldn_table_id, id, wrk_id, "R", 0, 0);
	}

	public void cancel(String ldn_table_id,String id, String wrk_id, int total,int err) {
		this.getStatus().cancel(null, id, wrk_id, "T", total, err);
	}

	public void error(String id, String wrk_id, int total,int err) {
		this.getStatus().update(null, id, wrk_id, "E", total, err);
	}

	public Map<String,Object> loadDataSetForRuleExecuting(boolean isLoading, boolean isResult, Map<String,Object> parameter, RuleResultExecutorInDataLoading executor) throws Exception{
		
		Map<String,Object> dataSetBscInf = null;
		if(parameter.get(Constants.DATA_SET_BASIC_INF) != null) dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		List<Map<String,Object>> itmInf = null;
		if(parameter.get(Constants.ITEM_INF) != null) itmInf = (List<Map<String,Object>>)parameter.get(Constants.ITEM_INF);
		List<Map<String,Object>> cond = null;
		if(parameter.get(Constants.DATA_SET_BASIC_LOADING_COND) != null) cond = (List<Map<String,Object>>)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND);
		
		String loadingId = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString() : "";
		String dataSetId = dataSetBscInf.get(Constants.DATA_SET_BASIC_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString() : "";
		
		DataSetDataLoadInfo info = new DataSetDataLoadInfo();
		info.setDataSetId(dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString());
		info.setDataSetLoadingTableId(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString());
		info.addLoadingCondition(cond);
		info.setLoad(isLoading);
		info.setResult(isResult);
		
		DataSetLoader loader = new DataSetLoader( (status, rowCount, last, rs, itemList, code, total, err)-> {
			Map<String,Object> result = null;
			try {
				// 룰 데이터의 적재 결과를 전송해 준다.
				if((rowCount == 1 || last) && loadingId != null)
					if(status ) getStatus().transfer(null, rs
								  , info.getDataSetLoadingTableId()
	                              , dataSetId
	                              , loadingId
	                              , code
	                              , total
	                              , err);
				
				if(executor != null && !last) {
					result = executor.executeRuleAndStoreResult(parameter, rs);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception(e);
			}
			return result;
		});
		loader.setBatch(true);
		loader.setFetchSize(100);
		loader.dataSet(info, dataSetBscInf, itmInf);
		
		if(loader.getTotalCount() == 0) {
			this.error(dataSetId, loadingId, 0, 0);
		}
		
		// 작업이 완료 된 경우, 완료 상태로 해준다.
		LoadingAndStatsStatusManager.getInstance().setLoadingAndStatsComplete(dataSetId, loadingId);
		
		return null;
	}

	public boolean proceedAnalysis(boolean status, Map<String,Object> parameter)  throws Exception{
		return this.proceedAnalysis(status, null, parameter);		
	}
	
	public boolean proceedAnalysis(boolean isAfter, boolean loadAll, boolean status, String env, Map<String,Object> parameter)  throws Exception{

		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		DataSetStatsInfo stats = this.createDataStatsInfo(parameter);
		// 분석 로딩시, 전체 데이터 로딩  혹은 작업 범위 데이터 로딩에 사용하기 위함.
		// 시뮬레이션/룰 실행한 결과 분석시에는 LoadAll = false 로 들어 옴
		stats.getDataSetDataLoadInfo().setLoadAll(loadAll);
		
		if(!isAfter) {
			this.ready(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
				, dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
				, dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
		}
		
		String[] svs = null;
		try {
			// 2018.08.13
			// Special value 처리 관련.
			stats.setItemInf((List<Map<String,Object>>)parameter.get(Constants.ANALYSIS_ITEM_DATA));
			/*
			 * Special Value는 analysis_item_data 아래에 위치 하게 됨.
			if(parameter.get(Constants.SPECIAL_VALUE) != null) {
				String strSV = parameter.get(Constants.SPECIAL_VALUE).toString();
				svs = strSV.split(",");
			}
			
			stats.setSvInf(svs);
			*/
			return stats.analysis(status, env);
		} catch (Exception e) {
			this.error( dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
					   ,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString(), 0,0);
			e.printStackTrace();
			return false;
		}		
		 
		
	}
	
	public boolean proceedAnalysis(boolean loadAll, boolean status, String env, Map<String,Object> parameter)  throws Exception{
		return this.proceedAnalysis(false, loadAll, status, env, parameter);	
	}
	
	public boolean proceedAnalysis(boolean status, String env, Map<String,Object> parameter)  throws Exception{
		return this.proceedAnalysis(true, status, env, parameter);
	}
	
	public boolean proceedDimenAnalysis(Map<String,Object> parameter) throws Exception{
		return this.proceedDimenAnalysis(null, parameter);
	}
	
	public boolean proceedDimenAnalysis(String env, Map<String,Object> parameter)  throws Exception{
		
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		
		// 차원의 정보(리스트)
		List<Map<String,Object>> dmItemInf = (List<Map<String,Object>>)parameter.get(Constants.ANALYSIS_DM_ITEM_DATA);
		// 통계 산출 항목 정보(리스트)
		List<Map<String,Object>> ftItemInf = (List<Map<String,Object>>)parameter.get(Constants.ANALYSIS_FT_ITEM_DATA);
		
		if(dmItemInf == null || ftItemInf == null || dmItemInf.size() == 0 || ftItemInf.size() == 0) {
			com.koreacb.kais.GlobalLogger.log(this,"Analysis item is NULL");
			return false;
		}
		
		DataSetStatsInfo stats = this.createDataStatsInfo(parameter);
		this.ready(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
				,dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
				,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
		try {
			List<RangeDimen> rangeDimenList = stats.getDimenAnalysis().getRangeDimenList();
		
			List<RangeDimen> rdList = new ArrayList<>();
			
			for(Map<String,Object> dm : dmItemInf) {

				RangeDimen rd = new RangeDimen();
				String type = dm.get(Constants.GROUP_TP).toString();
				String item_id = dm.get(Constants.ANAL_DM_ITM_ID).toString();
				String item_type = dm.get(Constants.ANAL_DM_ITM_TP).toString();
				
				rd.setItemId(item_id);
				rd.setItemType(item_type);
				rd.setType(type);
				rd.setFactTemplate(getNewValueDimen(ftItemInf));
				
				// 차원의 범위를 지정하는 경우
				// 범위 이름을 나타냄.
				if(type.equals(Constants.ANALYSIS_DM_R_TYPE)) {
					if(dm.containsKey(Constants.SPRT_LIST)) {
						List<Map<String,Object>> list = (List<Map<String,Object>>)dm.get(Constants.SPRT_LIST);
						for(int i = 0; i < list.size() ; i++) {
							Map<String,Object> range = list.get(i);
							// 범위 이름을 저장 한다.
							String range_id = range.get(Constants.SPRT_ITM_ID).toString();
							String upper_tp = range.get(Constants.SPRT_HGLM_CND_TP).toString();
							String upper_vl = range.get(Constants.SPRT_HGLM_CND_VL).toString();
							String lower_tp = range.get(Constants.SPRT_LWLM_CND_TP).toString();
							String lower_vl = range.get(Constants.SPRT_LWLM_CND_VL).toString();
							RangeCond rc = rd.addRangeCondTemplate(range_id, item_id, upper_tp, upper_vl, lower_tp, lower_vl);
							com.koreacb.kais.GlobalLogger.log(this,"##### SPRT ##### " + list);
						}
					}else {
						com.koreacb.kais.GlobalLogger.log(this,"Analysis dimension type is range but list is NULL");
						return false;
					}
					
				}else { 
					// 차원의 값을 지정하는 경우,
					// 차원의 값을 읽어야 하므로, Data Loading 을 하고, Scanning 하면서, 만들어야 함.
					// eval 시점에 생성하게 함. 
				}
				rdList.add(rd);
			}
			
			RangeDimen root = null;
			
			/*
			 *   
			 * RangeDimenList[] : List
			 *     [0] Root : RangeDimen
			 *          - Child : RangeDimen (Type : V or R) : R인경우 RangeCond 안에 List로 범위별 RangeDimen이 들어가게 됨.
			 *                 - ChildRange : Dimen  (Type : V or R) : V인경우 distinctTable 안에 Map에 키는 Value, 값은 RangeDimen으로 들어가게 됨.
			 *                     .......
			 *                     
			 * 향후, eval 을 실행할 경우,(Root RangeDimen)                     
			 * RootDimen의 타입이  V 혹은 R 인경우, 각 조건에 해당하는 값의 RangeDimen이 없는 경우, RangeDimen을 생성하여, 계산함.
			 */
			
			StringBuilder sb = new StringBuilder();
			for(int i = 0; i < rdList.size(); i++) {
				
				for(int x = 0; x < i; x++)sb.append("\t");
				
				if(root == null) {
					com.koreacb.kais.GlobalLogger.log(this,"#################### Root !!!!!!!!!!!!!!!!!!!!");
					// RangeDimen의 복사본에 저장된 중요한 정보
					// Range(R)타입의 경우: 현재 차원의 항목아이디 존재함
					//                , ValueDimen에 구해야할 통계/분석 항목아이디 존재함
					//                , RangeCond에 해당항목(차원의) 아이디와 차원의 서브조건명이 존재함.
					// V 타입의 경우: 현재 차원의 항목아이디 존재함
					//                , ValueDimen에 구해야할 통계/분석 항목아이디 존재함
					root = (RangeDimen)rdList.get(i).clone();
					rangeDimenList.add(root);
					sb.append(root.getItemId() + " i'm root , child = " + root.getChildRangeDimen() + " , parent  = " + root.getParentRangeDimen() + "\n");
					continue;
				}
				RangeDimen rd = (RangeDimen)rdList.get(i).clone();
				
				root.setChildRangeDimen(rd);
				rd.setParentRangeDimen(root);
				sb.append(rd.getItemId() + ", child = " + rd.getChildRangeDimen() + " , parent  = " + rd.getParentRangeDimen() + "\n");
				
				if(root.getType().equals(Constants.ANALYSIS_DM_R_TYPE)) {
					// TODO
				}else if(root.getType().equals(Constants.ANALYSIS_DM_V_TYPE)) {
					// TODO
				}else{
					com.koreacb.kais.GlobalLogger.log(this,"###### Type error.....");
				}
				
				root = root.getChildRangeDimen();
			}
			com.koreacb.kais.GlobalLogger.log(this,"#### Range Depth Structure ####");
			com.koreacb.kais.GlobalLogger.log(this,"RangeDimen's count : " + rangeDimenList.size());
			com.koreacb.kais.GlobalLogger.log(this,sb.toString());
			com.koreacb.kais.GlobalLogger.log(this,"#### Range Depth Structure ####");
			
			
			return stats.analysisDimention(env);
		} catch (Exception e) {
			com.koreacb.kais.GlobalLogger.log(this,"####### Analysis Dimention Exception + " + e.toString());
			try {
				this.error( dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
						   ,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString(), 0,0);
			}catch(Exception ee) {}
			e.printStackTrace();
		}		
		return false;
	}
	
	/*
	 // 아래 메서드는 다차원 분석의 테스트 결과가 정상이면, 삭제 해도 됨.
	 // 방식이 바뀔수 있으므로, 남겨 둠. 
	private boolean addFactDimension(List<Map<String, Object>> ftItemInf
									, RangeDimen root
									, Map<String, Object> dm
									, String type
									, String item_id
									, String item_type) {
		
		root.setItemId(item_id);
		root.setItemType(item_type);
		root.setType(type);
		root.setFactTemplate(getNewValueDimen(ftItemInf));
		
		// 차원의 범위를 지정하는 경우
		if(type.equals(Constants.ANALYSIS_DM_R_TYPE)) {
			if(dm.containsKey(Constants.SPRT_LIST)) {
				List<Map<String,Object>> list = (List<Map<String,Object>>)dm.get(Constants.SPRT_LIST);
				for(int i = 0; i < list.size() ; i++) {
					Map<String,Object> range = list.get(i);
					String range_id = range.get(Constants.SPRT_ITM_ID).toString();
					String upper_tp = range.get(Constants.SPRT_HGLM_CND_TP).toString();
					String upper_vl = range.get(Constants.SPRT_HGLM_CND_VL).toString();
					String lower_tp = range.get(Constants.SPRT_LWLM_CND_TP).toString();
					String lower_vl = range.get(Constants.SPRT_LWLM_CND_VL).toString();
					root.addRangeCond(range_id, item_id, upper_tp, upper_vl, lower_tp, lower_vl);
				}
			}else {
				com.koreacb.kais.GlobalLogger.log(this,"Analysis dimension type is range but list is NULL");
				return false;
			}
			
		}else { // 차원의 값을 지정하는 경우,
			// 차원의 값을 읽어야 하므로, Data Loading 을 하고, Scanning 하면서, 만들어야 함.
		}
		return true;
	}
	*/
	
	// 분석/통계 항목 정보를 생성한다.
	private List<ValueDimen> getNewValueDimen(List<Map<String, Object>> ftItemInf) {
		List<ValueDimen> vm = new ArrayList<>();
		ftItemInf.forEach((m)->{
			vm.add(new ValueDimen());
			// 분석/통계항목 아이디 (후에 저장할 경우, R타입(범위)인 경우, F_ID 를 나타냄 , 즉 항목 이름을 나중에 표현해 줘야 함.)
			vm.get(vm.size()-1).setItemId(m.get(Constants.ANL_FT_ITM_ID).toString());
			vm.get(vm.size()-1).setItemName(m.get(Constants.ANL_FT_ITM_ID).toString());
			vm.get(vm.size()-1).setType(m.get(Constants.ANL_FT_ITM_TP).toString());
			if(m.get(Constants.FT_CNT) != null && m.get(Constants.FT_CNT).toString().equals("Y"))vm.get(vm.size()-1).setEnableCount(true);
			if(m.get(Constants.FT_MAX) != null && m.get(Constants.FT_MAX).toString().equals("Y"))vm.get(vm.size()-1).setEnableMax(true);
			if(m.get(Constants.FT_MIN) != null && m.get(Constants.FT_MIN).toString().equals("Y"))vm.get(vm.size()-1).setEnableMin(true);
			if(m.get(Constants.FT_AVG) != null && m.get(Constants.FT_AVG).toString().equals("Y"))vm.get(vm.size()-1).setEnableAvg(true);
			if(m.get(Constants.FT_SUM) != null && m.get(Constants.FT_SUM).toString().equals("Y"))vm.get(vm.size()-1).setEnableSum(true);
		});
		return vm;
	}
	
	public boolean cancelBatch(Map<String, Object> parameter) {
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		String dataSetId = dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString();
		String loadingAndStatsId = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString();
		LoadingAndStatsStatusManager.getInstance().setLoadingAndStatsStop(dataSetId, loadingAndStatsId);
		this.cancel(null, dataSetId, loadingAndStatsId, 0, 0);
		return true;
	}
	
	public boolean checkDataSetInfo(Map<String,Object> dataSetBscInf) throws Exception{
		List<Map<String,Object>> result = this.getUtils().select("selectDsetTableList"
													,dataSetBscInf
													,Constants.DATA_SET_BASIC_LOADING_TABLE_ID
													,"DSET_TABLE");
		if(result != null && result.size() == 1) return true;
		else return false;
	}

	public boolean checkRuleResultInfo(Map<String,Object> dataSetBscInf) throws Exception{
		List<Map<String,Object>> result = this.getUtils().select("selectRuleResultTableList"
													,dataSetBscInf
													,Constants.RULE_RESULT_TABLE
													,"RULE_RESULT_TABLE");
		if(result != null && result.size() == 1) return true;
		else return false;
	}

	public List<Map<String, Object>> load(boolean load, Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf, int limit) throws Exception {
		try {
			if(Constants.LOADING_RULE_TP_SRC_TP_FILE.equals(dataSetBscInf.get(Constants.LOADING_RULE_TP_SRC_TP).toString())) {
				return loadFile(load, dataSetBscInf, itmInf, limit);
			}else if(Constants.LOADING_RULE_TP_SRC_TP_SQL.equals(dataSetBscInf.get(Constants.LOADING_RULE_TP_SRC_TP).toString())) {
				return loadSql(load, dataSetBscInf, itmInf, limit);
			}else if(Constants.LOADING_RULE_TP_SRC_TP_DS.equals(dataSetBscInf.get(Constants.LOADING_RULE_TP_SRC_TP).toString())) {
				return loadDataSet(load,dataSetBscInf, itmInf, limit);
			}else return null;
		}catch(Exception e) {
			this.error( dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
					   ,dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString(),0, 0);
			e.printStackTrace();
			return null;
		}
	}

	public List<Map<String,Object>> loadFile(boolean load, Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf,
			 int limit) throws Exception {
		FileDataLoadInfo info = new FileDataLoadInfo();
		info.setLoad(load);
		info.setDelimeter(dataSetBscInf.get(Constants.LOADING_RULE_FILE_DELM).toString());
		info.setHeader(dataSetBscInf.get(Constants.LOADING_RULE_FILE_HEADER).toString().equals("Y") ? true : false);
		info.setPath(dataSetBscInf.get(Constants.LOADING_RULE_FILE_PATH).toString() + dataSetBscInf.get(Constants.LOADING_RULE_FILE_NAME).toString());

		//--------------------------------------------
		// 상태 전달 로직
		//--------------------------------------------		
		DataSetLoader loader = new DataSetLoader( (status , rowCount, last, rs, itemList,  code, total, err)-> {
			if((rowCount == 1   || last ) && dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null) {
				com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... [rowCount/last : "+rowCount+ "/" + last + "]");
								if(status ) {
									com.koreacb.kais.GlobalLogger.log(this,"ExecuteInReading... [rowCount/last/status : "+rowCount+ "/" + last + "/" + status + "]");
												getStatus().transfer(null, rs
											, dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()	
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString()
						                    , code
						                    , total
						                    , err);
								}
			}
			return rs;
		});
		loader.setBatch(true);
		loader.setFetchSize(100);
		return loader.file(info, dataSetBscInf,itmInf , limit);
	}

	public List<Map<String,Object>> loadSql(boolean load, Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf,
			int limit) throws Exception {
		DBDataLoadInfo info = new DBDataLoadInfo();
		info.setLoad(load);
		info.setSourceDriver(dataSetBscInf.get(Constants.LOADING_RULE_DB_DRIVER).toString());
		info.setSourceUrl(dataSetBscInf.get(Constants.LOADING_RULE_DB_URL).toString());
		info.setSourceId(dataSetBscInf.get(Constants.LOADING_RULE_DB_ID).toString());
		info.setSourcePw(dataSetBscInf.get(Constants.LOADING_RULE_DB_PW).toString());
		info.setSourceSql(dataSetBscInf.get(Constants.LOADING_RULE_DB_SQL).toString());

		//--------------------------------------------
		// 상태 전달 로직
		//--------------------------------------------		
		DataSetLoader loader = new DataSetLoader((status, rowCount, last, rs, itemList,  code, total, err)-> {
			if((rowCount == 1   || last )  && dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null)
				if(status ) getStatus().transfer(null, rs
										    , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString()
						                    , code
						                    , total
						                    , err);
			return rs;
		});
		loader.setBatch(true);
		loader.setFetchSize(100);
		return loader.sql(info, dataSetBscInf,itmInf , limit);
	}

	public List<Map<String,Object>> loadDataSet(boolean load, Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf,
			int limit) throws Exception {
		DataSetDataLoadInfo info = new DataSetDataLoadInfo();
		info.setLoad(load);
		info.setDataSetId(dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString());
		info.setDataSetLoadingTableId(dataSetBscInf.get(Constants.DATA_SET_BASIC_SOURCE_TABLE_ID).toString());
		List<Map<String,Object>> cond =  (List<Map<String,Object>>)dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_COND);
		info.addLoadingCondition(cond);

		//--------------------------------------------
		// 상태 전달 로직
		//--------------------------------------------		
		DataSetLoader loader = new DataSetLoader((status, rowCount, last, rs, itemList, code, total, err)-> {
			if((rowCount == 1   || last ) && dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null)
				if(status ) getStatus().transfer(null, rs
										    , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString()
						                    , code
						                    , total
						                    , err);
			return rs;
		});
		loader.setBatch(true);
		loader.setFetchSize(100);
		return loader.dataSet(info, dataSetBscInf,itmInf , limit);
	}

	public void executeDROPSQL(MultiMyBatisUtils utils , Map<String,Object> p) throws Exception {
		utils.insert("dropDsetTable", p, Constants.DATA_SET_BASIC_LOADING_TABLE_ID,"DSET_TABLE");
	}

	public void executeDROPRuleResultSQL(MultiMyBatisUtils utils , Map<String,Object> p) throws Exception {
		utils.insert("dropDsetTable", p, Constants.DATA_SET_BASIC_LOADING_TABLE_ID,"RULE_RESULT_TABLE");
	}

	public void executeTruncateDataSetSQL(MultiMyBatisUtils utils , Map<String,Object> p) throws Exception {
		utils.insert("truncDsetTable", p, Constants.DATA_SET_BASIC_LOADING_TABLE_ID,"DSET_TABLE");
	}

	public void executeTruncateRuleResultSQL(MultiMyBatisUtils utils , Map<String,Object> p) throws Exception {
		utils.insert("truncDsetTable", p, Constants.RULE_RESULT_TABLE,"RULE_RESULT_TABLE");
	}

	public String executeCreateDataSetDDL(Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf,
			MultiMyBatisUtils utils , String ddl) throws Exception {
		if( ddl == null ) ddl = createDataLoadingTable(dataSetBscInf, itmInf);
		utils.insert("insert", "executeSql",ddl);
		return ddl;
	}

	public String executeCreateRuleResultDDL(Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf,
			MultiMyBatisUtils utils , String ddl) throws Exception {
		if( ddl == null ) ddl = createRuleResultTable(dataSetBscInf, itmInf);
		utils.insert("insert", "executeSql",ddl);
		return ddl;
	}

	public String createDataLoadingTable(Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf) throws Exception {
		TableBuilder tb = new TableBuilder();
		tb.create(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString());
		tb.append("SCOL_DATASET_ID", "VARCHAR", 12, false, null)
		  .append("SCOL_LOADING_ID", "VARCHAR", 15, false, null)
		  .append("SCOL_RECORD_ID", "BIGINT", 20, false, null)
		  .append("SCOL_RANDOM_NO", "INT", 7, true, "NULL")
		  .append("SCOL_ERR_YN", "VARCHAR", 1, true, "NULL")
		  .append("SCOL_LOADING_DTM", "DATETIME", 0, true, "CURRENT_TIMESTAMP")
		  .append("SCOL_LOADING_DATA", "LONGTEXT", 0, true, "NULL")
		  .append("SCOL_ORIGNAL_DATA", "LONGTEXT", 0, true, "NULL");
		
		for(Map<String,Object> itm : itmInf) {
			if(itm.get(Constants.ITEM_USE_TYPE).toString().equals(Constants.ITEM_USE_TYPE_FILTER) || itm.get(Constants.ITEM_USE_TYPE).toString().equals(Constants.ITEM_USE_TYPE_PERFORMANCE)) {
				int len = itm.get(Constants.ITEM_DATA_LENGTH) == null ? 0 : Integer.parseInt(itm.get(Constants.ITEM_DATA_LENGTH).toString());
				tb.append(itm.get(Constants.ITEM_ID).toString(), itm.get(Constants.ITEM_DATA_TYPE).toString(),len, true, null);
			}
		}
		
		tb.key("SCOL_DATASET_ID","SCOL_LOADING_ID","SCOL_RECORD_ID","SCOL_RANDOM_NO");
		
		return tb.build();
	}

	public String createRuleResultTable(Map<String, Object> dataSetBscInf, List<Map<String, Object>> itmInf) throws Exception {
		TableBuilder tb = new TableBuilder();
		tb.create(dataSetBscInf.get(Constants.RULE_RESULT_TABLE).toString());
		tb.append("SCOL_DATASET_ID", "VARCHAR", 12, false, null)
		  .append("SCOL_LOADING_ID", "VARCHAR", 15, false, null)
		  .append("SCOL_RECORD_ID", "BIGINT", 20, false, null)
		  .append("SCOL_RANDOM_NO", "INT", 7, true, "NULL")
		  .append("SCOL_ERR_YN", "VARCHAR", 1, true, "NULL")
		  .append("SCOL_RULE_ERR_YN", "VARCHAR", 1, true, "NULL")
		  .append("SCOL_LOADING_DTM", "DATETIME", 0, true, "CURRENT_TIMESTAMP")
		  .append("SCOL_LOADING_DATA", "LONGTEXT", 0, true, "NULL")
		  .append("SCOL_RESULT_DATA", "LONGTEXT", 0, true, "NULL")
		  .append("SCOL_DEBUG_DATA", "LONGTEXT", 0, true, "NULL");
		
		for(Map<String,Object> itm : itmInf) {
			if(itm.get(Constants.ITEM_USE_TYPE).toString().equals(Constants.ITEM_USE_TYPE_FILTER) || itm.get(Constants.ITEM_USE_TYPE).toString().equals(Constants.ITEM_USE_TYPE_PERFORMANCE)) {
				int len = itm.get(Constants.ITEM_DATA_LENGTH) == null ? 0 : Integer.parseInt(itm.get(Constants.ITEM_DATA_LENGTH).toString());
				tb.append(itm.get(Constants.ITEM_ID).toString(), itm.get(Constants.ITEM_DATA_TYPE).toString(),len, true, null);
			}
		}
		
		tb.key("SCOL_DATASET_ID","SCOL_LOADING_ID","SCOL_RECORD_ID","SCOL_RANDOM_NO");
		
		return tb.build();
	}
	
	
	public DataSetStatsInfo createDataStatsInfo(Map<String, Object> parameter) {
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		//--------------------------------------------
		// 상태 전달 로직
		//--------------------------------------------		
		DataSetStatsInfo stats = new DataSetStatsInfo((status, rowCount, last, rs, itemList, code, total, err)-> {
			if((rowCount == 1  || last ) && dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null)
				if(status ) getStatus().transfer(null, rs
										    , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString()
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString()
						                    , dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString()
						                    , code
						                    , total
						                    , err);
			return rs;
		});
		
		DataSetDataLoadInfo info = new DataSetDataLoadInfo();
		info.setIgnoreFiltering(false);
		if(dataSetBscInf.containsKey(Constants.IGNORE_FILTERING)) {
			if(Constants.IGNORE.equals(dataSetBscInf.get(Constants.IGNORE_FILTERING))) {
				info.setIgnoreFiltering(true);
			}
		}
		info.setDataSetId(dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString());
		info.setDataSetLoadingTableId(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString());
		if(dataSetBscInf.containsKey(Constants.DATA_SET_BASIC_LOADING_ID))
			info.setDataLoadId(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
		if(parameter.containsKey(Constants.DATA_SET_BASIC_LOADING_COND)) {
			List<Map<String,Object>> cond =  (List<Map<String,Object>>)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND);
			info.addLoadingCondition(cond);
		}
		
		stats.setDataSetDataLoadInfo(info);
		if(parameter.containsKey(Constants.ITEM_INF))stats.setItemInf((List<Map<String,Object>>)parameter.get(Constants.ITEM_INF));
		// if(parameter.containsKey(KaisConstants.SPECIAL_VALUE_INF))stats.setSvInf((List<Map<String,Object>>)parameter.get(KaisConstants.SPECIAL_VALUE_INF));
		stats.setDataSetId(dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString());
		stats.setDataLoadId(info.getDataLoadId());
		stats.setDataSetLoadingTableId(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString());
		stats.setAnalId(dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString());
		return stats;
	}
	

}
