package com.koreacb.kais.mapper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreacb.kais.Constants;

public class KaisRuleExecutorImpl {
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmSS");

	public Map<String, Object> executeRule(Map<String, Object> inputRule, Map<String, Object> inputVariables) {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Object> exeStarategySub(Map<String, Object> inputRule, Map<String, Object> inputVariables) {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Object> exeStarategyMain(Map<String, Object> inputRule, Map<String, Object> inputVariables) {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Object> exeScoreCard(Map<String, Object> inputRule, Map<String, Object> inputVariables,int outputLevel) {
	
		Map<String,Object> map = new HashMap<>();
		map.put(Constants.KAIS_OUT_CODE, "0");
		map.put(Constants.KAIS_OUT_BASIC_MAP, new HashMap<String,Object>());
		map.put(Constants.KAIS_OUT_RESULT_MAP, new HashMap<String,Object>());
		map.put(Constants.KAIS_OUT_DEBUG_MAP, new HashMap<String,Object>());
		
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_ID, "TEST-RULE-ID-11111");
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_TYPE, "SCORECARD");
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_VER_DATE, "");
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_EXE_DATE, sdf.format(new java.util.Date(System.currentTimeMillis())));
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_EXE_USER, "LEE");
		
		((Map<String,Object>)map.get(Constants.KAIS_OUT_RESULT_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP, new HashMap<String,Object>());
		((Map<String,Object>)map.get(Constants.KAIS_OUT_RESULT_MAP)).put(Constants.KAIS_OUT_RESULT_SCORE_MAP, new HashMap<String,Object>());
		
		Map<String,Object> output = (Map<String,Object>)((Map<String,Object>)map.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP);
		Map<String,Object> score = (Map<String,Object>)((Map<String,Object>)map.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_RESULT_SCORE_MAP);
		score.put(Constants.KAIS_OUT_BASIC_SCORE_SEG_ID,"SEG-0001");
		score.put(Constants.KAIS_OUT_BASIC_SCORE_MIN,Math.round(Math.random()*100000));
		score.put(Constants.KAIS_OUT_BASIC_SCORE_MAX,Math.round(Math.random()*100000));
		score.put(Constants.KAIS_OUT_BASIC_SCORE_SUM,Math.round(Math.random()*100000));
		score.put(Constants.KAIS_OUT_BASIC_SCORE_AVG,Math.round(Math.random()*100000));
		score.put(Constants.KAIS_OUT_BASIC_SCORE_GRADE,String.format("%02d", Math.round(Math.random()*10)));
		score.put(Constants.KAIS_OUT_BASIC_SCORE_GRADE_RULE_ID,"RULE-00001");
		
		score.put(Constants.KAIS_OUT_BASIC_SCORE_POINT,new HashMap<String,Object>());
		
		((Map<String,Object>)score.get(Constants.KAIS_OUT_BASIC_SCORE_POINT)).put("0","1");
		((Map<String,Object>)score.get(Constants.KAIS_OUT_BASIC_SCORE_POINT)).put("10","1");
		((Map<String,Object>)score.get(Constants.KAIS_OUT_BASIC_SCORE_POINT)).put("25","1");
		
		score.put(Constants.KAIS_OUT_BASIC_SCORE_PLUS_REASON_MAP,new ArrayList<String>());
		
		((List<String>)score.get(Constants.KAIS_OUT_BASIC_SCORE_PLUS_REASON_MAP)).add("P01");
		((List<String>)score.get(Constants.KAIS_OUT_BASIC_SCORE_PLUS_REASON_MAP)).add("P02");
		((List<String>)score.get(Constants.KAIS_OUT_BASIC_SCORE_PLUS_REASON_MAP)).add("P03");
		
		score.put(Constants.KAIS_OUT_BASIC_SCORE_MINUS_REASON_MAP,new ArrayList<String>());
		
		((List<String>)score.get(Constants.KAIS_OUT_BASIC_SCORE_MINUS_REASON_MAP)).add("M01");
		((List<String>)score.get(Constants.KAIS_OUT_BASIC_SCORE_MINUS_REASON_MAP)).add("M02");
		((List<String>)score.get(Constants.KAIS_OUT_BASIC_SCORE_MINUS_REASON_MAP)).add("M03");
		
		score.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_MAP,new ArrayList<Map<String,Object>>());
		
		for(int i = 0; i < 5; i++){
		    Map<String,Object> bin = new HashMap<>();
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_ITEM_ID,"A000"+i);
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_ITEM_TYPE,"String");
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_ITEM_VALUE,"43255");
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_BIN_ID,"A000_000" + i);
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_BIN_POINT,"24");
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_BIN_CLASS,"Y");
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_REASON_PLUS,"P01");
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_REASON_MINUS,"M01");
		    bin.put(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_REASON_POINT,"10");
		    ((List<Map<String,Object>>)score.get(Constants.KAIS_OUT_BASIC_SCORE_TIMEBIN_MAP)).add(bin);
		}
		
		score.put(Constants.KAIS_OUT_BASIC_SCORE_CLASS_MAP,new HashMap<String,Object>());
		((Map<String,Object>)score.get(Constants.KAIS_OUT_BASIC_SCORE_CLASS_MAP)).put("XX","YY");
		
		score.put(Constants.KAIS_OUT_BASIC_SCORE_POINT_MAP,new HashMap<String,Object>());
		((Map<String,Object>)score.get(Constants.KAIS_OUT_BASIC_SCORE_POINT_MAP)).put("XX","YY");
		
		for(int i =1; i <= 10; i++) {
			if(i > 5) output.put("ITM-OUT-"+i, Math.random()*100000);
			else if(i > 7)output.put("ITM-OUT-"+i, Math.round(Math.random()*100));
			else output.put("ITM-OUT-"+i, Math.round(Math.random()*1000));
		}

		output.put(Constants.KAIS_OUT_BASIC_SCORE_SEG_ID,"SEG-0001");
		output.put(Constants.KAIS_OUT_BASIC_SCORE_MIN,Math.round(Math.random()*100000));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_MAX,Math.round(Math.random()*100000));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_SUM,Math.round(Math.random()*100000));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_AVG,Math.round(Math.random()*100000));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_GRADE,String.format("%02d", Math.round(Math.random()*10)));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_GRADE_RULE_ID,"RULE-00001");
		
		return map;
	}

	public Map<String, Object> exeStarategyMain(Map<String, Object> inputRule, Map<String, Object> inputVariables,
			int outputLevel) {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Object> exeStarategySub(Map<String, Object> inputRule, Map<String, Object> inputVariables,
			int outputLevel) {
		// TODO Auto-generated method stub
		return null;
	}

	public Map<String, Object> executeRule(Map<String, Object> inputRule, Map<String, Object> inputVariables,
			int outputLevel) {
		// TODO Auto-generated method stub
		
		Map<String,Object> map = new HashMap<>();
		map.put(Constants.KAIS_OUT_CODE, 0);
		map.put(Constants.KAIS_OUT_BASIC_MAP, new HashMap<String,Object>());
		map.put(Constants.KAIS_OUT_RESULT_MAP, new HashMap<String,Object>());
		map.put(Constants.KAIS_OUT_DEBUG_MAP, new HashMap<String,Object>());
		
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_ID, "TEST-RULE-ID-11111");
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_TYPE, "");
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_VER_DATE, "");
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_EXE_DATE, "");
		((Map<String,Object>)map.get(Constants.KAIS_OUT_BASIC_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_EXE_USER, "");
		
		((Map<String,Object>)map.get(Constants.KAIS_OUT_RESULT_MAP)).put(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP, new HashMap<String,Object>());
		((Map<String,Object>)map.get(Constants.KAIS_OUT_RESULT_MAP)).put(Constants.KAIS_OUT_RESULT_SCORE_MAP, new HashMap<String,Object>());
		
		Map<String,Object> output = (Map<String,Object>)((Map<String,Object>)map.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP);
		output.put(Constants.KAIS_OUT_BASIC_SCORE_SEG_ID,"");
		output.put(Constants.KAIS_OUT_BASIC_SCORE_MIN,Math.round(Math.random()*100000));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_MAX,Math.round(Math.random()*100000));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_SUM,Math.round(Math.random()*100000));
		output.put(Constants.KAIS_OUT_BASIC_SCORE_AVG,Math.round(Math.random()*100000));
		
		for(int i =1; i <= 10; i++) {
			if(i > 5) output.put("ITM-OUT-"+i, Math.random()*100000);
			else if(i > 7)output.put("ITM-OUT-"+i, Math.round(Math.random()*100));
			else output.put("ITM-OUT-"+i, Math.round(Math.random()*1000));
		}

		return map;
	}

}
