package com.koreacb.kais.rule.server.exec;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreacb.kais.Constants;
import com.koreacb.kais.ExecutorInLoading;
import com.koreacb.kais.mybatis.MultiMyBatisUtils;
import com.koreacb.kais.mybatis.MyBatisUtils;
import com.koreacb.kais.rule.KaisRuleExecutor;
import com.koreacb.kais.rule.core.KaisRuleExecutorImpl;
import com.koreacb.kais.status.LoadingAndStatsStatusManager;

public class RuleInfoReceiver extends ExecutorInLoading{
	
	/*
	 * ------------------------------------------------------
	 *  룰 디버그 요청 
	 * ------------------------------------------------------
	 * Debug할경우, 데이터 셋의 로딩 테이블에 대한 키 조건을 다시 입력 받아서, 조회후, 룰을 실행하도록 해야 함.
	 */
	
	public Map<String,Object> debugRule(Map<String,Object> parameter){
		
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		List<Map<String,Object>> itmInf = (List<Map<String,Object>>)parameter.get(Constants.ITEM_INF);
		Map<String,Object> ruleInf = (Map<String,Object>)parameter.get(Constants.RULE_DATA);
				
		String dataSetId = dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString();
		String loadingId = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString();
		String recordId = dataSetBscInf.get(Constants.DATA_SET_BASIC_RECORD_ID).toString();
		String loadingTable = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString();
		Map<String,Object> map = new HashMap<>();
		map.put("DSET_ID", dataSetId);
		map.put("LOADING_ID", loadingId);
		map.put("RECORD_ID", recordId);
		map.put("DSET_TABLE", loadingTable);
		
		MultiMyBatisUtils utils = new MultiMyBatisUtils(false);
		try {
			ObjectMapper mapper = new ObjectMapper();
			List<Map<String,Object>> result = utils.select("selectDsetDATAByPrimaryKey", map);
			if(result != null && result.size() == 0) {
				Map<String,Object> jsonMap = mapper.readValue(result.get(0).get("SCOL_LOADING_DATA").toString(), new HashMap<String,Object>().getClass());
				result.get(0).remove("SCOL_LOADING_DATA");
				jsonMap.putAll(result.get(0));
				KaisRuleExecutor executor = new KaisRuleExecutorImpl();
				Map<String,Object> ruleResult = executor.executeRule(ruleInf, jsonMap ,KaisRuleExecutor.OPT_ONLY_EXE_DBG_RTN_OUT,true);
				return ruleResult;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

	/*
	 * ------------------------------------------------------
	 *  룰 실행 결과 요청 --> 결과 정보 를 요청하는 기능 제외 됨. 
	 * ------------------------------------------------------
	 */
	public List<Map<String,Object>> requestRuleResult(Map<String,Object> parameter) throws Exception{
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		MultiMyBatisUtils utils = new MultiMyBatisUtils(false);
		return utils.select("selectRuleResultDATA", dataSetBscInf);
	}
	/*
	 * ------------------------------------------------------
	 *  룰 테스트 요청 
	 * ------------------------------------------------------
	 */
	public Map<String,Object> requestRuleTest(Map<String,Object> parameter) throws Exception{
		return this.requestEngine(parameter);
	}
	
	public Map<String,Object> requestRuleTestLegacy(Map<String,Object> parameter) throws Exception{
		
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		// 실행할 룰 정보
		Map<String,Object> ruleInf = (Map<String,Object>)parameter.get(Constants.RULE_DATA);
		String loadingId = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString() : "";
		String dataSetId = dataSetBscInf.get(Constants.DATA_SET_BASIC_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString() : "";
		String dataLoadingTableId = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString() : "";
		try {
			this.ready(dataLoadingTableId, dataSetId, loadingId);
			RuleResultStore store = new RuleResultStore();
			KaisRuleExecutor executor = new KaisRuleExecutorImpl();

			this.loadDataSetForRuleExecuting(false, false, parameter, (p,rs)->{
				com.koreacb.kais.GlobalLogger.log(this,"Rule Test Data ["+rs+"]");
				Map<String,Object> ruleResult = executor.executeRule(ruleInf, rs ,KaisRuleExecutor.OPT_ONLY_EXE_DBG_RTN_OUT,true);
				ruleResult = store.saveRuleResultInTable(dataSetId, loadingId, dataLoadingTableId, rs, ruleResult, parameter);
				return ruleResult;
			});
			
			proceedAnalysisAfterTestRule(false, parameter, dataSetBscInf);
			
		}catch(Exception e) {
			this.error(dataSetId, loadingId , 0 ,0);
			e.printStackTrace();
		}
		return null;
	}

	
	// 룰 실행후, 진행할 분석 기능
	public boolean proceedAnalysisAfterTestRule(boolean status, Map<String, Object> parameter, Map<String, Object> dataSetBscInf)
			throws Exception {
		// 룰을 실행한 결과를 저장한 테이블에서 한 건을 읽은 후, 분석 항목을 추출하기 위함. 
		// 룰 실행 결과 정보가 저장된 DATA 소스(stage D/B)로 연결을 한다.
		List<Map<String,Object>> oneRecord = new MyBatisUtils("resultDataSource",false).select("selectResultTable", dataSetBscInf);
		// 룰 실행 결과가 없는 경우에는 분석을 할 필요가 없음.
		if(oneRecord == null || oneRecord.size() == 0) return false;
		
		// 룰 실행 결과를 분석할 항목을 파라미터에 저장 한다.
		List<Map<String,Object>> itemInf = this.createAnalysisItemInf(oneRecord.get(0));
		com.koreacb.kais.GlobalLogger.log(this,"Stats Item Info = ["+itemInf+"]");
		parameter.put(Constants.ANALYSIS_ITEM_DATA, itemInf);

		// 룰 실행 결과 테이블을 분석해야 하므로, 테이블 정보를 RULE_RESULT로 변경 해준다.
		// RULE_RESULT 테이블은 데이터 로딩 테이블과 구조가 비슷하다. (SCOL_RESULT_DATA, SCOL_ERR_YN 칼럼만 추가됨)
		// RULE_RESULT 테이블에서 SCOL_LOADING_DATA 칼럼에 룰의 실행 결과가 저장되고, SCOL_ORIGINA_DATA에 데이터 로딩한 정보가 저장된다.
		dataSetBscInf.put(Constants.IGNORE_FILTERING, Constants.IGNORE);
		dataSetBscInf.put(Constants.DATA_SET_BASIC_LOADING_TABLE_ID, "RULE_RESULT");
		/**
		 * 
		 * TO DO LIST
		 * 아래 조건이 추가 되어야 함. 
		 * 
		
		parameter.put(Constants.DATA_SET_BASIC_LOADING_COND, new ArrayList<>());
		((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).add(new HashMap<String,Object>());
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(0)).put(Constants.DATA_SET_BASIC_LOADING_COND_OR_GROUP, "1");
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(0)).put(Constants.DATA_SET_BASIC_LOADING_COND_ITEM_ID, "SCOL_DATASET_ID");
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(0)).put(Constants.DATA_SET_BASIC_LOADING_COND_IN_VALUE, dataSetId);
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(0)).put(Constants.DATA_SET_BASIC_LOADING_COND_OPERAND, Constants.EQ0);
		((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).add(new HashMap<String,Object>());
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(1)).put(Constants.DATA_SET_BASIC_LOADING_COND_OR_GROUP, "2");
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(1)).put(Constants.DATA_SET_BASIC_LOADING_COND_ITEM_ID, "SCOL_LOADING_ID");
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(1)).put(Constants.DATA_SET_BASIC_LOADING_COND_IN_VALUE, loadingId);
		((Map<String,Object>)((List)parameter.get(Constants.DATA_SET_BASIC_LOADING_COND)).get(1)).put(Constants.DATA_SET_BASIC_LOADING_COND_OPERAND, Constants.EQ0);
		 */
		
		// 룰 실행 결과 데이터 셋을 로딩하여, 해당 항목들을 분석해야 함. 
		// SCOL_LOADING_DATA 칼럼에 JSON 중, 분석항목 (ANALYSIS_ITEM_DATA)에 있는 칼럼을 분석하게 된다.
		return this.proceedAnalysis(false, false, status, "resultDataSource", parameter);
	}
	
	// 룰 실행 결과 변수들을 분석 대상 항목으로 생성해 주는 기능
	// 룰 실행 결과 테이블에서, RESULT_OUTPUT 칼럼에 있는 데이터를 통계 컬럼으로 지정한다. 
	public List<Map<String,Object>> createAnalysisItemInf(Map<String,Object> output){
		List<Map<String,Object>> itmInf = new ArrayList<>();
		ObjectMapper mapper = new ObjectMapper();
		output.forEach((k,v) ->{
			try{
				if(v != null) {
					Map<String,Object> json = mapper.readValue((String)v, new HashMap<String,Object>().getClass());
					if(
					   json.containsKey(Constants.KAIS_OUT_RESULT_MAP)
					&& json.get(Constants.KAIS_OUT_RESULT_MAP) != null
					&& ((Map<String,Object>)json.get(Constants.KAIS_OUT_RESULT_MAP)).containsKey(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP)
					&& ((Map<String,Object>)json.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP) != null
					) {
						Map<String,Object> ruleResultMap = (Map<String,Object>)(((Map<String,Object>)json.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP));
						if(ruleResultMap != null && ruleResultMap.size() > 0) {
							ruleResultMap.forEach((key,val) -> {
								Map<String,Object> m = new HashMap<>();
								m.put(Constants.ANL_ITM_ID, key);
								itmInf.add(m);
							});
						}
					}
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		});
		return itmInf;
	}
	
	/*
	 * ------------------------------------------------------
	 *  룰 테스트 결과 통계 요청
	 *  " 아래 기능은 사용하지 않게 됨. " 
	 * ------------------------------------------------------
	 */
	public Map<String,Object> requestRuleResultStats(Map<String,Object> parameter) throws Exception{
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		List<Map<String,Object>> itmInf = (List<Map<String,Object>>)parameter.get(Constants.ITEM_INF);
		// dataSetBscInf.put(Constants.RULE_RESULT_TABLE, Constants.RULE_RESULT_TABLE_PREFIX + dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID));
		
		String ddl = null;
		if(this.checkRuleResultInfo(dataSetBscInf)) {
			this.executeTruncateRuleResultSQL(this.getUtils(),dataSetBscInf);
		}else {
			this.executeDROPRuleResultSQL(this.getUtils(),dataSetBscInf);
			ddl = this.executeCreateRuleResultDDL(dataSetBscInf, itmInf, this.getUtils(), ddl);
		}
		
		KaisRuleExecutor executor = new KaisRuleExecutorImpl();
		
		this.loadDataSetForRuleExecuting(false, true, parameter, (p,rs)->{
			Map<String,Object> ruleResult = executor.executeRule(p, rs,KaisRuleExecutor.OPT_ONLY_EXE_DBG_RTN_OUT,false);
			return ruleResult;
		});
		return null;
	}	

	public Map<String,Object> requestEngine(Map<String,Object> parameter){
		com.koreacb.kais.GlobalLogger.log(this,"######## " + parameter);
		Map<String,Object> dataSetBscInf = (Map<String,Object>)parameter.get(Constants.DATA_SET_BASIC_INF);
		com.koreacb.kais.GlobalLogger.log(this,"######## " + "LOADING DATA :  " + dataSetBscInf);
		/*
		 * 2018.08.01 아래 내용 변경/삭제됨.
		// 시뮬레이션 관련 정보를 읽어 온다.
		Map<String,Object> simBasicInf = (Map<String,Object>)parameter.get(Constants.SIM_BASIC_INFO);
		com.koreacb.kais.GlobalLogger.log(this,"######## " + "BASIC INFO :  " + simBasicInf);
		// 시뮬레이션 정보의 데이터를 읽어 온다.
		Map<String,Object> simBasicData = (Map<String,Object>)simBasicInf.get(Constants.SIM_BASIC_DATA);
		com.koreacb.kais.GlobalLogger.log(this,"######## " + "BASIC DATA :  " + simBasicData);
		// 시뮬레이션 데이터의 룰 아이디를 읽어 온다.
		String ruleId = (String)simBasicData.get(Constants.SIM_RULE_ID);
		com.koreacb.kais.GlobalLogger.log(this,"######## " + "RULE ID :  " + ruleId);
		*/
		
		Map<String,Object> ruleInf = (Map<String,Object>)parameter.get(Constants.RULE_DATA);
		
		String loadingId = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_ID).toString() : "";
		String dataSetId = dataSetBscInf.get(Constants.DATA_SET_BASIC_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_ID).toString() : "";
		String dataLoadingTableId = dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID) != null ? dataSetBscInf.get(Constants.DATA_SET_BASIC_LOADING_TABLE_ID).toString() : "";
		
		com.koreacb.kais.GlobalLogger.log(this,"######## " + "LOADING ID :  " + loadingId);
		com.koreacb.kais.GlobalLogger.log(this,"######## " + "DATASET ID :  " + dataSetId);
		com.koreacb.kais.GlobalLogger.log(this,"######## " + "TABLE ID :  " + dataLoadingTableId);
		try {
			this.ready(dataLoadingTableId, dataSetId, loadingId);
			com.koreacb.kais.GlobalLogger.log(this,"######## " + "LOADING ready");
			
			RuleResultStore store = new RuleResultStore();
			KaisRuleExecutor executor = new KaisRuleExecutorImpl();

			// 먼저 Blank Map을 룰엔진에 전송해서, Rule ID를 생성하도록 한다.
			Map<String,Object> preResult = executor.executeRule(ruleInf, new HashMap<String,Object>(), KaisRuleExecutor.OPT_ONLY_EXE,true);
			
			// KOUT_CODE를 확인해서 0이 아니면, 에러후 리턴
			if(!preResult.containsKey(Constants.KAIS_OUT_CODE)
			|| preResult.get(Constants.KAIS_OUT_CODE) == null) {
				this.error(dataSetId, loadingId, 0, 0);
				return null;
			}
			
			// KOUT_CODE를 확인해서 0이 아니면, 에러후 리턴
			if(!preResult.get(Constants.KAIS_OUT_CODE).toString().equals("0")) {
				this.error(dataSetId, loadingId, 0, 0);
				return null;
			}
			
			// 룰 타입을 결정
			String ruleType = ((Map<String,Object>)ruleInf.get(Constants.SIM_BASIC_DATA)).get(Constants.EXE_RULE_TYPE).toString();
			// 룰 아이디 결정
			String ruleId = ((Map<String,Object>)ruleInf.get(Constants.SIM_BASIC_DATA)).get(Constants.SIM_RULE_ID).toString();
			
			com.koreacb.kais.GlobalLogger.log(this,"######## " + "LOADING and EXECUTING.....");
			this.loadDataSetForRuleExecuting(false, false, parameter, (p,original)->{
				
				// 룰엔진에서 사용할 멥을 복사하여 전달 한다.
				// 룰엔진 안에서 값을 바꿀수 있으므로...
				Map<String,Object> rs = (Map<String,Object>)((HashMap<String,Object>)original).clone();
				// com.koreacb.kais.GlobalLogger.log(this,"Rule Test Data ["+rs+"]");
				Map<String,Object> ruleResult = null;
				
				// 앞에서, 데이터를 읽어서, SIMUL_DATA 라는 칼럼에 넣어 준다.
				// 아래에서 그 정보를 사용한다.
				if(rs.containsKey(Constants.SIM_DATASET_INF) && rs.get(Constants.SIM_DATASET_INF) != null) {
					
					// Map<String,Object> inputParam = (Map<String,Object>)rs.get(Constants.SIM_DATASET_INF);
					// SIMUL_DATA -> LOADING_DATA
					Map<String,Object> inputParam = new HashMap<>();
					
					rs.forEach((k,v)->{
						if(!"SCOL_ORIGNAL_DATA".equals(k)
						&& !"SCOL_LOADING_DATA".equals(k)
						&& !(rs.get(k) instanceof Map) 
						&& !(rs.get(k) instanceof List)) inputParam.put(k, v);
					});
					
					if(rs.containsKey(Constants.SIM_DATASET_INF) 
					&& rs.get(Constants.SIM_DATASET_INF) != null
					&& rs.get(Constants.SIM_DATASET_INF) instanceof Map) {
						((Map<String,Object>)rs.get(Constants.SIM_DATASET_INF)).forEach((k,v)->{
							if(!"SCOL_ORIGNAL_DATA".equals(k)
							&& !"SCOL_LOADING_DATA".equals(k)
							&& !(((Map<String,Object>)rs.get(Constants.SIM_DATASET_INF)).get(k) instanceof Map) 
							&& !(((Map<String,Object>)rs.get(Constants.SIM_DATASET_INF)).get(k) instanceof List)) {
								inputParam.put(k, v);
							}
						});
					}
					
					// 입력값을 나중에 저장하기 위함.
					try{
						rs.put("SCOL_LOADING_DATA", new JSONObject(inputParam).toString()); 
					}catch(Exception e) {
						e.printStackTrace();
					}
					
					if(Constants.EXE_RULE_TYPE_MS.equals(ruleType)) {
						ruleResult = executor.exeStrategyMain(ruleId, inputParam);
					}else if(Constants.EXE_RULE_TYPE_SS.equals(ruleType)) {
						ruleResult = executor.exeStrategySub(ruleId, inputParam);
					}else if(Constants.EXE_RULE_TYPE_SC.equals(ruleType)) {
						ruleResult = executor.exeScoreCard(ruleId, inputParam);
					}else {
						ruleResult = executor.executeRule(ruleId, inputParam);
					}
					// SIMUL_DATA -> LOADING_DATA
					// rs.put("SCOL_LOADING_DATA", inputParam);
					ruleResult = store.saveRuleResultInTable(dataSetId, loadingId, dataLoadingTableId, rs, ruleResult, parameter);
				}
				return ruleResult;
				
			});
			
			// 시뮬레이션이 완료된 경우에 분석을 시작함.
			if(!LoadingAndStatsStatusManager.getInstance().isLoadingAndStatsComplete(dataSetId,loadingId)) {
				com.koreacb.kais.GlobalLogger.log(this,">>>>>> Error Simulation or Rule does not completed.....");
			 	return null;
			}
			
			// 산출결과의 결과 코드가 0인 것만 추출 해서, 통계를 만들어야 함.
			// 룰을 실행한 결과가 정상이 아니면, SCOL_ERR_YN을 Y로 세팅 하므로, 통계시 제외 된다.
			proceedAnalysisAfterTestRule(false, parameter, dataSetBscInf);
			
		}catch(Exception e) {
			this.error(dataSetId, loadingId , 0 ,0);
			e.printStackTrace();
		}
		return null;
	}
	
}
