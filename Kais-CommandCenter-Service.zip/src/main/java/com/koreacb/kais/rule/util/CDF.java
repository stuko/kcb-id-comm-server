package com.koreacb.kais.rule.util;

import java.util.*;
import java.text.*;
import java.sql.Timestamp;
import java.util.regex.*;
import java.math.*;

public class CDF {
	 private Locale DATE_LOCALE = Locale.KOREA;
	 private String DATE_FORMAT = "yyyyMMdd";
	 private String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
	 private String DATETIMES_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

	 public boolean IN(Object val, Object... args) {
		 try {
			 if (val==null) { return false; } 
			 else if (args.length < 1) { return false;} 
			 else {
				 for (int ii=0 ; ii < args.length ; ii++) {
					 if (args[ii] != null) {
						 if (val.equals(args[ii])) {return true;}
						 else if ((val instanceof Number) && (args[ii] instanceof Number) && ((Number)val).doubleValue() == ((Number)args[ii]).doubleValue()) {
							 return true;
						 } else if (val.toString().equals(args[ii].toString())) {
							 return true;
						 }
					 }
				 }
			 }
			 return false;
		 } catch (Exception e) {return false;}
	 }
	 
	 public boolean IN(Object val, String vals, String dlm) {
		 try {
			 String valary[] =  vals.split(dlm);
			 
			 if (val==null) { return false; } 
			 else  if (valary.length < 1) { return false;} 
			 else {
				 String tval = val.toString().trim();
				 for (int ii=0 ; ii < valary.length ; ii++) {
					 if (tval.equals(valary[ii].trim())) {return true;} 
				 }
				 return false;
			 }
		 } catch (Exception e) {return false;}
	 }
	 
	 public boolean IN(Object val, String vals) { return IN(val,vals,",");} 
	 
	 public boolean IS_NUMBER(Object val) {
		 try {
			if (val==null){
				return false; 
			}  else if (val instanceof Number) {
				return true;
			} else if(val instanceof String){
				Double.parseDouble((String)val);
				return true;
			}	else {return false;}
		 } catch (Exception e) {return false;}
	 }
	 
	 public double TO_NUMBER(Object val) {
		 try {
			 double result=0.0;
			 if (val instanceof Number) {
				 result = ((Number)val).doubleValue();
			 } else if(val instanceof String){
				 result = Double.parseDouble((String)val);
			 } 
			 return result;
		 } catch (Exception e) {return 0;}
	 }
	 
	 private Double[] TO_NUMBERS(Object... args) {
		 try {
			 List<Double> tmp = new ArrayList<Double>();

			 for (int ii=0 ; ii < args.length ; ii++) { 
				 if (args[ii] instanceof Number) {
					 tmp.add( ((Number)args[ii]).doubleValue() );
				 } else if(args[ii] instanceof String){
					 try {
						 tmp.add( Double.parseDouble((String)args[ii]) );
				 	 } catch (Exception e) {}
				 }
			 }
			 Double[] result = tmp.toArray( new Double[ tmp.size() ] );

			 return result;
		 } catch (Exception e) {return null;}
	 }
	 
	 public Object MAX(Object... args) {
		 Object result=null;
		 try {
			 Arrays.sort(args);
			 result = args[args.length-1];
			 return result;
		 } catch (Exception e) {
			 Double tmp[] = TO_NUMBERS(args);
			 if (tmp.length == args.length) {
				 Arrays.sort(tmp);
				 result = tmp[tmp.length-1];
			 } else {
				 String[] tmps = TO_CHARS(args);
				 Arrays.sort(tmps);
				 result = tmps[tmps.length-1];
			 }
			 return result;
		 }
	 }

	 public Object MIN(Object... args) {
		 Object result=null;
		 try {
			 Arrays.sort(args);
			 result = args[0];
			 return result;
		 } catch (Exception e) {
			 Double tmp[] = TO_NUMBERS(args);
			 if (tmp.length == args.length) {
				 Arrays.sort(tmp);
				 result = tmp[0];
			 } else {
				 String[] tmps = TO_CHARS(args);
				 Arrays.sort(tmps);
				 result = tmps[0];
			 }
			 return result;
		 }
	 }

	 public double SUM(Object... args) {
		 double sumVal=0;
		 try {
			 if (args.length > 1) {
				 for (int ii=0 ; ii < args.length ; ii++) {
					 if (args[ii] instanceof Number) {
						 sumVal += ((Number)args[ii]).doubleValue();
					 } else if(args[ii] instanceof String){
						 sumVal += TO_NUMBER((String) args[ii]);
					 }
				 }
			 } else {return sumVal=0;}
		 } catch (Exception e) {sumVal = 0;}
		 return sumVal;
	 }

	 public double AVG(Object... args) {
		 try {
			 if (args.length > 1) {
				 double sumVal=0;
				 int    cntVal=0;
				 
				 for (int ii=0 ; ii < args.length ; ii++) {
					 if (args[ii] == null) {} 
					 else if (args[ii] instanceof Number) {
						 sumVal += ((Number)args[ii]).doubleValue();
						 cntVal++;
					 } else if(args[ii] instanceof String){
						 if (IS_NUMBER((String) args[ii])) { 
							 cntVal++; 
							 sumVal += TO_NUMBER((String) args[ii]);
						 }
					 }
				 }			 
				 return (cntVal > 0 ? sumVal/cntVal : 0);
			 } else {return 0;}
		 } catch (Exception e) {return 0;}
	 }
	 
	 public double VARIANCE(Object... args) {
		 try {
			 if (args.length > 1) {
				 double Val = 0;
				 double ssumVal = 0;
				 int    cntVal=0;
				 double mean = AVG(args);
				 
				 for (int ii=0 ; ii < args.length ; ii++) {
					 if (args[ii] == null) {} 
					 else if (args[ii] instanceof Number) {
						 Val = ((Number)args[ii]).doubleValue();
						 ssumVal += (Val - mean) * (Val - mean);
						 cntVal++;

					 } else if(args[ii] instanceof String){
						 if (IS_NUMBER((String) args[ii])) { 
							 Val = TO_NUMBER((String) args[ii]);
							 ssumVal += (Val - mean) * (Val - mean);
							 cntVal++;
						 }
					 }
				 }
				 return (cntVal > 0 ? ssumVal / cntVal : 0);
			 } else {return 0;}
		 } catch (Exception e) {return 0;}
	 }

	 public double STDDEV(Object... args) {
		 try {
			 	 return Math.sqrt(VARIANCE(args));
		 } catch (Exception e) {return 0;}
	 }

	 public Date GETDATE() {
	     try {
	    	 GregorianCalendar clr = new GregorianCalendar();
	    	 return clr.getTime();
	     } catch (Exception e) { return null; }
	 }

	 public String SYSDATE(Object... args) {
	     try {
	    	 Date dVal 		= GETDATE();
	    	 
	    	 if (args.length <= 0) 		{ return TO_CHAR(dVal, DATE_FORMAT		, DATE_LOCALE); }
	    	 else if (args.length <= 1) { return TO_CHAR(dVal, args[0]			, DATE_LOCALE); }
	    	 else 						{ return TO_CHAR(dVal, args[0]			, args[1]); 	}
	     } catch (Exception e) { return null; }
	 }

	 public boolean IS_DATE(Object... args) {
	     try {
	    	 String dValue  = null;
	    	 int    dLength = 0;
	    	 String dFormat = null;
	    	 Locale dLocale = DATE_LOCALE;
	    	 Date date = null;
	    	 
	    	 if (args.length < 1) 												{ return false; }
	    	 else if (args[0] == null) 											{ return false; }  
	    	 else if (args[0] instanceof Date || args[0] instanceof Timestamp) 	{ return true;  }
	    	 else {	 
	    		 dValue = ((Object)args[0]).toString();
	    		 dLength = dValue.length();

	    		 if (args.length == 1) 		{ dFormat = ""; }
		    	 else if (args[1]==null) 	{ dFormat = ""; }
	    	 	 else { dFormat = ((Object)args[1]).toString(); }

	    		 if (dFormat.equals("")) {
		    		 if (dLength <=  DATE_FORMAT.length()) {
		    			 dFormat = DATE_FORMAT.substring(0, dLength);
		    		 } else {
		    			 dFormat = DATETIMES_FORMAT.substring(0,dLength);
		    		 }
		    	 }
		    		 
		    	 if(args.length > 2) {
		    		 if (args[2] != null) {
		    			 if (args[2] instanceof Locale) {
		    				 dLocale = (Locale)args[2]; 
		    			 } 
		    			 else if (!((Object)args[2]).toString().equals("")) {
		    				 dLocale = new Locale( ((Object)args[2]).toString() );
		    			 }
		    		 }
		    	 }
		    	
    			 SimpleDateFormat formatter = new SimpleDateFormat(dFormat, dLocale);
    			 date = formatter.parse(dValue);
    			 if (formatter.format(date).equals(dValue)) { return true; } else {return false; }	    		 
	    	 }
	     } catch (Exception e) { return false; }
	 }
	 
	 public String GET_DATEFORMAT(Object args) {
	     try {
	    	 if (args == null) 												{ return null; 					}
	    	 else if (args instanceof Date || args instanceof Timestamp) 	{ return DATETIMES_FORMAT;  	}
	    	 else {
	    		 String dValue = ((Object)args).toString(), dFormat=null;
	    		 int dLength = dValue.length();
	    		 
	    		 if 	 (dLength <= 0) 					{ dFormat = null;									}
	    		 else if (dLength <=  DATE_FORMAT.length()) { dFormat = DATE_FORMAT.substring(0, dLength); 		}
	    		 else 										{ dFormat = DATETIMES_FORMAT.substring(0,dLength); 	}

	    		 if (IS_DATE(dValue, dFormat)) { return dFormat;} else { return null;}
	    	 }
	     } catch (Exception e) { return null; }
	 }	 

	 public Date TO_DATE(Object... args) {
	     try {
	    	 String dValue  = null;
	    	 int    dLength = 0;
	    	 String dFormat = null;
	    	 Locale dLocale = DATE_LOCALE;
	    	 Date   date    = null;
	    	 
	    	 if (args.length < 1) 					{ return GETDATE(); }
	    	 else if (args[0] == null) 				{ return GETDATE(); }  
	    	 else if (args[0] instanceof Date) 		{ return (Date)args[0]; } 
	    	 else if (args[0] instanceof Timestamp)	{ return new Date(((Timestamp)args[0]).getTime()); }
	    	 else {
	    		 dValue = ((Object)args[0]).toString();
	    		 dLength = dValue.length();

	    		 if (args.length == 1) 		{ dFormat = ""; }
		    	 else if (args[1]==null) 	{ dFormat = ""; }
	    	 	 else { dFormat = ((Object)args[1]).toString(); }

	    		 if (dFormat.equals("")) {
		    		 if (dLength <=  DATE_FORMAT.length()) {
		    			 dFormat = DATE_FORMAT.substring(0, dLength);
		    		 } else {
		    			 dFormat = DATETIMES_FORMAT.substring(0,dLength);
		    		 }
		    	 }
		    		 
		    	 if(args.length > 2) {
		    		 if (args[2] != null) {
		    			 if (args[2] instanceof Locale) {
		    				 dLocale = (Locale)args[2]; 
		    			 } 
		    			 else if (!((Object)args[2]).toString().equals("")) {
		    				 dLocale = new Locale( ((Object)args[2]).toString() );
		    			 }
		    		 }
		    	 }
		    	
    			 SimpleDateFormat formatter = new SimpleDateFormat(dFormat, dLocale);
    			 date = formatter.parse(dValue);    			 
    			 if (formatter.format(date).equals(dValue)) {return date;} else {return null;}
	    	 }
	 	 } catch (Exception e) { return null; }
	 }

	 public Timestamp TO_TIMESTAMP(Object... args) {
		 try {
			 return new Timestamp(TO_DATE(args).getTime());
		 } catch (Exception e) { return null; }
	 }

	 public String TO_STR(Object... args) {
		String rVal = TO_CHAR(args);
		 
		return (rVal== null ? "" : rVal);
	 }
	 
	 public String TO_CHAR(Object... args) {
		 try {
	    	 if (args.length < 1) 					{ return null; }
	    	 else if (args[0] == null) 				{ return null; }  
	    	 else if (args[0] instanceof String) 	{ return (String)args[0]; } 
	    	 else if (args[0] instanceof Date || args[0] instanceof Timestamp) 	{
		    	 try {
		    		 String dFormat = "";
		    		 Locale dLocale = null;
		    		 Date   dDate   = TO_DATE(args[0]);
		    		 
		    		 if (args.length < 2) 								{ dFormat = DATE_FORMAT; }
			    	 else if (args[1]==null) 							{ dFormat = DATE_FORMAT; }
			    	 else if (((Object)args[1]).toString().equals("")) 	{ dFormat = DATE_FORMAT; }
		    	 	 else 												{ dFormat = ((Object)args[1]).toString(); }
		    		 
			    	 if(args.length < 3) 								{ dLocale = DATE_LOCALE; }
			    	 else if (args[2] != null) 							{ dLocale = DATE_LOCALE; }
			    	 else if (((Object)args[2]).toString().equals("")) 	{ dLocale = DATE_LOCALE; }
			    	 else if (args[2] instanceof Locale) 				{ dLocale = (Locale)args[2]; }
		    	 	 else 												{ dLocale = new Locale( ((Object)args[2]).toString() ); }
		    	 
		    		 SimpleDateFormat formatter = new SimpleDateFormat(dFormat, dLocale);
		    		 return formatter.format(dDate);
		    	 } catch (Exception e) { return null; } 
	    	 } 
	    	 else if (args[0] instanceof BigDecimal) {
	    		 if (args.length == 1) {
	    			 return ((BigDecimal)args[0]).stripTrailingZeros().toPlainString();
	    		 } else {
			    	 if (args[1]==null) 								{ return ((BigDecimal)args[0]).stripTrailingZeros().toPlainString(); }
			    	 else if (((Object)args[1]).toString().equals("")) 	{ return ((BigDecimal)args[0]).stripTrailingZeros().toPlainString(); }
			    	 else {
						 try {
				    		 String nformat = (String)args[1];
				    		 DecimalFormat fmt = new DecimalFormat(nformat);
					    	return fmt.format((BigDecimal)args[0]);
						 } catch (Exception e) { return ((BigDecimal)args[0]).toString(); }			    		 
			    	 }
	    		 }
	    	 }
	    	 else if (args[0] instanceof Integer || args[0] instanceof Long) {
    			 long val = Long.parseLong(args[0].toString());
	    		 if (args.length == 1) {
	    			 return BigDecimal.valueOf(val).stripTrailingZeros().toPlainString();
	    		 } else {
			    	 if (args[1]==null) 								{ return BigDecimal.valueOf(val).toPlainString(); }
			    	 else if (((Object)args[1]).toString().equals("")) 	{ return BigDecimal.valueOf(val).toPlainString(); }
			    	 else {
						 try {
				    		 String nformat = (String)args[1];
				    		 DecimalFormat fmt = new DecimalFormat(nformat);
					    	return fmt.format((Long)args[0]);
						 } catch (Exception e) { return ((Object)args[0]).toString(); }			    		 
			    	 }
	    		 }
	    	 }
	    	 else if (args[0] instanceof Number) {
	    		 if (args.length == 1) {
	    			 double val = (Double)args[0];

	    			 return BigDecimal.valueOf(val).stripTrailingZeros().toPlainString();
	    		 } else {
			    	 if (args[1]==null) 								{ return BigDecimal.valueOf((Double)args[0]).toPlainString(); }
			    	 else if (((Object)args[1]).toString().equals("")) 	{ return BigDecimal.valueOf((Double)args[0]).toPlainString(); }
			    	 else {
						 try {
				    		 String nformat = (String)args[1];
				    		 DecimalFormat fmt = new DecimalFormat(nformat);
					    	return fmt.format((Double)args[0]);
						 } catch (Exception e) { return ((Object)args[0]).toString(); }			    		 
			    	 }
	    		 }
	    	 } else {return ((Object)args[0]).toString();}
		 } catch (Exception e) { return null; }
	 }
	 
	 
	 private String[] TO_CHARS(Object... args) {
		 try {
			 List<String> tmp = new ArrayList<String>();
			 
			 for (int ii=0 ; ii < args.length ; ii++) {
					 tmp.add( TO_CHAR(args[ii]) );
			 }
			 String[] result = tmp.toArray( new String[ tmp.size() ] );
			 return result;
		 } catch (Exception e) { return null; }
	 }

	 public Double DIFF_MILLISECONDS(Date fromDate, Date... toDate) {
		 try {
			 if      (fromDate==null) 		{ return 0.0; }
			 else if (toDate.length <= 0) 	{ return (double)( Math.abs(fromDate.getTime() - GETDATE().getTime()) );}
			 else if (toDate[0]==null) 		{ return 0.0; }
			 else 							{ return (double)( Math.abs(fromDate.getTime() - toDate[0].getTime()) );}
		 } catch (Exception e) { return 0.0; }
	 }
	 public Double DIFF_SECONDS(Object... args) {
		 try {
			 if 	(args.length <= 0) { return 0.0; }
			 else if (args[0] == null) { return 0.0; }
			 else {
				 Date sDate = null;	Date eDate = null; double divVal = 1000.0;
				 
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length >= 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length >= 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}

				 return ((sDate == null || eDate == null)? 0.0 : DIFF_MILLISECONDS(sDate, eDate) / divVal );
			 }
		 } catch (Exception e) { return 0.0; }
	 }

	 public Double DIFF_MINUTES(Object... args) {
		 try {
			 if 	(args.length <= 0) { return 0.0; }
			 else if (args[0] == null) { return 0.0; }
			 else {
				 Date sDate = null;	Date eDate = null; double divVal = 1000.0 * 60;
				 
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length >= 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length >= 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}

				 return ((sDate == null || eDate == null)? 0.0 : DIFF_MILLISECONDS(sDate, eDate) / divVal );
			 }
		 } catch (Exception e) { return 0.0; }
	 }

	 public Double DIFF_HOURS(Object... args) {
		 try {
			 if 	(args.length <= 0) { return 0.0; }
			 else if (args[0] == null) { return 0.0; }
			 else {
				 Date sDate = null;	Date eDate = null; double divVal = 1000.0 * 60 * 60;
				 
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length >= 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length >= 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}

				 return ((sDate == null || eDate == null)? 0.0 : DIFF_MILLISECONDS(sDate, eDate) / divVal );
			 }
		 } catch (Exception e) { return 0.0; }
	 }

	 public Double DIFF_DAYS(Object... args) {
		 try {
			 if 	(args.length <= 0) { return 0.0; }
			 else if (args[0] == null) { return 0.0; }
			 else {
				 Date sDate = null;	Date eDate = null; double divVal = 1000.0 * 60 * 60 * 24;
				 
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length >= 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length >= 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}

				 return ((sDate == null || eDate == null)? 0.0 : DIFF_MILLISECONDS(sDate, eDate) / divVal );
			 }
		 } catch (Exception e) { return 0.0; }
	 }

	 public Double DIFF_WEEKS(Object... args) {
		 try {
			 if 	(args.length <= 0) { return 0.0; }
			 else if (args[0] == null) { return 0.0; }
			 else {
				 Date sDate = null;	Date eDate = null; double divVal = 1000.0 * 60 * 60 * 24 * 7;
				 
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length >= 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length >= 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}

				 return ((sDate == null || eDate == null)? 0.0 : DIFF_MILLISECONDS(sDate, eDate) / divVal );
			 }
		 } catch (Exception e) { return 0.0; }
	 }

	 public Double DIFF_MONTHS(Object... args) {
		 try {
			 if 	(args.length <= 0) { return 0.0; }
			 else if (args[0] == null) { return 0.0; }
			 else {
				 Date sDate = null;	Date eDate = null; Date tDate = null;
				 
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length >= 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length >= 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}
				 
				 if (sDate == null || eDate == null) 			{ return 0.0; }
				 else if (sDate.getTime() == eDate.getTime()) 	{ return 0.0; }
				 else {
					 if(sDate.getTime() > eDate.getTime()) { tDate = sDate; sDate = eDate; eDate = tDate; }
					 
		             SimpleDateFormat yearFormat  = new SimpleDateFormat("yyyy",DATE_LOCALE);
		             SimpleDateFormat monthFormat = new SimpleDateFormat("MM",DATE_LOCALE);
		             SimpleDateFormat dayFormat   = new SimpleDateFormat("dd",DATE_LOCALE);

		             int fromYear  = Integer.parseInt(yearFormat.format(sDate));
		             int fromMonth = Integer.parseInt(monthFormat.format(sDate));
		             int fromDay   = Integer.parseInt(dayFormat.format(sDate));

		             int toYear    = Integer.parseInt(yearFormat.format(eDate));
		             int toMonth   = Integer.parseInt(monthFormat.format(eDate));
		             int toDay     = Integer.parseInt(dayFormat.format(eDate));
		            
		            return (toYear - fromYear) * 12.0 + (toMonth - fromMonth) + (toDay - fromDay) / 31.0;					 
				 }
			 }
		 } catch (Exception e) { return 0.0; }
	 }
	 public Double MONTHS_BETWEEN(Object... args) {
		 try {
			 return DIFF_MONTHS(args);
		 } catch (Exception e) { return 0.0; }
	 }		 

	 public Double DIFF_YEARS(Object... args) {
		 try {
			 if 	(args.length <= 0) { return 0.0; }
			 else if (args[0] == null) { return 0.0; }
			 else {
				 Date sDate = null;	Date eDate = null; double divVal = 12.0;
				 
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length >= 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length >= 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}

				 return ((sDate == null || eDate == null)? 0.0 : DIFF_MONTHS(sDate, eDate) / divVal );
			 }
		 } catch (Exception e) { return 0.0; }
	 }

	 public double DIFF_DATE(Object... args) {
		 try {
			 double result=0.0;
			 if 	(args.length <= 0) { result=0.0; }
			 else if (args[0] == null) { result=0.0; }
			 else {
				 	Date sDate = null;
				 	Date eDate = null;
				 	String dFormat = "";
				 	
				 	if 		(args.length >= 5)	{ sDate = TO_DATE(args[0], args[3], args[4]	); 	eDate = TO_DATE(args[1], args[3], args[4]	);	dFormat = (String)args[2]; }
				 	else if (args.length == 4)	{ sDate = TO_DATE(args[0], args[3]			);	eDate = TO_DATE(args[1], args[3]			);	dFormat = (String)args[2]; } 
				 	else if (args.length == 3)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	dFormat = (String)args[2]; } 
				 	else if (args.length == 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						); 	dFormat = "dd"; 		   }
				 	else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								dFormat = "dd";			   }
				 	
					if 	 (sDate == null || eDate == null) 					{ result = 0.0;							}
					else if ( IN(dFormat,"ss","s","S","SS") ) 				{ result = DIFF_SECONDS(sDate, eDate);	}
					else if ( IN(dFormat,"mm","m","mi","MI") ) 				{ result = DIFF_MINUTES(sDate, eDate);	}
					else if ( IN(dFormat,"hh","h","HH","H") ) 				{ result = DIFF_HOURS(sDate, eDate);	}
					else if ( IN(dFormat,"dd","d","DD","D") ) 				{ result = DIFF_DAYS(sDate, eDate);		}
					else if ( IN(dFormat,"ww","w","WW","W","wk","WK") ) 	{ result = DIFF_WEEKS(sDate, eDate);	}
					else if ( IN(dFormat,"MM","M") ) 						{ result = DIFF_MONTHS(sDate, eDate);	}
					else if ( IN(dFormat,"yy","y","YY","Y","yyyy","YYYY") )	{ result = DIFF_YEARS(sDate, eDate);	}
					else 													{ result = 0.0;							}				 	
			 }
			 return result;
		 } catch (Exception e) { return 0.0; }
	 }

	 public String DIFF_TIME(Object... args) {
		 try {
			 String result = null;
			 if 	(args.length <= 0) { result = null; }
			 else if (args[0] == null) { result = null; }
			 else {
				 Date sDate = null;
				 Date eDate = null;
				 	
				 if		 (args.length >= 4)	{ sDate = TO_DATE(args[0], args[2], args[3]	); 	eDate = TO_DATE(args[1], args[2], args[3]	);	}
				 else if (args.length == 3)	{ sDate = TO_DATE(args[0], args[2]			);	eDate = TO_DATE(args[1], args[2]			);	} 
				 else if (args.length == 2)	{ sDate = TO_DATE(args[0]					);	eDate = TO_DATE(args[1]						);	} 
				 else 						{ sDate = TO_DATE(args[0]					);	eDate = GETDATE();								}

				 if 	 (sDate == null || eDate == null) 					{ result = null; }
				 long duration = Math.abs(eDate.getTime() - sDate.getTime());
				 
				 int milliSecond 	= (int) (duration % 1000) ; 	duration = (long) (duration / 1000);
				 int Second 		= (int) (duration % 60) ;		duration = (long) (duration / 60); 
				 int Minute 		= (int) (duration % 60) ;		duration = (long) (duration / 60);
				 int hour   		= (int) (duration % 24) ;		duration = (long) (duration / 24);
				 int days   		= (int) duration;
				 
				 result = "";
				 if (days > 0) 				 		{result += days 		+ "_days ";			}
				 if (result!="" || hour > 0) 		{result += hour 		+ "_hours ";		}
				 if (result!="" || Minute > 0) 		{result += Minute 		+ "_minutes ";		}
				 if (result!="" || Second > 0) 		{result += Second 		+ "_seconds ";		}
				 if (result!="" || milliSecond > 0)	{result += milliSecond 	+ "_milliseconds ";	}
				 
				 return result.trim();
			 }
			 return result;
		 } catch (Exception e) { return null; }
	 }
	 
	 private int LAST_DAY(int year, int month) {
		 try {
			 int day=0;
			 
			 if (month == 2) {
				 if( (year % 4) == 0) {
					 if(((year %100) == 0) && ((year % 400) != 0)) {
						 day = 28; 
					 } else {day = 29;} 
				 } else { day = 28;}
			 } else if( IN(month,1,3,5,7,8,10,12) ) {
				 day = 31;
			 } else {
				 day = 30; 
			 }
			 return day;
		 } catch (Exception e) { return 0; }
	 }

	 public Date LAST_DAY(Date dDate) {
		 try {
			 SimpleDateFormat yearFormat 	= new SimpleDateFormat("yyyy",DATE_LOCALE);
			 SimpleDateFormat monthFormat 	= new SimpleDateFormat("MM",DATE_LOCALE);
			 SimpleDateFormat timeFormat 	= new SimpleDateFormat("HHmmss",DATE_LOCALE);
			 
			 java.text.DecimalFormat twoDf = new java.text.DecimalFormat("00");
			
			 int dayVal		= LAST_DAY( Integer.parseInt(yearFormat.format(dDate)), Integer.parseInt(monthFormat.format(dDate)) );
			 String tmpDate = yearFormat.format(dDate) + monthFormat.format(dDate) + String.valueOf(twoDf.format(dayVal)) + timeFormat.format(dDate);
			 
			 return TO_DATE(tmpDate, "yyyyMMddHHmmss", DATE_LOCALE);
		 } catch (Exception e) { return null; }
	 }
	 public String LAST_DAY(Object... args) {
		 try {
			 if 	(args.length <= 0) { return TO_CHAR(LAST_DAY(GETDATE())); }
			 else if (args[0] == null) { return null; }
			 else {
				 Date dDate = null;
				 
				 if 	 (args.length >= 3)	{ dDate = TO_DATE(args[0], args[1], args[2]	);	return ((dDate == null)? null : TO_CHAR(LAST_DAY(dDate), args[1], args[2]	) );} 
				 else if (args.length >= 2)	{ dDate = TO_DATE(args[0], args[1]			);	return ((dDate == null)? null : TO_CHAR(LAST_DAY(dDate), args[1]			) );}  
				 else 						{ dDate = TO_DATE(args[0]					);	return ((dDate == null)? null : TO_CHAR(LAST_DAY(dDate)						) );} 
			 }
		 } catch (Exception e) { return null; }
	 }	 

	 public Date NEXT_DAY(Date dDate, Object dNum) {
		 try {
			 if(dDate==null) {return null;}
			 else {
				 int aDay, dDay, wDay, wNum=0;
				 java.util.Calendar cal = new java.util.GregorianCalendar();
				 
				 if (dNum == null) {wNum = 7;}
				 else if (dNum instanceof Number) { wNum = (Integer)dNum; }
				 else if (dNum instanceof String) { 
					 if      (IN( (String)dNum, "1","��","�Ͽ���","SUN","SUNDAY"))  	{ wNum = 1;}
					 else if (IN( (String)dNum, "2","��","������","MON","MONDAY"))  	{ wNum = 2;}
					 else if (IN( (String)dNum, "3","ȭ","ȭ����","TUE","TUESDAY"))  	{ wNum = 3;}
					 else if (IN( (String)dNum, "4","��","������","WED","WEDNESDAY"))  { wNum = 4;}
					 else if (IN( (String)dNum, "5","��","�����","THU","THURSDAY"))  	{ wNum = 5;}
					 else if (IN( (String)dNum, "6","��","�ݿ���","FRI","FRIDAY"))  	{ wNum = 6;}
					 else if (IN( (String)dNum, "7","��","�����","SAT","SATURDAY"))  	{ wNum = 7;}
					 else if (IS_NUMBER( (String)dNum )) 							{ wNum = (int) TO_NUMBER( (String)dNum );}
					 else {wNum=0;}
				 }	 
				 else if (dNum instanceof Date) {
					 cal.setTime((Date)dNum);
					 wNum = cal.get(Calendar.DAY_OF_WEEK);
				 } else {wNum=0;}
				 	 
				 cal.setTime(dDate);
				 dDay = cal.get(Calendar.DAY_OF_WEEK);
				 
				 wDay = (wNum==0) ? dDay : ((Math.abs(wNum) % 7 == 0) ? 7 : Math.abs(wNum) % 7);
				 
				 if (dDay == wDay) { aDay = 7;}
				 else if (dDay  < wDay) { aDay = wDay - dDay; }
				 else {aDay = wDay - dDay + 7;}
	
				 return ADD_DAYS(dDate, aDay);
			 }
		 } catch (Exception e) { return null; }
	 }
	 
	 public String NEXT_DAY(Object... args) {
		 try {
			 if 	(args.length <= 0) { return null; }
			 else if (args[0] == null) { return null; }
			 else {
				 Date dDate 	= null;

				 if 	 (args.length >= 4)	{ dDate = TO_DATE(args[0], args[2], args[3]	);	return TO_CHAR(NEXT_DAY(dDate, args[1]), args[2], args[3]	); }
				 else if (args.length >= 3)	{ dDate = TO_DATE(args[0], args[2]			);	return TO_CHAR(NEXT_DAY(dDate, args[1]), args[2]			); }
				 else if (args.length >= 2)	{ dDate = TO_DATE(args[0]					);	return TO_CHAR(NEXT_DAY(dDate, args[1])						); }
				 else 						{ dDate = TO_DATE(args[0]					);	return TO_CHAR(NEXT_DAY(dDate, "7")							); }
			 }
		 } catch (Exception e) { return null; }
	 }
	 
	 public Date ADD_SECONDS(Date dDate, Object addNum) {
		 try {
			 if (dDate == null || addNum == null) 	{ return null; }
			 else if (!IS_NUMBER(addNum)) 			{ return null; } 
			 else {
				 long aNum = (long) TO_NUMBER(addNum);
				 double multiVal = 1000.0;
				 Date oDate	 = new Date();

				 oDate.setTime(dDate.getTime() + ((long) (aNum * multiVal) ));
				 return oDate;
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String ADD_SECONDS(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_SECONDS( GETDATE()						 , 1		), DATETIME_FORMAT			, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_SECONDS( TO_DATE(args[0]					), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_SECONDS( TO_DATE(args[0]					), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 3) { return TO_CHAR( ADD_SECONDS( TO_DATE(args[0], args[2]         ), args[1] 	), args[2]         							); }
			 else 						{ return TO_CHAR( ADD_SECONDS( TO_DATE(args[0], args[2], args[3]), args[1] 	), args[2]					, args[3]		); }
		 } catch (Exception e) { return null; }
	 }	 

	 public Date ADD_MINUTES(Date dDate, Object addNum) {
		 try {
			 if (dDate == null || addNum == null) 	{ return null; }
			 else if (!IS_NUMBER(addNum)) 			{ return null; } 
			 else {
				 long aNum = (long) TO_NUMBER(addNum);
				 double multiVal = 1000.0 * 60;
				 Date oDate	 = new Date();

				 oDate.setTime(dDate.getTime() + ((long) (aNum * multiVal) ));
				 return oDate;
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String ADD_MINUTES(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_MINUTES( GETDATE()						 , 1		), DATETIME_FORMAT			, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_MINUTES( TO_DATE(args[0]					), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_MINUTES( TO_DATE(args[0]					), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 3) { return TO_CHAR( ADD_MINUTES( TO_DATE(args[0], args[2]         ), args[1] 	), args[2]         							); }
			 else 						{ return TO_CHAR( ADD_MINUTES( TO_DATE(args[0], args[2], args[3]), args[1] 	), args[2]					, args[3]		); }
		 } catch (Exception e) { return null; }
	 }	
	 
	 public Date ADD_HOURS(Date dDate, Object addNum) {
		 try {
			 if (dDate == null || addNum == null) 	{ return null; }
			 else if (!IS_NUMBER(addNum)) 			{ return null; } 
			 else {
				 long aNum = (long) TO_NUMBER(addNum);
				 double multiVal = 1000.0 * 60 * 60;
				 Date oDate	 = new Date();

				 oDate.setTime(dDate.getTime() + ((long) (aNum * multiVal) ));
				 return oDate;
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String ADD_HOURS(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_HOURS( GETDATE()						 	 , 1		), DATETIME_FORMAT			, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_HOURS( TO_DATE(args[0]					), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_HOURS( TO_DATE(args[0]					), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 3) { return TO_CHAR( ADD_HOURS( TO_DATE(args[0], args[2]         	), args[1] 	), args[2]         							); }
			 else 						{ return TO_CHAR( ADD_HOURS( TO_DATE(args[0], args[2], args[3]	), args[1] 	), args[2]					, args[3]		); }
		 } catch (Exception e) { return null; }
	 }	
	 
	 public Date ADD_DAYS(Date dDate, Object addNum) {
		 try {
			 if (dDate == null || addNum == null) 	{ return null; }
			 else if (!IS_NUMBER(addNum)) 			{ return null; } 
			 else {
				 long aNum = (long) TO_NUMBER(addNum);
				 double multiVal = 1000.0 * 60 * 60 * 24;
				 Date oDate	 = new Date();

				 oDate.setTime(dDate.getTime() + ((long) (aNum * multiVal) ));
				 return oDate;
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String ADD_DAYS(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_DAYS( GETDATE()						 	 , 1		), DATE_FORMAT				, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_DAYS( TO_DATE(args[0]						), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_DAYS( TO_DATE(args[0]						), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 3) { return TO_CHAR( ADD_DAYS( TO_DATE(args[0], args[2]         	), args[1] 	), args[2]      							); }
			 else 						{ return TO_CHAR( ADD_DAYS( TO_DATE(args[0], args[2], args[3]	), args[1] 	), args[2]					, args[3]		); }
		 } catch (Exception e) { return null; }
	 }	

	 public Date ADD_WEEKS(Date dDate, Object addNum) {
		 try {
			 if (dDate == null || addNum == null) 	{ return null; }
			 else if (!IS_NUMBER(addNum)) 			{ return null; } 
			 else {
				 long aNum = (long) TO_NUMBER(addNum);
				 double multiVal = 1000.0 * 60 * 60 * 24 * 7;
				 Date oDate	 = new Date();

				 oDate.setTime(dDate.getTime() + ((long) (aNum * multiVal) ));
				 return oDate;
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String ADD_WEEKS(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_WEEKS( GETDATE()						 	 , 1		), DATE_FORMAT				, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_WEEKS( TO_DATE(args[0]					), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_WEEKS( TO_DATE(args[0]					), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 3) { return TO_CHAR( ADD_WEEKS( TO_DATE(args[0], args[2]         	), args[1] 	), args[2]      							); }
			 else 						{ return TO_CHAR( ADD_WEEKS( TO_DATE(args[0], args[2], args[3]	), args[1] 	), args[2]					, args[3]		); }
		 } catch (Exception e) { return null; }
	 }	

	 public Date ADD_MONTHS(Date dDate, Object addNum) {
		 try {
			 if (dDate == null || addNum == null) 	{ return null; }
			 else if (!IS_NUMBER(addNum)) 			{ return null; } 
			 else {
				 Date oDate=dDate;
				 long aNum = (long) TO_NUMBER(addNum);
				 
				 SimpleDateFormat yearFormat 	= new SimpleDateFormat("yyyy",DATE_LOCALE);
				 SimpleDateFormat monthFormat 	= new SimpleDateFormat("MM",DATE_LOCALE);
				 SimpleDateFormat dayFormat 	= new SimpleDateFormat("dd",DATE_LOCALE);	
				 SimpleDateFormat timeFormat 	= new SimpleDateFormat("HHmmss",DATE_LOCALE);
				
				 int yearVal 	= Integer.parseInt(yearFormat.format(dDate));
				 int monthVal 	= Integer.parseInt(monthFormat.format(dDate));
				 int dayVal 	= Integer.parseInt(dayFormat.format(dDate));

				 monthVal += aNum;
		         if (aNum > 0) {
		                while (monthVal > 12) {
		                	monthVal -= 12;
		                	yearVal += 1;
		                }
		         } else {
		                while (monthVal <= 0) {
		                	monthVal += 12;
		                	yearVal -= 1;
		                }
		         }
				 
		         java.text.DecimalFormat fourDf = new java.text.DecimalFormat("0000");
		         java.text.DecimalFormat twoDf = new java.text.DecimalFormat("00");
		         
		         String tempDate = String.valueOf(fourDf.format(yearVal)) + String.valueOf(twoDf.format(monthVal)) + String.valueOf(twoDf.format(dayVal));
		         if (IS_DATE(tempDate,"yyyyMMdd")) {
		        	 oDate = TO_DATE(tempDate + timeFormat.format(dDate),"yyyyMMddHHmmss");
		         } else {
		        	 tempDate = String.valueOf(fourDf.format(yearVal)) + String.valueOf(twoDf.format(monthVal)) + "01";
		        	 oDate =LAST_DAY(TO_DATE(tempDate + timeFormat.format(dDate),"yyyyMMddHHmmss")); 
		         }
				 return oDate;
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String ADD_MONTHS(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_MONTHS( GETDATE()						 	 , 1		), DATE_FORMAT				, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_MONTHS( TO_DATE(args[0]					), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_MONTHS( TO_DATE(args[0]					), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 3) { return TO_CHAR( ADD_MONTHS( TO_DATE(args[0], args[2]         	), args[1] 	), args[2]      							); }
			 else 						{ return TO_CHAR( ADD_MONTHS( TO_DATE(args[0], args[2], args[3]	), args[1] 	), args[2]					, args[3]		); }
		 } catch (Exception e) { return null; }
	 }	

	 public Date ADD_YEARS(Date dDate, Object addNum) {
		 try {
			 if (dDate == null || addNum == null) 	{ return null; }
			 else if (!IS_NUMBER(addNum)) 			{ return null; } 
			 else {
				 long aNum = (long) TO_NUMBER(addNum);
				 Date oDate	 = ADD_MONTHS(dDate, aNum*12);
				 return oDate;
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String ADD_YEARS(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_YEARS( GETDATE()						 	 , 1		), DATE_FORMAT				, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_YEARS( TO_DATE(args[0]					), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_YEARS( TO_DATE(args[0]					), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 3) { return TO_CHAR( ADD_YEARS( TO_DATE(args[0], args[2]         	), args[1] 	), args[2]      							); }
			 else 						{ return TO_CHAR( ADD_YEARS( TO_DATE(args[0], args[2], args[3]	), args[1] 	), args[2]					, args[3]		); }
		 } catch (Exception e) { return null; }
	 }	

	 public Date ADD_DATE(Date dDate, Object... args) {
		 try {
			 Date dVal = (dDate==null ? GETDATE() : dDate);
			 String dFormat = null;
			 int    addNum = 0; 
			 
			 if 	 (args.length > 0) {
				 dFormat = (args.length > 1) ? ((args[1] instanceof String) ? (String)args[1] : null ) : "D";

				 if (IS_NUMBER(args[0])) { addNum = (int) TO_NUMBER(args[0]); }  
				 else { 
						 dFormat = null;
						 addNum = 0;
				 }
			 } else {
				 dFormat = "D";
				 addNum = 1;
			 }
			 
			 if      (dFormat == null)								{ return null;}
			 else if (IN(dFormat,"ss","s","S","SS")) 				{ return ADD_SECONDS(dVal,addNum);}
			 else if (IN(dFormat,"mm","m","mi","MI")) 				{ return ADD_MINUTES(dVal,addNum); }
			 else if (IN(dFormat,"hh","h","HH","H")) 				{ return ADD_HOURS(dVal,addNum); }
			 else if (IN(dFormat,"dd","d","DD","D")) 				{ return ADD_DAYS(dVal,addNum); }
			 else if (IN(dFormat,"ww","w","WW","W","wk","WK")) 		{ return ADD_WEEKS(dVal,addNum); }
			 else if (IN(dFormat,"MM","M")) 						{ return ADD_MONTHS(dVal,addNum); }
			 else if (IN(dFormat,"yy","y","YY","Y","yyyy","YYYY"))	{ return ADD_YEARS(dVal,addNum); }
			 else {return ADD_DAYS(dVal,addNum);}
		 } catch (Exception e) { return null; }
	 }

	 public String ADD_DATE(Object... args) {
		 try {
			 if (args.length <= 0) 		{ return TO_CHAR( ADD_DAYS( GETDATE()						 , 1		), DATE_FORMAT				, DATE_LOCALE	); }
			 else if (args.length <= 1) { return TO_CHAR( ADD_DAYS( TO_DATE(args[0]					), 1		), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else if (args.length <= 2) { return TO_CHAR( ADD_DAYS( TO_DATE(args[0]					), args[1] 	), GET_DATEFORMAT(args[0])	, DATE_LOCALE	); }
			 else {
				 String dFormat = (String)args[2];
				 String format  = (args.length >= 4) ? (String)args[3] : GET_DATEFORMAT(args[0]);
				 Object dLocale = (args.length >= 5) ? (Object)args[4] : DATE_LOCALE;
				 
				      if (IN(dFormat,"ss","s","S","SS")) 				{ return ADD_SECONDS(	args[0], args[1], format, dLocale); }
				 else if (IN(dFormat,"mm","m","mi","MI")) 				{ return ADD_MINUTES(	args[0], args[1], format, dLocale); }
				 else if (IN(dFormat,"hh","h","HH","H")) 				{ return ADD_HOURS(		args[0], args[1], format, dLocale); }
				 else if (IN(dFormat,"dd","d","DD","D")) 				{ return ADD_DAYS(		args[0], args[1], format, dLocale); }
				 else if (IN(dFormat,"ww","w","WW","W","wk","WK")) 		{ return ADD_WEEKS(		args[0], args[1], format, dLocale); }
				 else if (IN(dFormat,"MM","M")) 						{ return ADD_MONTHS(	args[0], args[1], format, dLocale); }
				 else if (IN(dFormat,"yy","y","YY","Y","yyyy","YYYY"))	{ return ADD_YEARS(		args[0], args[1], format, dLocale); }
				 else 													{ return ADD_DAYS(		args[0], args[1], format, dLocale); }
			 }
		 } catch (Exception e) { return null; }
	 }

	 public double ROUND(Object... args) {
		 try {
			 if (args.length < 1) 	{return 0;}
			 else if (args[0]==null){return 0;}
			 else {
				 double val = TO_NUMBER(args[0]);
				 int 	digit 	= (args.length >= 2) ? (int) TO_NUMBER(args[1]) : 0 ;
				 return  (digit==0) ? Math.round(val) : Math.round( val * Math.pow(10, digit)) / (Math.pow(10, digit)) ;
			 }
		 } catch (Exception e) { return 0; }
	 }

	 public double CEIL(Object... args) {
		 try {
			 if (args.length < 1) 	{return 0;}
			 else if (args[0]==null){return 0;}
			 else {
				 double val 	= TO_NUMBER(args[0]);
				 int 	digit 	= (args.length >= 2) ? (int) TO_NUMBER(args[1]) : 0 ;
				 return  (digit==0) ? Math.ceil(val) : Math.ceil( val * Math.pow(10, digit)) / (Math.pow(10, digit)) ;
			 }
		 } catch (Exception e) { return 0; }
	 }

	 public double FLOOR(Object... args) {
		 try {
			 if (args.length < 1) 	{return 0;}
			 else if (args[0]==null){return 0;}
			 else {
				 double val 	= TO_NUMBER(args[0]);
				 int 	digit 	= (args.length >= 2) ? (int) TO_NUMBER(args[1]) : 0 ;
				 return  (digit==0) ? Math.floor(val) : Math.floor( val * Math.pow(10, digit)) / (Math.pow(10, digit)) ;
			 }
		 } catch (Exception e) { return 0; }
	 }

	 public double TRUNC(Object... args) {
		 try {
			 if (args.length <= 0) { return 0;}
			 else if (args[0]==null){return 0;}
			 else if (args[0] instanceof Number ) { 
				 double val 	= TO_NUMBER(args[0]);
				 int 	digit 	= (args.length >= 2) ? (int) TO_NUMBER(args[1]) : 0 ;
				 return  (digit==0) ? (long) val : ( (long) (val * Math.pow(10, digit)) ) / (Math.pow(10, digit)) ;
			 }
			 else { return 0; }
		 } catch (Exception e) { return 0; }
	 }
	 public Date TRUNC(Date val, String... args) {
		 try {
			 if (val == null) { return null; }
			 else {
				 String dFormat = "";
				 if (args.length <= 0) 	{ dFormat = "D";}
				 else if (args[0]==null){ dFormat = "D";}
				 else 					{ dFormat = args[0];}
				 
				 if 	 (IN(dFormat,"ss","s","S","SS")) 				{ return TO_DATE(TO_CHAR(val, DATETIME_FORMAT)); }
				 else if (IN(dFormat,"mm","m","mi","MI")) 				{ return TO_DATE(TO_CHAR(val, DATETIME_FORMAT.substring(0, 15))); }
				 else if (IN(dFormat,"hh","h","HH","H")) 				{ return TO_DATE(TO_CHAR(val, DATETIME_FORMAT.substring(0, 12))); }
				 else if (IN(dFormat,"dd","d","DD","D")) 				{ return TO_DATE(TO_CHAR(val, DATETIME_FORMAT.substring(0,  9))); }
				 else if (IN(dFormat,"MM","M")) 						{ return TO_DATE(TO_CHAR(val, DATETIME_FORMAT.substring(0,  6))); }
				 else if (IN(dFormat,"yy","y","YY","Y","yyyy","YYYY"))	{ return TO_DATE(TO_CHAR(val, DATETIME_FORMAT.substring(0,  3))); }
				 else 													{ return TO_DATE(TO_CHAR(val, DATETIME_FORMAT.substring(0,  9))); }
			 }
		 } catch (Exception e) { return null; }
	 }
	 public String TRUNC(String val, Object... args) {
		 try {
			 if 	 (val==null) 		{ return null;}
			 else if (val.equals("")) 	{ return "";}
			 else if (IS_NUMBER(val)) 	{ return (args.length > 0) ? TO_CHAR( TRUNC( TO_NUMBER(val), args[0] )) : TO_CHAR( TRUNC( TO_NUMBER(val))); } 
			 else { 
				if 		(args.length <= 0) 	{ return (IS_DATE(val) 					) ? TO_CHAR(TO_DATE(val						)					) : null; }
				else if (args.length <= 1) 	{ return (IS_DATE(val, args[0]) 		) ? TO_CHAR(TO_DATE(val, args[0]			), args[0]			) : null; }
				else 					 	{ return (IS_DATE(val, args[0], args[1])) ? TO_CHAR(TO_DATE(val, args[0], args[1]	), args[0], args[1]	) : null; }
			 }
		 } catch (Exception e) { return null; }
	 }

	 public String TRIM(String val) {
		 try {
			 if 	 (val==null) 		{ return null;	}
			 else if (val.equals("")) 	{ return "";	}
			 else 						{ return val.trim(); }
		 } catch (Exception e) { return null; }
	 }
	 public String RTRIM(String val) {
		 try {
			 if 	 (val==null) 		{ return null;}
			 else if (val.equals("")) 	{ return "";}
			 else 						{ return ("*" + val).trim().substring(1);}
		 } catch (Exception e) { return null; }
	 }
	 public String LTRIM(String val) {
		 try {
			 if 	 (val==null) 		{ return null;}
			 else if (val.equals("")) 	{ return "";}
			 else 						{ 
				 String result = ( val + "*" ).trim();
				 return result.substring(0,result.length()-1);
			 }
		 } catch (Exception e) { return null; }
	 }
	 
	 public String LPAD(String orgStr, int padLen, String... padStr) {
		 try {
			 if (orgStr == null) {orgStr = "";}
			 
			 String result="";
			 int tmpLen = padLen - orgStr.length();
			 String pStr = (padStr.length <= 0 ) ? " " : padStr[0];  
			 
			 if 	 (padLen <= 0 || tmpLen <= 0)       { result = orgStr;}
			 else if (pStr == null || pStr.equals("")) 	{ result = orgStr;}
			 else if (tmpLen <= 0) 						{ result = orgStr;}
			 else {
				 while (result.length() <= tmpLen) { result += pStr; }
				 result = result.substring(0, tmpLen) + orgStr;
			 }
			 return result;
		 } catch (Exception e) { return null; }
	 }

	 public String RPAD(String orgStr, int padLen, String... padStr) {
		 try {
			 if (orgStr == null) {orgStr = "";}
			 
			 String result="";
			 int tmpLen = padLen - orgStr.length();
			 String pStr = (padStr.length <= 0 ) ? " " : padStr[0];  
			 
			 if 	 (padLen <= 0 || tmpLen <= 0)       { result = orgStr;}
			 else if (pStr == null || pStr.equals("")) 	{ result = orgStr;}
			 else {
				 while (result.length() <= tmpLen) { result += pStr; }
				 result = orgStr + result.substring(0, tmpLen);
			 }
			 return result;
		 } catch (Exception e) { return null; }
	 }	 

	 public String SUBSTR(String orgStr, int pos, Object... slen) {
		 try {
			 String result = "";
			 int sPos, ePos, tPos, len;
			 int EPos = orgStr.length();
			 
			 if 	 (slen.length <= 0) 		 { len = orgStr.length(); 							} 
			 else if (slen[0] instanceof Number) { len = (int) (((Number)slen[0]).doubleValue()); 	}
			 else if (slen[0] instanceof String) { len = ((String)slen[0]).length(); 				}
			 else {	 							   len = (int) TO_NUMBER(slen[0]); 			 		}
			 
			 if( len == 0 ) {result = "";}
			 else {
				 sPos = (pos > 0) ? pos-1 : EPos+pos;
				 ePos = sPos+len;
				 
				 if(sPos > ePos) { tPos=ePos; ePos=sPos; sPos=tPos;} //�� ��ȯ

				 if(sPos < 0 ) {sPos=0;} else if(sPos > EPos) {sPos=EPos;}
				 if(ePos < 0 ) {ePos=0;} else if(ePos > EPos) {ePos=EPos;}
				 
				 result = (sPos==ePos) ? "" : orgStr.substring(sPos, ePos);
			 }
			 return result;
		 } catch (Exception e) { return null; }
	 }
/*
	 public String SUBSTR(String orgStr, int pos, int len) {
		 try {
			 String result = "";
			 int sPos, ePos, tPos;
			 int EPos = orgStr.length()-1;
			 
			 if( len == 0 ) {result = "";}
			 else {
				 if(pos > 0) {sPos = pos-1;} else {sPos = EPos+pos+1 ;}
				 ePos = sPos+len;
				 
				 if(sPos > ePos) { tPos=ePos; ePos=sPos; sPos=tPos;} //�� ��ȯ

				 if(sPos < 0 ) {sPos=0;} else if(sPos > EPos) {sPos=EPos+1;}
				 if(ePos < 0 ) {ePos=0;} else if(ePos > EPos) {ePos=EPos+1;}
				 
				 result = (sPos==ePos) ? "" : orgStr.substring(sPos, ePos);
			 }
			 
			 return result;
		 } catch (Exception e) { return null; }
	 }
	 public String SUBSTR(String orgStr, int pos) {
		 try {
			 return SUBSTR(orgStr, pos, orgStr.length()) ;
		 } catch (Exception e) { return null; }
	 }
*/
	 public String SUBSTRB(String orgStr, int pos, Object... slen) {
		 try {
			 String result = "";
			 byte[] src = orgStr.getBytes();
			 
			 int sPos, ePos, tPos, len;
			 int EPos = src.length;
			 
			 
			 if 	 (slen.length <= 0) 		 { len = src.length; 								} 
			 else if (slen[0] instanceof Number) { len = (int) (((Number)slen[0]).doubleValue()); 	}
			 else if (slen[0] instanceof String) { len = ((String)slen[0]).getBytes().length; 		}
			 else {	 							   len = (int) TO_NUMBER(slen[0]); 			 		}
			 
			 if( len == 0 ) {result = "";}
			 else {
				 sPos = (pos > 0) ? pos-1 : EPos+pos;
				 ePos = sPos+len;
				 
				 if(sPos > ePos) { tPos=ePos; ePos=sPos; sPos=tPos;} //�� ��ȯ

				 if(sPos < 0 ) {sPos=0;} else if(sPos > EPos) {sPos=EPos;}
				 if(ePos < 0 ) {ePos=0;} else if(ePos > EPos) {ePos=EPos;}
				 
				 if (sPos==ePos) {
					 result = "";
				 } else {
					 byte[] dest = new byte[ePos - sPos];
					 
					 System.arraycopy(orgStr.getBytes(), sPos, dest, 0, ePos - sPos);
					 result = new String(dest);
				 }
			 }
			 return result;
		 } catch (Exception e) { return null; }
	 }	 
/*	 
	 public String SUBSTRB(String orgStr, int pos, int len) {
		 try {
			 String result = "";
			 byte[] src = orgStr.getBytes();
			 
			 int sPos, ePos, tPos;
			 int EPos = src.length;
			 
			 if( len == 0 ) {result = "";}
			 else {
				 if(pos > 0) {sPos = pos;} else {sPos = EPos+pos ;}
				 ePos = sPos+len;
				 
				 if(sPos > ePos) { tPos=ePos; ePos=sPos; sPos=tPos;} //�� ��ȯ

				 if(sPos < 0 ) {sPos=0;} else if(sPos > EPos) {sPos=EPos;}
				 if(ePos < 0 ) {ePos=0;} else if(ePos > EPos) {ePos=EPos;}
				 
				 if (sPos==ePos) {
					 result = "";
				 } else {
					 byte[] dest = new byte[ePos - sPos];
					 
					 System.arraycopy(orgStr.getBytes(), sPos, dest, 0, ePos - sPos);
					 result = new String(dest);
				 }
			 }
			 return result;
		 } catch (Exception e) { return null; }
	 }
	 public String SUBSTRB(String orgStr, int pos) {
		 try {
			 return SUBSTRB(orgStr, pos, orgStr.getBytes().length) ;
		 } catch (Exception e) { return null; }
	 }
*/	 
	 public int LENGTH(String orgStr) {
		 try {
			 return orgStr.length() ;
		 } catch (Exception e) { return 0; }
	 }
	 public int LENGTHB(String orgStr) {
		 try {
			 return orgStr.getBytes().length ;
		 } catch (Exception e) { return 0; }
	 }

	 public Object DECODE(Object val, Object... args) {
		 try {
			 Object result = null;
			 if (args.length < 2) { return result;}
			 else {
				 
				 for (int ii=0 ; ii < args.length ; ii+=2) {
					 if (args.length-ii < 2) {
						 result = args[ii];
					 } else {
						 if (val==null) {
							 if (args[ii]==null) {
								 result = args[ii+1];
								 break;
							 }
						 } else if(val.equals(args[ii])) {
							 result = args[ii+1];
							 break;
						 } else {
							 if ((val instanceof Number) && (args[ii] instanceof Number)) {
							 	 if (((Number)val).doubleValue() == ((Number)args[ii]).doubleValue()) {
							 		 result = args[ii+1];
							 		 break;
							 	 }
							 }
						 }
					 } 
					 
				 }
			 }
			 return result;
		 } catch (Exception e) {return null;}
	 }
	 public String REVERSESTR(String str) {
		 try {
			 StringBuffer sf = new StringBuffer(str);
			 
			 return (sf.reverse()).toString();
		 } catch (Exception e) {return "";}
	 }
	 
	 public int INSTR(String str, String substr, int... args) {
		 try {
			 if ( str == null || substr == null ) 			{ return 0; }
			 else if (str.equals("") || substr.equals("") ) { return 0; }
			 else {
				 int pos = (args.length > 0 ) ? (args[0]==0 ? -1 : args[0]) : 1;
				 int cnt = (args.length > 1 ) ? args[1] : 1;
				 
				 int iPos = Math.abs(pos) - 1 , tpos=0;
				 String iStr=str, iSub = substr;

				 if (pos < 0) {
					 iStr 	= REVERSESTR(iStr);
					 iSub 	= REVERSESTR(iSub);
				 } 
				 
				 iStr = iStr.substring(iPos);
				 
				 for ( int ii=1 ; ii <= cnt ; ii++) {
					 tpos = iStr.indexOf(iSub);
					 if ( tpos < 0 ) {
						 iStr = null; 
						 break;
					 }
					 else {
						 iStr = iStr.substring(tpos + iSub.length() );
					 }
				 } 
				 iPos = (iStr==null) ? 0 : ((pos <= 0) ? iStr.length()+1 : str.length() - iStr.length() - iSub.length() + 1);
				 return iPos;
			 } 
		 } catch (Exception e) {return 0;}
	 }
	 public int INSTRB(String str, String substr, int... args) {
		 try {
			 if 	 ( str == null || substr == null ) 		{ return 0; }
			 else if (str.equals("") || substr.equals("") ) { return 0; }
			 else 											{ return SUBSTR(str,1,INSTR(str,substr, args)).getBytes().length; } 
		 } catch (Exception e) {return 0;}
	 }
	 public Object COALESCE(Object... args) {
		 try {
			 for (int ii = 0 ; ii < args.length ; ii++) {
				 if (args[ii] != null) {
					 return args[ii];
				 }
			 } 
			 return null;
		 } catch (Exception e) { return null; }
	 }

	 public String STRTOSAM(String str, int len) {
		 try {
			 String retVal = "";
			 if (str ==null || str.trim().equals("")) {
				 retVal = String.format("%" + len + "s", " ");
			 } else {
				 retVal = SUBSTRB(String.format("%-" + len + "s", str.trim()), 1, len);
			 }
			 return retVal;
		 } catch (Exception e) {return null;}	 
	 }

	 public String NUMTOSAM(String str, int len, String fchar) {
		 try {
			 String retVal ="";
			 
			 if (str ==null || str.trim().equals("")) {
				 retVal = String.format("%" + len + "s", " ");
			 } else if (IS_NUMBER(str.trim())) {
				 str =  str.trim();
				 if ( fchar == null || fchar.trim().equals("")) {
					 str = TO_CHAR(new BigDecimal(str));
					 retVal = (String.format("%" + len + "s", str));
				 } else {
					 if (TO_NUMBER(str) < 0) {
						 str = TO_CHAR(  (new BigDecimal(str)).multiply(new BigDecimal("-1")) );
						 retVal = ("-"+String.format("%" + (len-1) + "s", str)).replace(" ", "0");
					 } else  {
						 str = TO_CHAR( new BigDecimal(str).toString() );
						 retVal = (String.format("%" + len + "s", str)).replace(" ", "0");
					 }
				 }
				 retVal = retVal.substring(0, len);
			 } else {
				 retVal = STRTOSAM(str, len);
			 }
			 return retVal;
		 } catch (Exception e) {return null;}	 
	 }
	 public String NUMTOSAM(String str, int len) {
		 return NUMTOSAM(str, len, "0");
	 }
	 
	 public boolean IN_CHARS(String targetStr, String sh_chrs) {
		 try {
			 Pattern p = Pattern.compile(sh_chrs);  
			 Matcher m = p.matcher(targetStr);  
			 
			 return m.find();
		 } catch (Exception e) {return false;}
	 }
	 
	 public boolean CHECK_SCHAR(String... args) {
		 try {
			 String orgStr = " \n\t@#$%^&*(){}[]<=>~_-+`'\".,:;\\|/?!";
			 String shStr="[", iiStr ="";
	
			 if (args.length > 0) {
				 if (args.length > 1) {
					 if(args[1].equals("")==false) {orgStr = args[1];}
				 } 
	
				 for (int ii=0;ii<orgStr.length();ii++) {
					 iiStr = orgStr.substring(ii, ii+1);
					 
					 if (IN(iiStr, "*,(,),{,[,],-,+,\\,?", ",")) {iiStr="\\"+iiStr;}
					 else if (iiStr.equals(" ")) {iiStr="\\s";}
					 else if (iiStr.equals("	")) {iiStr="\\t";}
					 else if (iiStr.equals("\n")) {iiStr="\\n";}
					 shStr = shStr + iiStr;
				 }
				 shStr = shStr + "]";
	
				 return IN_CHARS(args[0], shStr);
			 } else {return false;}
			 
			 
		 } catch (Exception e) {return false;}
	 }
	
	public String getCurrentTimeStamp() {
	    SimpleDateFormat sdfDate = new SimpleDateFormat("yyyyMMddHHmmssSSS");
	    Date now = new Date();
	    String strDate = sdfDate.format(now);
	    return strDate;
	}

	public Object COMPARE(Object orgVal, Object comVal) {
		if (orgVal==null || comVal == null) {return null;}
		else {
			if (orgVal instanceof Double) { 
				return ((double)orgVal - (double)comVal);
			} else if (orgVal instanceof Long) {
				return ((long)orgVal - (long)comVal);
			} else if (orgVal instanceof Integer) {
				return ((int)orgVal - (int)comVal);
			} else if (orgVal instanceof Number) {
				return (((Number)orgVal).doubleValue() - ((Number)comVal).doubleValue());
			} else if (orgVal instanceof Date || orgVal instanceof Timestamp) {
				return (double)( TO_DATE(orgVal).getTime() - TO_DATE(comVal).getTime());					
			} else {
				return (int)orgVal.toString().compareTo(comVal.toString());
			}
		}
	}
	@SuppressWarnings("rawtypes")
	public boolean ISEMPTY(Object val){
		try {
			if 		(val == null																						) {return true;}
			else if	(val instanceof String 		&& 		val.toString().trim().equals("")								) {return true;}
			else if (val instanceof Map 		&& (	((Map) val).isEmpty()			|| ((Map) val).size() < 1	)	) {return true;}
			else if (val instanceof HashMap		&& (	((Map) val).isEmpty()			|| ((Map) val).size() < 1	)	) {return true;}
			else if (val instanceof List 		&& (	((List) val).isEmpty() 			|| ((List) val).size() < 1	)	) {return true;}
			else if	(val instanceof String[]	&& 		((String[]) val).length < 1 									) {return true;}
			else if	(val instanceof Object[]	&& 		((Object[]) val).length < 1 									) {return true;}
			else if (val.getClass().isArray() 	&& 		((Object[]) val).length < 1 									) {return true;}
			else if (val.toString().trim().equals("")																	) {return true;}			
			return false;
		} catch (Exception e) {
			return false;
		}
	}
	public Object IFEMPTY(Object val, Object replaceVal) {
		if 		(ISEMPTY(val)) {
			return (ISEMPTY(replaceVal) ? null : replaceVal);
		} else {
			return val;
		}
	}
	public Object IFEMPTY(Object val, Object replaceVal, Object replaceVal2) {
		if 		(ISEMPTY(val)) {
			return (ISEMPTY(replaceVal) ? ((ISEMPTY(replaceVal2) ? null : replaceVal2)) : replaceVal);
		} else {
			return (ISEMPTY(replaceVal2) ? val : replaceVal2);
		}
	}	
	@SuppressWarnings("rawtypes")
	public boolean ISEMPTY(Object val, String key){
		try {
			if 		(		ISEMPTY(val) 	|| 	ISEMPTY(key)																	) {return true;}
			else if	(val instanceof String 		&& 		INSTR((String)val,key)	<= 0											) {return true;}
			else if (val instanceof Map 		&& (	!((Map) val).containsKey(key)	|| ISEMPTY(((Map) val).get(key))	)	) {return true;}
			else if (val instanceof HashMap		&& (	!((Map) val).containsKey(key)	|| ISEMPTY(((Map) val).get(key))	)	) {return true;}
			else if	(val instanceof String[]	&& 		!IN((Object)key, ((Object[]) val))	 									) {return true;}
			else if	(val instanceof Object[]	&& 		!IN((Object)key, ((Object[]) val))	 									) {return true;}
			else if	(val.getClass().isArray()	&& 		!IN((Object)key, ((Object[]) val))	 									) {return true;}

			return false;
		} catch (Exception e) {
			return false;
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Object FINDMAP(Map<String, Object> map, String key) {
		if 		(! ISEMPTY(map) && !ISEMPTY(key)) 	{	
			if (map.containsKey(key)) {
				return map.get(key);
			} else {
				for(String sKey : map.keySet()) {
					Object sObj = map.get(sKey); 
					if ( sObj instanceof Map || sObj instanceof HashMap) {
						Object rVal = FINDMAP( (Map<String, Object>)sObj, key);
						if (rVal != null) {return rVal;}
					} else if (sObj instanceof List ) {
						Object rVal = FINDMAP( (List<Map>)sObj, key);
						if (rVal != null) {return rVal;}
					}
				}
			}
		}
		return null;
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Object FINDMAP(List<Map> lMap, String key) {
		if 	(! ISEMPTY(lMap) && !ISEMPTY(key)) 	{
			for (int ii = 0 ; ii < lMap.size() ; ii++) {
				Object rVal = FINDMAP( (Map<String, Object>)lMap.get(ii), key);
				if (rVal != null) {return rVal;}
			}
		}
		return null;
	}
	
	public Object FINDMAP(Map<String, Object> map, String key, Object replaceVal) {
		if ( !ISEMPTY(map) && ! ISEMPTY(key) ) {
			Object fVal = FINDMAP(map, key);
			if (fVal != null) { return fVal;}
		} 
		return ISEMPTY(replaceVal) ? null : replaceVal;
	}
	@SuppressWarnings("rawtypes")
	public Object FINDMAP(List<Map> lMap, String key, Object replaceVal) {
		if ( !ISEMPTY(lMap) && ! ISEMPTY(key) ) {
			Object fVal = FINDMAP(lMap, key);
			if (fVal != null) { return fVal;}
		} 
		return ISEMPTY(replaceVal) ? null : replaceVal;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Object IFEMPTY(Object val, String key, Object replaceVal) {
		if ( ISEMPTY(key) ) { return IFEMPTY(val, replaceVal); }
		else if ( !ISEMPTY(val)  ) {
			if (val instanceof Map || val instanceof HashMap ) {
				Object rVal = FINDMAP( (Map<String, Object>)val, key);
				if (rVal == null) {
					if (!ISEMPTY(replaceVal)) {
						if (replaceVal instanceof Map || replaceVal instanceof HashMap ){ return FINDMAP((Map<String, Object>)replaceVal, key);	} 	
						else if (replaceVal instanceof List ) 							{ return FINDMAP((List<Map>)replaceVal, key);			}
						else 															{ return replaceVal;									}
					} else { return null;}
				} else {return rVal;}
			} else if (val instanceof List) {
				Object rVal = FINDMAP( (List<Map>)val, key);
				if (rVal == null) {
					if (!ISEMPTY(replaceVal)) {
						if (replaceVal instanceof Map || replaceVal instanceof HashMap ){ return FINDMAP((Map<String, Object>)replaceVal, key);	} 	
						else if (replaceVal instanceof List ) 							{ return FINDMAP((List<Map>)replaceVal, key);			}
						else 															{ return replaceVal;									}
					} else { return null;}
				} else {return rVal;}
			} else {return val;}
		} else {
			if (!ISEMPTY(replaceVal)) {
				if (replaceVal instanceof Map || replaceVal instanceof HashMap ){ return FINDMAP((Map<String, Object>)replaceVal, key);	} 	
				else if (replaceVal instanceof List ) 							{ return FINDMAP((List<Map>)replaceVal, key);			}
				else 															{ return replaceVal;									}
			} else { return null;}
		}
	}

	public int RANDOM(int... args){
		int stVal = 1, enVal=10000;
		
		if (args.length > 1) {
			stVal = args[0];
			enVal = args[1];
		} else if (args.length > 0) {
			enVal = args[0];
		}
		
		int cnt	= enVal - stVal + 1;
		int rndVal = (int) (Math.floor( Math.random() * cnt ) + stVal);
		
		return rndVal;
	}
}
