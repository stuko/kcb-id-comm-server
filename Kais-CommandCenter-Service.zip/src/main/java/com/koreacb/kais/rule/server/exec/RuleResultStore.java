package com.koreacb.kais.rule.server.exec;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

import com.koreacb.kais.Constants;
import com.koreacb.kais.mybatis.MyBatisUtils;
import com.koreacb.kais.stats.dist.DistPerformance;

public class RuleResultStore {
	
	MyBatisUtils utils;
	final Map<String,int[]> itemStatsMap = new HashMap<>();

	public RuleResultStore() {
		utils = new MyBatisUtils("resultDataSource",false);
	}		
	
	public Map<String,Object> saveRuleResultInTable(String dataSetId
									, String dataLoadId
									, String dataLoadTableId
									, Map<String,Object> record
									, Map<String,Object> result
									, Map<String,Object> param) throws Exception{
		
		com.koreacb.kais.GlobalLogger.log(this,"RULE RESULT...................");
		Map<String,Object> map = new HashMap<>();
		Map<String,Object> output = null;
		Map<String,Object> score = null;
		try {
			map.put("SCOL_LOADING_DATA", "");
			map.put("RESULT_OUTPUT", "");
			map.put("RESULT_SCORE", "");
			map.put("KOUT_CODE", "0");
			map.put("SCOL_ERR_YN","N");
			map.put("SCOL_ORIGNAL_DATA","");
			
			if(result.containsKey(Constants.KAIS_OUT_CODE) && result.get(Constants.KAIS_OUT_CODE) != null) {
				String outCode = result.get(Constants.KAIS_OUT_CODE).toString();
				map.put("KOUT_CODE", outCode);
				// 룰을 실행한 결과가 정상이 아니면, SCOL_ERR_YN을 Y로 세팅 한다.
				// 향후, 룰 실행 결과 정보 테이블을 통계 분석할 경우, Y인것은 제외하고 통계를 실행 한다.
				// Mapper.xml의 selectDsetLoading 의 조건에 영향을 줌.
				if(!outCode.equals("0"))map.put("SCOL_ERR_YN","Y");
			}
			
			if(result.get(Constants.KAIS_OUT_RESULT_MAP) != null) {
				if(((Map<String,Object>)result.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP) != null) {
					output = (Map<String,Object>)((Map<String,Object>)result.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP);
					String out = new JSONObject(output).toString();
					// 통계를 만들기 위해, 표준 칼럼 이름을 사용해야 하므로, 중복 칼럼을 추가 함.
					map.put("SCOL_LOADING_DATA", out);
					map.put("RESULT_OUTPUT", out);
				}
				if(((Map<String,Object>)result.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_RESULT_SCORE_MAP) != null) {
					score = (Map<String,Object>)((Map<String,Object>)result.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_RESULT_SCORE_MAP);
					map.put("RESULT_SCORE", new JSONObject(score).toString());
				}

			}
			
			map.put("DAT_SET_ID", dataSetId);
			map.put("WK_EXE_ID", dataLoadId);
			map.put("DAT_LDN_TABLE_ID", dataLoadTableId);
			map.put("SCOL_DATASET_ID",record.get("SCOL_DATASET_ID") );
			map.put("SCOL_LOADING_ID",record.get("SCOL_LOADING_ID") );
			map.put("SCOL_RECORD_ID",record.get("SCOL_RECORD_ID"));
			map.put("SCOL_RANDOM_NO",record.get("SCOL_RANDOM_NO"));
			map.put("SCOL_ORIGNAL_DATA",record.get("SCOL_LOADING_DATA"));  // RULE INPUT 데이터
			map.put("SCOL_RESULT_DATA",new JSONObject(result).toString()); // 전체 결과 정보
			
			map.put("SCOL_RULE_ERR_YN","N"); // Default Setting, after can be chanaged...
			
			
			//---------------------------------------------------
			// 시뮬레이션의 Performance 칼럼 때문에 추가함.
			// PERF는 0,1,2 중 1개만 입력을 해줘야 함.
			//---------------------------------------------------			
			map.put(Constants.PERF_COLUMN, Constants.PERF_NORMAL);
			Map<String,Object> permInf = param.containsKey(Constants.PERFORMANCE_ITEM) ? (Map<String,Object>)param.get(Constants.PERFORMANCE_ITEM) : null;
			if(permInf != null && permInf.containsKey(Constants.PERFORMANCE_ITM_LIST)) {
				List<Map<String,Object>> list = (List<Map<String,Object>>)permInf.get(Constants.PERFORMANCE_ITM_LIST);
				// 리스트는 항상 3개가 전송된다.
				DistPerformance df = null;
				// Performance 칼럼은 1개이다. 단 3가지 케이스를 보내준다.(0,1,2)
				if(list.size() == 3
				&& permInf.containsKey(Constants.PERFORMANCE_ITM_ID)
				&& permInf.get(Constants.PERFORMANCE_ITM_ID) != null
				) {
					df = new DistPerformance();
					int i = 0;
					df.setPermId(permInf.get(Constants.PERFORMANCE_ITM_ID).toString());
					for(int idx = 0; idx < list.size() ; idx++) {
						Map<String,Object> m  = list.get(idx);
						df.newPerformance(idx);
						df.getPerformance()[idx].setPerfValue(m.get(Constants.PRMC_VL).toString());
						df.getPerformance()[idx].setLowerOperand(m.get(Constants.LWLM_CND_TP).toString());
						df.getPerformance()[idx].setUseYn(m.get(Constants.USE_YN).toString());
						df.getPerformance()[idx].setUpper(m.get(Constants.HGLM_CND_VL).toString());
						df.getPerformance()[idx].setLower(m.get(Constants.LWLM_CND_VL).toString());
						df.getPerformance()[idx].setUpperOperand(m.get(Constants.HGLM_CND_TP).toString());
					}
					df.decideValue(record);
					map.put(Constants.PERF_COLUMN, df.getFinalValue());
				}
			}
			
			if(result.containsKey(Constants.KAIS_OUT_RESULT_MAP) && result.get(Constants.KAIS_OUT_RESULT_MAP) != null) {
				Map<String,Object> resultMap = ((Map<String,Object>)result.get(Constants.KAIS_OUT_RESULT_MAP));
				if(resultMap.containsKey(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP) && resultMap.get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP) != null) {
					
					com.koreacb.kais.GlobalLogger.log(this,"---------- Rule Validation Test -------------");
					com.koreacb.kais.GlobalLogger.log(this,"[VERIFY_MAPPING Exist ?] = ["+param.containsKey(Constants.VERIFY_MAPPING)+"] ");
					com.koreacb.kais.GlobalLogger.log(this,"[SCOL_LOADING_MAP Exist ?] = ["+(record.get("SCOL_LOADING_MAP") != null)+"] ");

					Map<String,Object> checkMap = (Map<String,Object>)((Map<String,Object>)result.get(Constants.KAIS_OUT_RESULT_MAP)).get(Constants.KAIS_OUT_BASIC_RULE_RESULT_OUTPUT_MAP);
					Map<String,Object> loadingMap = (Map<String,Object>)record.get("SCOL_LOADING_MAP");
					List<Map<String,Object>> verifyMap = null;
					
					if(param.containsKey(Constants.VERIFY_MAPPING) && param.get(Constants.VERIFY_MAPPING) != null) {
						verifyMap = (List<Map<String,Object>>)param.get(Constants.VERIFY_MAPPING);
					}
					if(checkMap != null) {
						for(String k : checkMap.keySet()){
							newMap(itemStatsMap,k);
							verifyMap(map, param, verifyMap, checkMap, loadingMap, itemStatsMap, k );
						}
					}
					com.koreacb.kais.GlobalLogger.log(this,"---------- Rule Validation Test -------------");
					com.koreacb.kais.GlobalLogger.log(this,"Store Info = " + map);
					utils.insert("insertResultTable",map);
					itemStatsMap.forEach((k, v) ->{
						Map<String,Object> itemMap = new HashMap<>();
						itemMap.put("DAT_SET_ID", dataSetId);
						itemMap.put("WK_EXE_ID", dataLoadId);
						itemMap.put("ITEM_ID", k);
						itemMap.put("TOT", v[0]);
						itemMap.put("ERR", v[1]);
						try {
							utils.insert("insertAnalysisItem", itemMap);
						} catch (Exception e) {
							e.printStackTrace();
						}
					});
				}
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}
		return output;
	}
	
	public Map<String,int[]> newMap(Map<String,int[]> map, String itemId){
		if(!map.containsKey(itemId)) map.put(itemId, new int[2]);
		return map;
	}
	
	public boolean verifyMap(Map<String,Object> sqlMap, Map<String,Object> param, List<Map<String,Object>> vMap, Map<String,Object> checkMap, Map<String,Object> loadingMap, Map<String,int[]> itemStatsMap ,  String k ) {
		
		boolean verify_error = false;
		itemStatsMap.get(k)[0] = itemStatsMap.get(k)[0]+1;
		
		if(param.get(Constants.VERIFY_MAPPING) == null) {
			verify_error = false;
		}else {
			String targetId = this.existVerifyResultItem(vMap, k);
			if(targetId != null) {
				if(loadingMap.containsKey(targetId)) {
					String src = loadingMap.get(targetId).toString();
					if(!src.equals(checkMap.get(k).toString()))	verify_error = true;
				}
			}
		}

		if(verify_error) {
			itemStatsMap.get(k)[1] = itemStatsMap.get(k)[1]+1;
			sqlMap.put("SCOL_RULE_ERR_YN","Y");
		}
		
		return verify_error;
		
	}
	
	public String existVerifyResultItem(List<Map<String,Object>> vMap, String itemId) {
		if(vMap == null) return null;
		for(Map<String,Object> map : vMap) {
			for(String k : map.keySet()) {
				if(k.equals(Constants.VRF_RSLT_ITM_ID) && map.get(k).toString().equals(itemId)) {
					return map.get(Constants.VRF_TGT_ITM_ID).toString();
				}
			}
		}
		return null;
	}
	
	public boolean existVerifyLoadingItem(List<Map<String,Object>> vMap, String itemId) {
		if(vMap == null) return false;
		for(Map<String,Object> map : vMap) {
			for(String k : map.keySet()) {
				if(k.equals(Constants.VRF_TGT_ITM_ID) && map.get(k).toString().equals(itemId)) {
					return true;
				}
			}
		}
		return false;
	}
}
