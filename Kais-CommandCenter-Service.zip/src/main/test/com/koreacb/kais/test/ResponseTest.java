package com.koreacb.kais.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreacb.kais.Constants;
import com.koreacb.kais.status.StatusManager;

public class ResponseTest {
	
	
	public void testScoreCard() throws Exception {
		
		List<Map<String,Object>> list = new ArrayList<>();
		list.add(new HashMap<String,Object>());
		list.get(list.size()-1).put("TEST_ITM_ID","item1");
		list.get(list.size()-1).put("LVL1_ALL_CNT","12");
		list.get(list.size()-1).put("LVL1_VLD_CNT","5");
		list.get(list.size()-1).put("LVL1_NUL_CNT","0");
		list.get(list.size()-1).put("LVL1_SV_CNT","1");
		list.get(list.size()-1).put("LVL1_ZERO_CNT","1");
		list.get(list.size()-1).put("LVL1_MIN_VL","1");
		list.get(list.size()-1).put("LVL1_MAX_VL","33");
		list.get(list.size()-1).put("LVL1_SUM_VL","78");
		list.get(list.size()-1).put("LVL1_AVG_VL","22");
		list.get(list.size()-1).put("LVL2_VL_CNT","11");
		list.get(list.size()-1).put("LVL2_MSFC_VL","1");
		list.get(list.size()-1).put("LVL2_P05","1");
		list.get(list.size()-1).put("LVL2_P10","11");
		list.get(list.size()-1).put("LVL2_P25","21");
		list.get(list.size()-1).put("LVL2_P50","31");
		list.get(list.size()-1).put("LVL2_P75","41");
		list.get(list.size()-1).put("LVL2_P90","51");
		list.get(list.size()-1).put("LVL2_P95","61");
		
		List<Map<String,Object>> list1 = new ArrayList<>();
		
		list.get(list.size()-1).put("VL_DSTB_ANL",list1);
		
		List<Map<String,Object>> list2 = new ArrayList<>();
		
		list.get(list.size()-1).put("SEG_DSTB_ANL",list2);
		list.get(list.size()-1).put("ERR_CNT","10");
		list.get(list.size()-1).put("ERR_RT","13%");
		
		Map<String,Object> map = new HashMap<>();
		map.put(Constants.RESPONSE_INFO, "SR70");
		map.put("SIMUL_DATA",new HashMap<String,Object>());
		map.put("BASIC_INFO", new ArrayList<Map<String,Object>>());
		
		StatusManager tf = new StatusManager();
		tf.transfer("","POST",map);
	
	}
	
	public static void main(String[] args) {
		// ResponseTest test = new ResponseTest();
		try {
			// test.testScoreCard();
			// System.out.println("a".compare("bbb"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
